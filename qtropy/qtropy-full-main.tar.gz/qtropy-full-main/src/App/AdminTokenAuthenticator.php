<?php

namespace Walnut\App;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

final readonly class AdminTokenAuthenticator implements MiddlewareInterface {

	public function __construct(
		//private readonly AccessTokenDecoder $accessTokenDecoder,
		private string $headerName,
		private string $cookieName,
		private string $attributeName
	) {}

	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {
		$token =
			$request->getHeader($this->headerName)[0] ??
			$request->getCookieParams()[$this->cookieName] ??
			null;
		$identityValue = $token === 'nice' ? 'admin' : null;
		if ($identityValue) {
			$request = $request->withAttribute($this->attributeName, $identityValue);
		}
		$response = $handler->handle($request);
		if ($token && $identityValue && !$response->getHeader('Set-Cookie')) {
			$response = $response->withAddedHeader(
				'Set-Cookie',
				"$this->cookieName=$token; Path=/; SameSite=Strict"
			);
		}
		return $response;
	}
}