<?php

namespace Walnut\App;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Walnut\Lib\HttpMapper\ResponseBuilder;

final readonly class CorsHandler implements MiddlewareInterface {

	public function __construct(
		private string          $origin,
		private ResponseBuilder $responseBuilder
	) {}

	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {
		return $this->addHeaders(
			$request->getMethod() === 'OPTIONS' ?
			$this->responseBuilder->emptyResponse() :
			$handler->handle($request)
		);
	}

	private function addHeaders(ResponseInterface $response): ResponseInterface {
		return $response
			->withAddedHeader('Access-Control-Expose-Headers', 'Location')
			->withAddedHeader('Access-Control-Allow-Headers', 'Pragma, Cache-Control, Content-Type, x-qtropy-token')
			//->withAddedHeader('Access-Control-Allow-Origin', rtrim($this->origin, '/'))
			->withAddedHeader('Access-Control-Allow-Origin', rtrim($this->origin, '/'))
			->withAddedHeader('Access-Control-Allow-Methods', 'OPTIONS, GET, HEAD, POST, PUT, PATCH, DELETE');
	}
}
