<?php

namespace Walnut\App;

use Psr\Log\LoggerInterface;
use Walnut\Lib\Container\Container;
use Walnut\Lib\Container\ContainerDecorator;
use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Lib\DecorAuto\Decorator\Builder\DecoratedInterfaceGenerator;
use Walnut\Lib\DecorAuto\Implementation\Model\InterfaceImplementation;
use Walnut\Lib\EventBus\EventBus;
use Walnut\Lib\TransactionContext\TransactionContext;
/*
use Walnut\Module\Content\Application\Context\Author;
use Walnut\Module\Content\Application\Context\Authors;
use Walnut\Module\Content\Application\Context\ContentContext;
use Walnut\Module\Content\Application\Context\Treatise\Treatise;
use Walnut\Module\Content\Application\Context\Treatise\TreatiseDraft;
use Walnut\Module\Content\Application\Context\Treatise\Treatises;
use Walnut\Module\Content\Domain\Command\Treatise\AddTreatiseDraft\AddTreatiseDraft;
use Walnut\Module\Feed\Application\Context\AccountFeed as Feed;
use Walnut\Module\Feed\Application\Context\FeedContext;
use Walnut\Module\Feed\Application\Context\FeedTreatise;
use Walnut\Module\Feed\Application\Context\FeedTreatises;
use Walnut\Module\Qtropy\Context\ApplicationAccount;
use Walnut\Module\Qtropy\Context\ApplicationAccounts;
use Walnut\Module\Qtropy\Context\ApplicationContext;
*/

final readonly class WalnutContainerDecorator implements ContainerDecorator {

	public function __construct(
		private Container                   $container,
		private DecoratedInterfaceGenerator $decoratedInterfaceGenerator
	) {}

	private function instantiate(
		InterfaceImplementation $decoratedInterface,
		object $instance,
		object $decorator
	): object {
		if (!class_exists($decoratedInterface->className, false)) {
			//echo "EVAL: ", $instance::class, " as ", $decoratedInterface->className, PHP_EOL;
			//echo $decoratedInterface->sourceCode;
			eval($decoratedInterface->sourceCode);
		}
		return new $decoratedInterface->className(instance: $instance, decorator: $decorator);
	}

	/**
	 * @template T of object
	 * @param T $instance
	 * @param class-string<T> $className
	 * @return T
	 */
	public function apply(object $instance, string $className): object {
		//echo "Class = $className, Instance = ", $instance::class, '<br/>', PHP_EOL;
		return match(true) {
			in_array($className, [
				/*ApplicationContext::class,
				ApplicationAccounts::class,
				ApplicationAccount::class,
				Authors::class,
				Author::class,
				Feed::class,
				FeedTreatises::class,
				FeedTreatise::class,
				Treatises::class,
				Treatise::class,
				TreatiseDraft::class,
				ContentContext::class,
				FeedContext::class,*/
			], true) => $this->instantiate(
				$this->decoratedInterfaceGenerator->getDecoratedInterface(
					$className,
					($decorator = new EventInterceptor(
						$this->container->instanceOf(TransactionContext::class),
						$this,
						$this->container->instanceOf(EventBus::class)
					))::class
				),
				$instance,
				$decorator
			),
			$className === QueryExecutor::class => $this->instantiate(
				$this->decoratedInterfaceGenerator->getDecoratedInterface(
					$className,
					($decorator = new QueryExecutorLogger(
						$this->container->instanceOf(LoggerInterface::class)
					))::class
				),
				$instance,
				$decorator
			),
			str_ends_with($className, 'Service') => $this->instantiate(
				$this->decoratedInterfaceGenerator->getDecoratedInterface(
					$className,
					($decorator = new TransactionCommitDecorator(
						$this->container->instanceOf(TransactionContext::class)
					))::class
				),
				$instance,
				$decorator
			),
			/*ControllerParser::class => $this->instantiate(
				$this->decoratedInterfaceGenerator->getDecoratedInterface(
					$className,
					($decorator = new ControllerParserLogger(null))::class
				),
				$instance,
				$decorator
			),*/
			default => $instance
		};
	}
}
