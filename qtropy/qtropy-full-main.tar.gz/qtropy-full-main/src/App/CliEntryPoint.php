<?php

namespace Walnut\App;

use Walnut\Module\Survey\Application\Service\AllExpiringSurveysFinder;

final readonly class CliEntryPoint {
	public function __construct(
		private AllExpiringSurveysFinder $allExpiringSurveysFinder
	) {}

	/** @var string[] $argv */
	public function execute(array $argv): string|null {
		$cmd = $argv[1] ?? null;
		$param = $argv[2] ?? null;
		$result = match($cmd) {
			'check-expiring' => $this->checkExpiring($param === '-s'),
			default => "Unrecognized command: $cmd"
		};
		return is_string($result) ? $result : null;
	}

	private function checkExpiring(bool $silent): string|null {
		$result = $this->allExpiringSurveysFinder->findAndCompleteAll();
		if ($silent) {
			return null;
		}
		return "The following surveys has been marked as completed:" . PHP_EOL .
			implode(PHP_EOL, $result) . PHP_EOL .
			"Total: " . count($result) . " survey(s)";
	}
}