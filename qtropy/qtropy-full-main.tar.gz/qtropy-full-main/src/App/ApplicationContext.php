<?php

namespace Walnut\App;

use Walnut\Module\Qtropy\Application\Context\_Qtropy;

interface ApplicationContext {
 	public function qtropy(): _Qtropy;
}