<?php

namespace Walnut\App;

use Walnut\Module\Kernel\Uuid\Uuid;

final readonly class HashedUuidGenerator {
	public function generateForValues(Uuid ... $values): Uuid {
		$hash = md5(implode('/', array_map(
			static fn(Uuid $uuid): string => $uuid->binaryValue,
			$values
		)));

		$bin = hex2bin($hash);
		/**
		 * @var int[] $arr
		 */
		$arr = array_values(unpack('N1a/n4b/N1c', $bin));
		$arr[2] = ($arr[2] & 0x0fff) | 0x4000;
		$arr[3] = ($arr[3] & 0x3fff) | 0x8000;

		$result = vsprintf('%08x-%04x-%04x-%04x-%04x%08x', $arr);
		return Uuid::fromString($result);
	}
}

