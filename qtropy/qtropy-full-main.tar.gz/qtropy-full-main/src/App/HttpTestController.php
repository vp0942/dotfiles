<?php

namespace Walnut\App;

use RuntimeException;
use Throwable;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\TextResponse;
use Walnut\Module\Content\Domain\Model\Common\Content;
use Walnut\Module\Content\Domain\Model\Common\Title;
use Walnut\Module\Content\Domain\Model\Treatise\Exception\UnknownTreatiseId;
use Walnut\Module\Content\Domain\Model\Treatise\Treatise;
use Walnut\Module\Content\Domain\Rejection\DraftAlreadyStarted;
use Walnut\Module\Kernel\Account\AccountId;
use Walnut\Module\Qtropy\Application\Context\ApplicationContext;

final readonly class HttpTestController {
	public function __construct(
		private ApplicationContext $applicationContext
	) {}

	private function getPrivateProperty(object $x, string $propertyName): mixed {
		return (fn() => $this->$propertyName)->call($x);
	}

	#[HttpGet('/treatises'), TextResponse]
	public function treatises(): string {
		ob_start();

		try {
			$account = $this->applicationContext->accounts()->accountWithId(
				AccountId::fromString('00000001-0002-4444-8888-000000000000')
			);
			$treatises = $account->content()->treatises();

			///////////
			echo "Step 1.1 - create a treatise draft", PHP_EOL;
			$treatiseId = $treatises->createDraft(new Title("My treatise 1"), new Content("My content 1"));
			echo "Created treatise with id ", $treatiseId->value->stringValue, ".", PHP_EOL;
			///////////
			echo "Step 1.2. Update title and content", PHP_EOL;
			$treatises->draftWithId($treatiseId)->updateDetails(
				new Title("My treatise 2"), new Content("My content 2")
			);
			///////////
			echo "Step 1.3. Delete treatise draft", PHP_EOL;
			$treatises->draftWithId($treatiseId)->remove();

			try {
				$treatises->draftWithId($treatiseId);
				throw new RuntimeException("Draft treatise is still there");
			} catch (UnknownTreatiseId) {}

			///////////
			echo '------------------------------------------------------------------------', PHP_EOL;
			///////////
			echo "Step 2.1 - create a treatise draft", PHP_EOL;
			$treatiseId = $treatises->createDraft(new Title("My treatise 1"), new Content("My content 1"));
			echo "Created treatise with id ", $treatiseId->value->stringValue, ".", PHP_EOL;
			///////////
			echo "Step 2.2.1 Update title and content", PHP_EOL;
			$treatises->draftWithId($treatiseId)->updateDetails(
				new Title("My treatise 2"), new Content("My content 2")
			);
			///////////
			echo "Step 2.2.2 Publish draft", PHP_EOL;
			$treatises->draftWithId($treatiseId)->publish();
			///////////
			echo "Step 2.3. Delete treatise", PHP_EOL;
			$treatises->withId($treatiseId)->remove();

			try {
				$treatises->withId($treatiseId);
				throw new RuntimeException("Treatise is still there");
			} catch (UnknownTreatiseId) {}

			///////////
			echo '------------------------------------------------------------------------', PHP_EOL;
			///////////
			echo "Step 3.1 - create a treatise draft", PHP_EOL;
			$treatiseId = $treatises->createDraft(new Title("My treatise 1"), new Content("My content 1"));
			echo "Created treatise with id ", $treatiseId->value->stringValue, ".", PHP_EOL;
			///////////
			echo "Step 3.2.1 Update title and content", PHP_EOL;
			$treatises->draftWithId($treatiseId)->updateDetails(
				new Title("My treatise 2"), new Content("My content 2")
			);
			///////////
			echo "Step 3.2.2 Publish draft", PHP_EOL;
			$treatises->draftWithId($treatiseId)->publish();

			/**
			 * @var Treatise $check
			 */
			$check = $this->getPrivateProperty($treatises->withId($treatiseId), 'treatise');
			($check->treatiseContent->title->value === "My treatise 2" &&
			$check->treatiseContent->content->value === "My content 2") || throw new RuntimeException("Unexpected treatise content");

			///////////
			echo '------------------------------------------------------------------------', PHP_EOL;
			///////////
			echo "Step 4.1 - edit treatise (add draft)", PHP_EOL;
			$treatises->withId($treatiseId)->createRevisionDraft();
			echo "Step 4.2 Update title and content", PHP_EOL;
			$treatises->draftWithId($treatiseId)->updateDetails(
				new Title("My treatise 3"), new Content("My content 3")
			);

			/**
			 * @var Treatise $check
			 */
			$check = $this->getPrivateProperty($treatises->withId($treatiseId), 'treatise');
			($check->treatiseContent->title->value === "My treatise 2" &&
			$check->treatiseContent->content->value === "My content 2") || throw new RuntimeException("Unexpected treatise content");
			/**
			 * @var Treatise $check
			 */
			$check = $this->getPrivateProperty($treatises->draftWithId($treatiseId), 'treatise');
			($check->currentDraft?->treatiseContent->title->value === "My treatise 3" &&
			$check?->currentDraft->treatiseContent->content->value === "My content 3") || throw new RuntimeException("Unexpected treatise draft content");

			///////////
			echo '------------------------------------------------------------------------', PHP_EOL;
			///////////
			echo "Step 5.1 - edit treatise (add draft)", PHP_EOL;
			try {
				$treatises->withId($treatiseId)->createRevisionDraft();
				throw new RuntimeException("Cannot create a second draft revision");
			} catch (DraftAlreadyStarted) {}
			echo "Step 5.2.1 Update title and content", PHP_EOL;
			$treatises->draftWithId($treatiseId)->updateDetails(
				new Title("My treatise 5"), new Content("My content 5")
			);
			echo "Step 5.2.2 Publish draft", PHP_EOL;
			$treatises->draftWithId($treatiseId)->publish();

			/**
			 * @var Treatise $check
			 */
			$check = $this->getPrivateProperty($treatises->withId($treatiseId), 'treatise');
			($check->treatiseContent->title->value === "My treatise 5" &&
			$check->treatiseContent->content->value === "My content 5") || throw new RuntimeException("Unexpected treatise content");

			try {
				/**
				 * @var Treatise $check
				 */
				$check = $this->getPrivateProperty($treatises->draftWithId($treatiseId), 'treatise');
				if ($check->currentDraft) {
					throw new RuntimeException("Treatise draft is still there");
				}
			} catch (UnknownTreatiseId) {}

			///////////
			echo '------------------------------------------------------------------------', PHP_EOL;
			///////////
			echo "Step 6.1 - edit treatise (add draft)", PHP_EOL;
			$treatises->withId($treatiseId)->createRevisionDraft();
			echo "Step 6.2 Update title and content", PHP_EOL;
			$treatises->draftWithId($treatiseId)->updateDetails(
				new Title("My treatise 6"), new Content("My content 6")
			);
			echo "Step 6.3 Delete draft", PHP_EOL;
			$treatises->draftWithId($treatiseId)->remove();

			/**
			 * @var Treatise $check
			 */
			$check = $this->getPrivateProperty($treatises->withId($treatiseId), 'treatise');
			($check->treatiseContent->title->value === "My treatise 5" &&
			$check->treatiseContent->content->value === "My content 5") || throw new RuntimeException("Unexpected treatise content");

			try {
				/**
				 * @var Treatise $check
				 */
				$check = $this->getPrivateProperty($treatises->draftWithId($treatiseId), 'treatise');
				if ($check->currentDraft) {
					throw new RuntimeException("Treatise draft is still there");
				}
			} catch (UnknownTreatiseId) {}

			///////////
			echo '------------------------------------------------------------------------', PHP_EOL;
			///////////
			echo "Step 7.1 - edit treatise (add draft)", PHP_EOL;
			$treatises->withId($treatiseId)->createRevisionDraft();
			echo "Step 7.2 Delete treatise", PHP_EOL;
			$treatises->withId($treatiseId)->remove();

			try {
				$treatises->withId($treatiseId);
				throw new RuntimeException("Treatise is still there");
			} catch (UnknownTreatiseId) {}
			try {
				$treatises->draftWithId($treatiseId);
				throw new RuntimeException("Treatise draft is still there");
			} catch (UnknownTreatiseId) {}

		} catch (Throwable $ex) {
			echo "Error: ", $ex;
		}
		return (string)ob_get_clean();
	}
}