<?php

namespace Walnut\App;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

final readonly class AnonymousAccountHandler implements MiddlewareInterface {

	public function __construct(
		private string                  $attributeName,
		private RequestHandlerInterface $anonymousAccountLookupRouter,
	) {}

	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {
		$identityValue = $request->getAttribute($this->attributeName);
		if (!$identityValue) {
			return $this->anonymousAccountLookupRouter->handle($request);
		}
		return $handler->handle($request);
	}
}