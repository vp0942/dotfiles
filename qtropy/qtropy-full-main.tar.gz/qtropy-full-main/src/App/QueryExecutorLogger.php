<?php

namespace Walnut\App;

use Psr\Log\LoggerInterface;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\Before;

final readonly class QueryExecutorLogger {
	public function __construct(private LoggerInterface $logger) { }

	#[Before('execute')]
	public function logQuery(array $args): void {
		$this->logger->debug("Query: " . $args[0]);
	}
}
