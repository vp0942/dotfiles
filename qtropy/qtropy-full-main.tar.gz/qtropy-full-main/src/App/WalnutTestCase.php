<?php

namespace Walnut\App;

use PHPUnit\Framework\TestCase;
use Walnut\Lib\Container\Container;

abstract class WalnutTestCase extends TestCase {

	protected Container $container;

	protected function setUp(): void {
		$this->container = new Container(
			$this->getOverriddenDependencies() +
				require __DIR__ . '/../../config/tests/di.config.php',
			WalnutContainerDecorator::class);
	}

	protected function getOverriddenDependencies(): array {
		return [];
	}
}