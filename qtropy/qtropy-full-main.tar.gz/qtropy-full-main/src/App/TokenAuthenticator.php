<?php

namespace Walnut\App;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

final readonly class TokenAuthenticator implements MiddlewareInterface {

	public function __construct(
		private AccessTokenDecoder $accessTokenDecoder,
		private string             $headerName,
		private string             $cookieName,
		private string             $attributeName
	) {}

	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {
		$token =
			$request->getHeader($this->headerName)[0] ??
			$request->getCookieParams()[$this->cookieName] ??
			null;
		//$identityValue = '00000005-0001-4444-8888-100000000163' ?? //TEMP
		$identityValue = //'99900001-0001-4444-8888-000000000001' ?? //TEMP
		//$identityValue = '00000001-0001-4444-8888-100000000164' ?? //TEMP
			($token ? $this->accessTokenDecoder->getTokenValue($token) : null);
		if ($identityValue) {
			$request = $request->withAttribute($this->attributeName, $identityValue);
		}
		$response = $handler->handle($request);
		if ($token && $identityValue && !$response->getHeader('Set-Cookie')) {
			$response = $response->withAddedHeader(
				'Set-Cookie',
				"$this->cookieName=$token; Path=/; SameSite=Strict"
			);
		}
		return $response;
	}
}