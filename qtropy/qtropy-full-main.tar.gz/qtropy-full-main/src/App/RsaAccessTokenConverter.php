<?php

namespace Walnut\App;

use Walnut\Lib\Security\RsaPrivateKey;

final readonly class RsaAccessTokenConverter implements AccessTokenDecoder, AccessTokenGenerator {

	public function __construct(private RsaPrivateKey $rsaKey) {}

	public function generateToken(string $value): string {
		return base64_encode($this->rsaKey->encrypt($value));
	}

	public function getTokenValue(string $token): ?string {
		$decodedToken = base64_decode($token);
		return $decodedToken ? $this->rsaKey->getPublicKey()->decrypt($decodedToken) : null;
	}

}