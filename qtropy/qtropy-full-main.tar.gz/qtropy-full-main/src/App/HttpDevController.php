<?php

namespace Walnut\App;

use Throwable;
use Walnut\Lib\Container\Container;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromForm;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpPost;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\HtmlResponse;
use Walnut\Module\Qtropy\Application\Context\_Qtropy;

final readonly class HttpDevController {
	private _Qtropy $qtropy;
	public function __construct(
		private Container $container,
	) {
		$this->qtropy = $this->container->instanceOf(
			_Qtropy::class
		);
	}

	#[HttpGet, HtmlResponse]
	public function form($code = ''): string {
		return "<form method='post'><textarea name='code' rows='20' cols='100' autofocus>$code</textarea><br/><button type='submit'>Execute</button></form>";
	}

	#[HttpPost, HtmlResponse]
	public function exec(#[FromForm('code')] $code): string {
		ob_start();
		try {
			echo $this->form($code);
			eval($code);
		} catch (Throwable $e) {
			echo '<pre>', $e, '</pre>';
		}
		return ob_get_clean();
	}

}