<?php

namespace Walnut\App;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Walnut\Lib\DbQuery\QueryExecutor;

final readonly class ContentVisitsCounter implements MiddlewareInterface {

	private const answerRegexp = "#question/Q-\d+/answer/(Q\-\d+\-A\-\d+)#";
	private const questionRegexp = "#question/(Q-\d+)#";
	private const treatiseRegexp = "#treatise/(T\-\d+)#";
	private const noteRegexp = "#note/(N-\d+)#";

	public function __construct(
		private QueryExecutor           $queryExecutor
	) {}

	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {
		$path = $request->getRequestTarget();
		foreach([self::answerRegexp, self::questionRegexp, self::treatiseRegexp, self::noteRegexp] as $regExp) {
			if (preg_match($regExp, $path, $matches)) {
				$this->queryExecutor->execute("UPDATE content_entries SET visits_counter = visits_counter + 1 WHERE content_key = ?", [$matches[1]]);
				break;
			}
		}
		return $handler->handle($request);
	}
}