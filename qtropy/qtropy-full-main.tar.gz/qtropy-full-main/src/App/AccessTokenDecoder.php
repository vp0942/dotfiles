<?php

namespace Walnut\App;

interface AccessTokenDecoder {
	public function getTokenValue(string $token): string|null;
}