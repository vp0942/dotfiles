<?php

namespace Walnut\App\Email;

use Walnut\Lib\FileAccessor\FileAccessor;

final readonly class InFileEmailSender implements EmailSender {
	public function __construct(
		private FileAccessor $fileAccessor,
		private string       $fileName
	) {}

	public function send(EmailAddress $emailAddress, EmailMessage $message): void {
		$this->fileAccessor->appendToFile($this->fileName,
			"---" . PHP_EOL .
			sprintf("Subject:\n %s" . PHP_EOL, $message->subject) .
			sprintf("Body:\n %s" . PHP_EOL, $message->body) .
			"---" . PHP_EOL
		);
	}
}
