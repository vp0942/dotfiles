<?php

namespace Walnut\App\Email;

use Walnut\Lib\DataType\Exception\InvalidValue;
use Walnut\Lib\DataType\StringData;

final readonly class EmailAddress {
	/**
	 * @throws InvalidValue
	 */
	public function __construct(
		public string $value
	) {
		(new StringData(minLength: 1, maxLength: 127, format: 'email'))->importValue($value);
	}
}