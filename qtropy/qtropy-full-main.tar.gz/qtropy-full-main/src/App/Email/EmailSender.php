<?php

namespace Walnut\App\Email;

interface EmailSender {
	public function send(EmailAddress $emailAddress, EmailMessage $message): void;
}
