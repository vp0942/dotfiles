<?php

namespace Walnut\App\Email;

final readonly class EmailMessage {
	public function __construct(
		public string $subject,
		public string $body,
	) {}
}
