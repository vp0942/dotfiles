<?php

namespace Walnut\App;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Walnut\Lib\Container\Container;
use Walnut\Lib\HttpController\ControllerHelper;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\InvalidUuid;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Member\Application\Context\_Member;
use Walnut\Module\Member\Application\Context\_Members;

final readonly class QtropyLookupRouter implements MiddlewareInterface {

	/**
	 * @param ControllerHelper $controllerHelper
	 * @param Container $container
	 * @param array<string, class-string> $routerMapping
	 * @param string $routeAttributeName
	 * @param string $accountIdAttributeName
	 */
	public function __construct(
		private ControllerHelper $controllerHelper,
		private Container        $container,
		private array            $routerMapping,
		private string           $routeAttributeName = 'route',
		private string           $accountIdAttributeName = 'accountId'
	) {}

	public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {
		$route = (string)$request->getAttribute($this->routeAttributeName);
		$routeHandler = $this->routerMapping[$route] ?? null;

		$memberIdString = (string)$request->getAttribute($this->accountIdAttributeName);
		try {
			if ($memberIdString) {
				$uuid = Uuid::fromString($memberIdString);
			}
		} catch (InvalidUuid) {
			$memberIdString = null;
		}
		if ($memberIdString) {
			$context = [
				_Member::class => static fn(_Members $members): _Member => $members
					->member(new MemberId($uuid)),
			];
		} else {
			$context = [];
		}

		/**
		 * @var RequestHandlerInterface|object $mappedHandler
		 */
		$mappedHandler = $routeHandler ?
			$this->container->
				withAdditionalMapping($context)->instanceOf($routeHandler) : $handler;
			//$this->container->contextInstanceOf($routeHandler, $context) : $handler;

		$next = $mappedHandler instanceof RequestHandlerInterface ?
			$mappedHandler : $this->controllerHelper->wire($mappedHandler);

		return $next->handle($request);
	}

}
