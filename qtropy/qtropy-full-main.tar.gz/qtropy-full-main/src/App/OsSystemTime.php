<?php

namespace Walnut\App;

use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Time\SystemTime;

final readonly class OsSystemTime implements SystemTime {

	public function now(): DateAndTime {
		return new DateAndTime;
	}
}