<?php

namespace Walnut\App;

interface AccessTokenGenerator {
	public function generateToken(string $value): string;
}