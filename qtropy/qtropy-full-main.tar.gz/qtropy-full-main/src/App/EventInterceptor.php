<?php

namespace Walnut\App;

use ReflectionObject;
use ReflectionUnionType;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\AfterReturning;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\AfterThrowing;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\Around;
use Walnut\Lib\DecorAuto\Decorator\DecoratorContext;
use Walnut\Lib\EventBus\EventBus;
use Walnut\Lib\TransactionContext\TransactionContext;

final readonly class EventInterceptor {
	public function __construct(
		private TransactionContext       $transactionContext,
		private WalnutContainerDecorator $decorator,
		private EventBus                 $eventBus,
	) {}

	//#[Around(new WhitelistMethodFilter('authors', 'withAccountId', 'treatises', 'withId', 'draftWithId'))]
	#[Around]
	public function nestedCall(callable $fn, DecoratorContext $decoratorContext): mixed {
		$result = $fn();
		//printf("Decorator context: %s...<br/>", $decoratorContext->instance::class);

		$args = [];
		$shouldReplace = false;
		$rObj = new ReflectionObject($result);
		if (
			$rObj->hasProperty('instance') &&
			$rObj->hasProperty('decorator') &&
			count($rObj->getProperties()) === 2
		) {
			return $result;
		}
		foreach($rObj->getProperties() as $property) {
			/*printf("Types: %s -- %s...<br/>",
				$property->getValue($result)::class,
				$property->getType()?->getName()
			);
			printf("[PARAM]");*/
			$v1 = $property->getValue($result);
			$v2 = $property->getType() instanceof ReflectionUnionType || $v1::class === $property->getType()?->getName() ?
				$v1 : $this->decorator->apply($v1, $property->getType()?->getName());
			$args[$property->getName()] = $v2;
			$shouldReplace |= $v1 !== $v2;
			//echo $result::class . '* ' . $property->getName() . ' ? ' . ($v1 !== $v2 ? 'DIFF' : 'EQ') . '<br/>';
		}
		if ($shouldReplace) {
			//printf("Start Replacing %s...<br/>", $result::class);
			$result = $rObj->newInstanceWithoutConstructor();
			foreach($rObj->getProperties() as $property) {
				$property->setValue($result, $args[$property->getName()]);
			}
			//printf("Finish Replacing %s...<br/>", $result::class);
		}
		if (count(class_implements($result::class)) === 1) {
			//echo "[RET]<br/>";
			//$oldResult = $result;
			$result = $this->decorator->apply(
				$result,
				array_key_first(class_implements($result::class))
			);
			//printf("Replaced %s by %s...<br/>", $oldResult::class, $result::class);
		}
		return $result;
	}

	#[AfterReturning]
	public function publishEvent(mixed $event, DecoratorContext $decoratorContext): void {
		if (is_object($event)) {
			$this->eventBus->dispatchEvent($event);
		}
	}


	#[AfterReturning]
	public function commitTransaction(): void {
		$this->transactionContext->saveChanges();
	}

	#[AfterThrowing]
	public function rollbackTransaction(): void {
		$this->transactionContext->revertChanges();
	}

}