<?php

namespace Walnut\App;

use Psr\Http\Message\ServerRequestFactoryInterface;
use Psr\Http\Message\StreamFactoryInterface;
use Psr\Http\Message\UriFactoryInterface;
use Walnut\Lib\HttpController\ControllerHelper;

abstract class WalnutHttpControllerTestCase extends WalnutTestCase {

	protected ControllerHelper $controllerHelper;
	protected ServerRequestFactoryInterface $requestFactory;
	protected StreamFactoryInterface $streamFactory;
	protected UriFactoryInterface $uriFactory;

	protected function setUp(): void {
		parent::setUp();
		$this->controllerHelper = $this->container->instanceOf(ControllerHelper::class);
		$this->requestFactory = $this->container->instanceOf(ServerRequestFactoryInterface::class);
		$this->streamFactory = $this->container->instanceOf(StreamFactoryInterface::class);
		$this->uriFactory = $this->container->instanceOf(UriFactoryInterface::class);
	}
}