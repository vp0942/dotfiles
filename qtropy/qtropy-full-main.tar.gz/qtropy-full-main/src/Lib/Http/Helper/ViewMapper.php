<?php

namespace Walnut\Lib\Http\Helper;

interface ViewMapper {
	/**
	 * @param class-string $className
	 * @return string
	 * @throws ViewTemplateNotFound
	 */
	public function findTemplate(string $className): string;
}