<?php

namespace Walnut\Lib\Http\Helper;

use Walnut\Lib\HttpMapper\ResponseRenderer;
use Walnut\Lib\TemplateRenderer\TemplateRenderer;

readonly final class TemplateRendererAdapter implements ResponseRenderer {
	public function __construct(
		private TemplateRenderer $templateRenderer
	) {}

	public function render(string $templateName, mixed $viewModel = null): string {
		return $this->templateRenderer->render($templateName, $viewModel);
	}
}