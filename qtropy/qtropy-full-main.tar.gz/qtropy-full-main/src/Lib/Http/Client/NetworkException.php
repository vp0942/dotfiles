<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\Client;

use Psr\Http\Client\NetworkExceptionInterface;

final class NetworkException extends ClientException implements NetworkExceptionInterface {}