<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\Client;

use CurlHandle;
use InvalidArgumentException;
use Psr\Http\Client\ClientInterface;
use Psr\Http\Client\NetworkExceptionInterface;
use Psr\Http\Client\RequestExceptionInterface;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\StreamFactoryInterface;
use RuntimeException;
use UnexpectedValueException;

/**
 * @psalm-suppress UnusedClosureParam
 */
final class Client implements ClientInterface {
	private ?CurlHandle $handle = null;

	public function __construct(
		private readonly ResponseFactoryInterface $responseFactory,
		private readonly StreamFactoryInterface $streamFactory,
		private readonly array $curlOptions = []
	) {}

	/**
	 * Release resources if still active.
	 */
	public function __destruct() {
		if ($this->handle) {
			curl_close($this->handle);
		}
	}

	/**
	 * Sends a PSR-7 request and returns a PSR-7 response.
	 *
	 * @param RequestInterface $request
	 *
	 * @return ResponseInterface
	 *
	 * @throws InvalidArgumentException  For invalid header names or values.
	 * @throws RuntimeException          If creating the body stream fails.
	 * @throws NetworkExceptionInterface In case of network problems.
	 * @throws RequestExceptionInterface On invalid request.
	 */
	public function sendRequest(RequestInterface $request): ResponseInterface {
		$response = $this->initResponse();
		$requestOptions = $this->prepareRequestOptions($request,
			$this->getHeaderFunction($response),
			$this->getBodyFunction($response),
		);

		/**
         * @psalm-suppress DocblockTypeContradiction
         */
		if ($this->handle) {
			curl_reset($this->handle);
		} else {
			$this->handle = curl_init();
		}
		if (!$this->handle) {
			throw new RequestException($request, "Unable to initialize cURL");
		}

		curl_setopt_array($this->handle, $requestOptions);
		if (!curl_exec($this->handle)) {
			$errno = curl_errno($this->handle);
			switch ($errno) {
				case CURLE_OK:
					break;
				case CURLE_COULDNT_RESOLVE_PROXY:
				case CURLE_COULDNT_RESOLVE_HOST:
				case CURLE_COULDNT_CONNECT:
				case CURLE_OPERATION_TIMEOUTED:
				case CURLE_SSL_CONNECT_ERROR:
					throw new NetworkException($request, curl_error($this->handle));
				default:
					throw new RequestException($request, curl_error($this->handle));
			}
		}

		$response->getBody()->seek(0);
		return $response;
	}

	private function applyStatusData(string $statusData, ResponseInterface $response): ResponseInterface {
		$parts = explode(' ', $statusData, 3);
		if (count($parts) < 2 || stripos($parts[0], 'http/') !== 0) {
			throw new InvalidArgumentException(
				sprintf('"%s" is not a valid HTTP status line', $statusData)
			);
		}
		$reasonPhrase = $parts[2] ?? '';
		return $response
			->withStatus((int)$parts[1], $reasonPhrase)
			->withProtocolVersion(substr($parts[0], 5));
	}

	private function applyHeaderData(string $headerData, ResponseInterface $response): ResponseInterface {
		$parts = explode(':', $headerData, 2);
		if (count($parts) !== 2) {
			throw new InvalidArgumentException(
				sprintf('"%s" is not a valid HTTP header line', $headerData)
			);
		}
		$name = trim($parts[0]);
		$value = trim($parts[1]);
		return $response->hasHeader($name) ?
			$response->withAddedHeader($name, $value) :
			$response->withHeader($name, $value);
	}

	/** @noinspection PhpUnusedParameterInspection */
	private function getHeaderFunction(ResponseInterface &$response): callable {
		/**
		 * @param mixed $ch
		 * @param string $data
		 * @return int
		 */
		return function (mixed $ch, string $data) use (&$response): int {
			/**
			 * @var ResponseInterface $response
			 */
			$str = trim($data);
			if ($str !== '') {
				$response = stripos($str, 'http/') === 0 ?
					$this->applyStatusData($str, $response) :
					$this->applyHeaderData($str, $response);
			}
			return strlen($data);
		};
	}

	/** @noinspection PhpUnusedParameterInspection */
	private function getBodyFunction(ResponseInterface $response): callable {
		/**
		 * @param mixed $ch
		 * @param string $data
		 * @return int
		 */
		return static function(mixed $ch, string $data) use ($response): int {
			$response->getBody()->write($data);
			return strlen($data);
		};
	}

	/**
	 * Create builder to use for building response object.
	 *
	 * @return ResponseInterface
	 */
	private function initResponse(): ResponseInterface {
		$body = $this->streamFactory->createStreamFromFile('php://temp', 'w+b');

		return $this->responseFactory->createResponse()->withBody($body);
	}

	/**
	 * Update cURL options for given request and hook in the response builder.
	 *
	 * @param RequestInterface $request         Request on which to create options.
	 * @param callable $headerFunction
	 * @param callable $bodyFunction
	 *
	 * @return array cURL options based on request.
	 *
	 * @throws InvalidArgumentException  For invalid header names or values.
	 * @throws RuntimeException          If can not read body.
	 * @throws RequestExceptionInterface On invalid request.
	 */
	private function prepareRequestOptions(
		RequestInterface $request,
		callable $headerFunction,
		callable $bodyFunction
	): array {
		$curlOptions = $this->curlOptions;

		try {
			$curlOptions[CURLOPT_HTTP_VERSION] = $this->getProtocolVersion(
				$request->getProtocolVersion()
			);
		} catch (UnexpectedValueException $e) {
			throw new RequestException($request, $e->getMessage());
		}
		$curlOptions[CURLOPT_URL] = (string)$request->getUri();
		$curlOptions[CURLOPT_HEADERFUNCTION] = $headerFunction;
		$curlOptions[CURLOPT_WRITEFUNCTION] = $bodyFunction;

		$curlOptions = $this->addRequestBodyOptions($request, $curlOptions);

		$curlOptions[CURLOPT_HTTPHEADER] = $this->createHeaders($request, $curlOptions);

		if ($request->getUri()->getUserInfo()) {
			$curlOptions[CURLOPT_USERPWD] = $request->getUri()->getUserInfo();
		}
		return $curlOptions;
	}

	/**
	 * Return cURL constant for specified HTTP version.
	 *
	 * @param string $requestVersion HTTP version ("1.0", "1.1" or "2.0").
	 *
	 * @return int Respective CURL_HTTP_VERSION_x_x constant.
	 *
	 * @throws UnexpectedValueException If unsupported version requested.
	 */
	private function getProtocolVersion(string $requestVersion): int {
		switch ($requestVersion) {
			case '1.0':
				return CURL_HTTP_VERSION_1_0;
			case '1.1':
				return CURL_HTTP_VERSION_1_1;
			case '2.0':
				if (defined('CURL_HTTP_VERSION_2_0')) {
					return CURL_HTTP_VERSION_2_0;
				}
				throw new UnexpectedValueException('libcurl 7.33 needed for HTTP 2.0 support');
		}
		return CURL_HTTP_VERSION_NONE;
	}

	/**
	 * Add request body related cURL options.
	 *
	 * @param RequestInterface $request     Request on which to create options.
	 * @param array            $curlOptions Options created by prepareRequestOptions().
	 *
	 * @return array cURL options based on request.
	 */
	private function addRequestBodyOptions(RequestInterface $request, array $curlOptions): array {
		/*
		 * Some HTTP methods cannot have payload:
		 *
		 * - GET — cURL will automatically change method to PUT or POST if we set CURLOPT_UPLOAD or
		 *   CURLOPT_POSTFIELDS.
		 * - HEAD — cURL treats HEAD as GET request with a same restrictions.
		 * - TRACE — According to RFC7231: a client MUST NOT send a message body in a TRACE request.
		 */
		if (!in_array($request->getMethod(), ['GET', 'HEAD', 'TRACE'], true)) {
			$body = $request->getBody();
			$bodySize = $body->getSize();
			if ($bodySize !== 0) {
				if ($body->isSeekable()) {
					$body->rewind();
				}

				// Message has non empty body.
				if ($bodySize === null || $bodySize > 1024 * 1024) {
					// Avoid full loading large or unknown size body into memory
					$curlOptions[CURLOPT_UPLOAD] = true;
					if ($bodySize !== null) {
						$curlOptions[CURLOPT_INFILESIZE] = $bodySize;
					}
					/**
					 * @param resource $ch
					 * @param resource $fd
					 * @param int $length
					 * @return string
					 */
					$curlOptions[CURLOPT_READFUNCTION] = static fn(mixed $ch, mixed $fd, int $length): string =>
						$body->read($length);
				} else {
					// Small body can be loaded into memory
					$curlOptions[CURLOPT_POSTFIELDS] = (string)$body;
				}
			}
		}

		if ($request->getMethod() === 'HEAD') {
			// This will set HTTP method to "HEAD".
			$curlOptions[CURLOPT_NOBODY] = true;
		} elseif ($request->getMethod() !== 'GET') {
			// GET is a default method. Other methods should be specified explicitly.
			$curlOptions[CURLOPT_CUSTOMREQUEST] = $request->getMethod();
		}

		return $curlOptions;
	}

	/**
	 * Create headers array for CURLOPT_HTTPHEADER.
	 *
	 * @param RequestInterface $request     Request on which to create headers.
	 * @param array            $curlOptions Options created by prepareRequestOptions().
	 *
	 * @return string[]
	 */
	private function createHeaders(RequestInterface $request, array $curlOptions): array {
		$curlHeaders = [];
		foreach ($request->getHeaders() as $name => $values) {
			$header = strtolower((string)$name);
			if ($header === 'expect') {
				// curl-client does not support "Expect-Continue", so dropping "expect" headers
				continue;
			}
			if ($header === 'content-length') {
				if (array_key_exists(CURLOPT_POSTFIELDS, $curlOptions)) {
					// Small body content length can be calculated here.
					$values = [strlen((string)($curlOptions[CURLOPT_POSTFIELDS] ?? null))];
				} elseif (!array_key_exists(CURLOPT_READFUNCTION, $curlOptions)) {
					// Else if there is no body, forcing "Content-length" to 0
					$values = [0];
				}
			}
			foreach ($values as $value) {
				$curlHeaders[] = $name . ': ' . $value;
			}
		}
		/*
		 * curl-client does not support "Expect-Continue", but cURL adds "Expect" header by default.
		 * We can not suppress it, but we can set it to empty.
		 */
		$curlHeaders[] = 'Expect:';

		return $curlHeaders;
	}

}