<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\Client;

use Psr\Http\Client\ClientExceptionInterface;
use Psr\Http\Message\RequestInterface;
use RuntimeException;
use Throwable;

class ClientException extends RuntimeException implements ClientExceptionInterface {

	/**
	 * ClientException constructor.
	 * @param RequestInterface $request
	 * @param string $message [optional] The Exception message to throw.
     * @param int $code [optional] The Exception code.
	 * @param ?Throwable $previous [optional] The previous throwable used for the exception chaining.
	 */
	public function __construct(private readonly RequestInterface $request, $message = "", $code = 0, Throwable $previous = null) {
		parent::__construct($message, $code, $previous);
	}

	public function getRequest(): RequestInterface {
		return $this->request;
	}
	
}