<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\Client;

use Psr\Http\Client\RequestExceptionInterface;

final class RequestException extends ClientException implements RequestExceptionInterface {}