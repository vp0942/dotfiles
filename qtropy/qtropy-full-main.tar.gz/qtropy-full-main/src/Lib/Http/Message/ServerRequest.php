<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\Message;

use InvalidArgumentException;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\UriInterface;
use Walnut\Lib\Http\Message\Helper\RequestHelper;

/**
 * Server-side HTTP request
 *
 * Extends the Request definition to add methods for accessing incoming data,
 * specifically server parameters, cookies, matched path parameters, query
 * string arguments, body parameters, and upload file information.
 *
 * "Attributes" are discovered via decomposing the request (and usually
 * specifically the URI path), and typically will be injected by the application.
 *
 * Requests are considered immutable; all methods that might change state are
 * implemented such that they retain the internal state of the current
 * message and return a new instance that contains the changed state.
 * @package Walnut\Lib\Http\Message
 */
final class ServerRequest implements ServerRequestInterface {
	use RequestHelper;

    /**
     * @var array
     */
	private array $attributes = [];

    /**
     * @var array
     */
	private array $cookieParams = [];

    /**
     * @var array|object|null
     */
	private object|null|array $parsedBody = null;

    /**
     * @var array
     */
	private array $queryParams = [];

    /**
     * @var array
     */
	private array $serverParams;

    /**
     * @var UploadedFile[]
     */
	private array $uploadedFiles = [];

	/**
	 * @param string $method HTTP method
	 * @param string|UriInterface $uri URI
	 * @param array $headers Request headers
	 * @param mixed $body Request body
	 * @param string $version Protocol version
	 * @param array $serverParams Typically the $_SERVER superglobal
	 */
    public function __construct(
	    string $method, UriInterface|string $uri,
	    array $headers = [],
	    mixed $body = null,
	    string $version = '1.1',
	    array $serverParams = []
    ) {
	    $this->initializeRequest($method, $uri, $headers, $body, $version);
        $this->serverParams = $serverParams;
    }

    public function getServerParams(): array {
        return $this->serverParams;
    }

    public function getUploadedFiles(): array {
        return $this->uploadedFiles;
    }

	/**
	 * @param array $uploadedFiles
	 * @return static
	 */
    public function withUploadedFiles(array $uploadedFiles): self {
        $request = clone $this;
        $request->uploadedFiles = $uploadedFiles;

        return $request;
    }

    public function getCookieParams(): array {
        return $this->cookieParams;
    }

	/**
	 * @param array $cookies
	 * @return static
	 */
    public function withCookieParams(array $cookies): self {
        $request = clone $this;
        $request->cookieParams = $cookies;

        return $request;
    }

    public function getQueryParams(): array {
        return $this->queryParams;
    }

	/**
	 * @param array $query
	 * @return static
	 */
    public function withQueryParams(array $query): self {
        $request = clone $this;
        $request->queryParams = $query;

        return $request;
    }

    public function getParsedBody() {
        return $this->parsedBody;
    }

	/**
	 * @param array|object|null $data
	 * @return static
	 * @noinspection NotOptimalIfConditionsInspection
	 */
    public function withParsedBody($data): self {
	    /**
          * @psalm-suppress DocblockTypeContradiction
          */
    	if (!(is_null($data) || is_array($data) || is_object($data))) {
    		throw new InvalidArgumentException("Invalid parsed body type");
	    }
        $request = clone $this;
        $request->parsedBody = $data;

        return $request;
    }

    public function getAttributes(): array {
        return $this->attributes;
    }

    public function getAttribute($name, $default = null) {
        return $this->attributes[$name] ?? $default;
    }

	/**
	 * @param string $name The attribute name.
     * @param mixed $value The value of the attribute.
	 * @return static
	 */
    public function withAttribute($name, $value): self {
        $request = clone $this;
        $request->attributes[$name] = $value;

        return $request;
    }

	/**
	 * @param string $name
	 * @return static
	 */
    public function withoutAttribute($name): self {
        if (!array_key_exists($name, $this->attributes)) {
            return $this;
        }

        $request = clone $this;
        unset($request->attributes[$name]);

        return $request;
    }
}
