<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\Message\Helper;

use InvalidArgumentException;
use Psr\Http\Message\StreamInterface;
use Psr\Http\Message\UriInterface;
use Walnut\Lib\Http\Message\Stream;
use Walnut\Lib\Http\Message\Uri;

/**
 * Trait implementing functionality common to requests and responses.
 * @package Walnut\Lib\Http\Message
 */
trait RequestHelper {
	use MessageHelper;

	/** @var string */
	private string $method;

	/** @var string|null */
	private ?string $requestTarget = null;

	/** @var UriInterface */
	private UriInterface $uri;

	public function getRequestTarget(): string {
 	    return $this->requestTarget ?? $this->buildRequestTarget();
    }

	/**
	 * @param mixed $requestTarget
	 * @return static
	 */
    public function withRequestTarget($requestTarget): self {
        if (preg_match('#\s#', $requestTarget)) {
            throw new InvalidArgumentException(
                "Invalid request target provided; cannot contain whitespace: [$requestTarget]"
            );
        }
		//
        $request = clone $this;
        $request->requestTarget = $requestTarget;
        return $request;
    }

	public function getMethod(): string {
		return $this->method;
	}

	/**
	 * @param string $method
	 * @return static
	 */
    public function withMethod($method): self {
	    /**
          * @psalm-suppress RedundantConditionGivenDocblockType
          */
        $this->assertMethod($method);
        //
        $request = clone $this;
        $request->method = $method;
        return $request;
    }

	public function getUri(): UriInterface {
		return $this->uri;
	}

	/**
	 * @param UriInterface $uri
	 * @param bool $preserveHost
	 * @return static
	 */
    public function withUri(UriInterface $uri, $preserveHost = false): self {
        if ($uri === $this->uri) {
            return $this;
        }
		//
        $request = clone $this;
        $request->uri = $uri;

        if (!$preserveHost || !isset($this->headerMapping['host'])) {
            $request->updateHostFromUri();
        }

        return $request;
    }

	private function updateHostFromUri(): void {
		$host = $this->uri->getHost();

		if ($host === '') {
            return;
		}

		if (($port = $this->uri->getPort()) !== null) {
			$host .= ':' . $port;
		}

		if (isset($this->headerMapping['host'])) {
			$header = $this->headerMapping['host'];
		} else {
			$header = 'Host';
			$this->headerMapping['host'] = 'Host';
		}
		// Ensure Host is the first header.
		// See: http://tools.ietf.org/html/rfc7230#section-5.4
		$this->headers = [$header => [$host]] + $this->headers;
	}

	/**
	* @param mixed $method
	*/
	private function assertMethod($method): void {
        if (!is_string($method) || $method === '') {
			throw new InvalidArgumentException('Method must be a non-empty string.');
		}
	}

	private function buildRequestTarget(): string {
		$target = $this->uri->getPath();
		if ($target === '') {
			$target = '/';
		}
		if ($this->uri->getQuery() !== '') {
            $target .= '?' . $this->uri->getQuery();
		}
		return $target;
	}

	/**
	 * @param string $method HTTP method
	 * @param string|UriInterface $uri URI
	 * @param array $headers Request headers
	 * @param string|resource|StreamInterface|null $body Request body
	 * @param string $version ProtocolVersion version
	 */
    private function initializeRequest(
        string $method,
        $uri,
        array $headers = [],
        $body = null,
        string $version = '1.1'
    ): void {
	    /**
          * @psalm-suppress RedundantCondition
          */
        $this->assertMethod($method);
        if (!($uri instanceof UriInterface)) {
            $uri = new Uri($uri);
        }

        $this->method = strtoupper($method);
        $this->uri = $uri;
        $this->setHeaders($headers);
        $this->protocolVersion = $version;

        if (!array_key_exists('host', $this->headerMapping)) {
            $this->updateHostFromUri();
        }

        if ($body !== '' && $body !== null) {
	        $this->stream = is_resource($body) ? Stream::fromResource($body) :
				Stream::fromString((string)$body);
        }
    }


}
