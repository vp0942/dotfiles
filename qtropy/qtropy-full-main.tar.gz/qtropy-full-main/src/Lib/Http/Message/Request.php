<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\Message;

use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\StreamInterface;
use Psr\Http\Message\UriInterface;
use Walnut\Lib\Http\Message\Helper\RequestHelper;

/**
 * PSR-7 request implementation.
 * @package Walnut\Lib\Http\Message
 */
final class Request implements RequestInterface {
    use RequestHelper;

	/**
	 * @param string $method HTTP method
	 * @param string|UriInterface $uri URI
	 * @param array $headers Request headers
	 * @param string|resource|StreamInterface|null $body Request body
	 * @param string $version ProtocolVersion version
	 */
    public function __construct(
        string $method,
        $uri,
        array $headers = [],
        $body = null,
        string $version = '1.1'
    ) {
	    $this->initializeRequest($method, $uri, $headers, $body, $version);
    }

}
