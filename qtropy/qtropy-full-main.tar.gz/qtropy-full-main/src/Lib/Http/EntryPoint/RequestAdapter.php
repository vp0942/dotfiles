<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\EntryPoint;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

interface RequestAdapter {
	public function fromInput(): ServerRequestInterface;
	public function toOutput(ResponseInterface $response): void;
}
