<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\EntryPoint;

use Psr\Http\Server\RequestHandlerInterface;

final readonly class EntryPoint {
	public function __construct(
		private RequestAdapter          $requestAdapter,
		private RequestHandlerInterface $requestHandler
	) {}

	public function execute(): void {
		$this->requestAdapter->toOutput(
			$this->requestHandler->handle(
				$this->requestAdapter->fromInput()
			)
		);
	}
}

