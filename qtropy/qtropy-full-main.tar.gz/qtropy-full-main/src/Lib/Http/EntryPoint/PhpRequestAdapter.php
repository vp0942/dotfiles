<?php

declare(strict_types=1);

namespace Walnut\Lib\Http\EntryPoint;

use InvalidArgumentException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestFactoryInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\StreamFactoryInterface;
use Psr\Http\Message\StreamInterface;
use Psr\Http\Message\UploadedFileFactoryInterface;
use Psr\Http\Message\UploadedFileInterface;
use Psr\Http\Message\UriFactoryInterface;
use Psr\Http\Message\UriInterface;

readonly final class PhpRequestAdapter implements RequestAdapter {

	public function __construct(
		private ServerRequestFactoryInterface $serverRequestFactory,
		private StreamFactoryInterface $streamFactory,
		private UriFactoryInterface $uriFactory,
		private UploadedFileFactoryInterface $uploadedFileFactory
	) {}

	/**
	  * Return a ServerRequest populated with superglobals:
	  * $_GET
	  * $_POST
	  * $_COOKIE
	  * $_FILES
	  * $_SERVER
	  * @noinspection SpellCheckingInspection
	  */
	public function fromInput(): ServerRequestInterface {
		$method = (string)($_SERVER['REQUEST_METHOD'] ?? 'GET');
		/**
		 * @var array<string, string>
		 */
		$headers = getallheaders();
		$uri = $this->getUriFromGlobals();
		$body = $this->streamFactory->createStreamFromFile('php://input', 'r+');
		$protocol = isset($_SERVER['SERVER_PROTOCOL']) ? str_replace('HTTP/', '', (string)$_SERVER['SERVER_PROTOCOL']) : '1.1';
		$serverRequest = $this->serverRequestFactory->createServerRequest(
			$method, $uri, $_SERVER
		);
		foreach($headers as $headerKey => $headerValue) {
			$serverRequest = $serverRequest->withHeader($headerKey, $headerValue);
		}
		return $serverRequest
			->withBody($body)
			->withProtocolVersion($protocol)
            ->withCookieParams($_COOKIE)
			->withQueryParams($_GET)
			->withParsedBody($this->getParsedBody())
			->withUploadedFiles($this->getUploadedFiles());
	}

	private function getUploadedFiles(): array {
		if ($_SERVER['REQUEST_METHOD'] !== 'PATCH' && $_SERVER['REQUEST_METHOD'] !== 'PUT') {
			return $this->normalizeFiles($_FILES);
		}
		if (($_SERVER['CONTENT_TYPE'] ?? '') === 'application/x-www-form-urlencoded') {
			return [];
		}
		if (($_SERVER['CONTENT_TYPE'] ?? '') && preg_match('#multipart/form-data; boundary=(.*?)$#', (string)($_SERVER['CONTENT_TYPE'] ?? ''), $matches)) {
			$boundary = $matches[1];
			return $this->extractFileData(file_get_contents('php://input'), $boundary);
		}
		return [];
	}

	private function getParsedBody(): array|object {
		if (($_SERVER['CONTENT_TYPE'] ?? '') === 'application/json') {
			/**
			 * @var object
			 */
			return json_decode(file_get_contents('php://input')/*, true*/) ?? [];
		}
		if ($_SERVER['REQUEST_METHOD'] !== 'PATCH' && $_SERVER['REQUEST_METHOD'] !== 'PUT') {
			return $_POST;
		}
		if (($_SERVER['CONTENT_TYPE'] ?? '') === 'application/x-www-form-urlencoded') {
			parse_str(file_get_contents('php://input'), $results);
			return $results;
		}
		if (($_SERVER['CONTENT_TYPE'] ?? '') && preg_match('#multipart/form-data; boundary=(.*?)$#', (string)($_SERVER['CONTENT_TYPE'] ?? ''), $matches)) {
			$boundary = $matches[1];
			return $this->extractPostData(file_get_contents('php://input'), $boundary);
		}
		return [];
	}

	private function extractFileData(string $content, string $boundary): array {
		$parts = array_filter(explode('--' . $boundary, $content));
		$result = [];
		foreach($parts as $part) {
			$split = explode("\r\n\r\n", $part, 2);
			$headers = $split[0];
			$body = $split[1] ?? '';
			if (preg_match("#Content-Disposition: form-data; name=\"(.*?)\"#", $headers, $matches)) {
				$name = $matches[1];
				if(str_contains($headers, 'filename=')) {
					$body = rtrim($body);
					$result[$name] = $this->uploadedFileFactory->createUploadedFile(
						$this->streamFactory->createStream($body),
			            strlen($body),
			            0,
			            '', //$value['name'],
			            '' //$value['type']
			        );
				}
			}
		}
		return $result;
	}

	private function extractPostData(string $content, string $boundary): array {
		$parts = array_filter(explode('--' . $boundary, $content));
		$result = [];
		foreach($parts as $part) {
			$split = explode("\r\n\r\n", $part, 2);
			$headers = $split[0];
			$body = $split[1] ?? '';
			if (preg_match("#Content-Disposition: form-data; name=\"(.*?)\"#", $headers, $matches)) {
				$name = $matches[1];
				if(!str_contains($headers, 'filename=')) {
					$result[] = $name . '=' . urlencode(rtrim($body));
				}
			}
		}
		parse_str(implode('&', $result), $post);
		return $post;
	}

	public function toOutput(ResponseInterface $response): void {
		$version = $response->getProtocolVersion();
		$status = $response->getStatusCode();
		$reason = $response->getReasonPhrase();
		header("HTTP/$version $status $reason");
		foreach($response->getHeaders() as $headerName => $headers) {
			foreach($headers as $header) {
				header("$headerName: $header");
			}
		}
		$stream = $response->getBody();
		if ($stream->isSeekable()) {
			$stream->rewind();
		}
		echo $stream->getContents();
	}

	/**
	 * Return an UploadedFile instance array.
	 *
	 * @param array $files An array which respect $_FILES structure
	 *
	 * @return array<array|UploadedFileInterface>
	 * @throws InvalidArgumentException for unrecognized values
	 */
    public function normalizeFiles(array $files): array {
        $normalized = [];
	    /**
	     * @var array<UploadedFileInterface|array> $files
	     */
        foreach ($files as $key => $value) {
            if ($value instanceof UploadedFileInterface) {
                $normalized[$key] = $value;
            } elseif (is_array($value)) {
                $normalized[$key] = isset($value['tmp_name']) ?
	                $this->createUploadedFileFromSpec($value) :
	                $this->normalizeFiles($value);
            } else {
                throw new InvalidArgumentException('Invalid value in files specification');
            }
        }
        return $normalized;
    }

    /**
     * Create and return an UploadedFile instance from a $_FILES specification.
     *
     * If the specification represents an array of values, this method will
     * delegate to normalizeNestedFileSpec() and return that return value.
     *
     * @param array $value $_FILES struct
     *
     * @return UploadedFileInterface|array
     */
    private function createUploadedFileFromSpec(array $value): array|UploadedFileInterface {
        if (is_array($value['tmp_name'])) {
            return $this->normalizeNestedFileSpec($value);
        }
	    /**
	     * @var array{tmp_name: StreamInterface, size: int, error: int, name: string, type: string} $value
	     */
        return $this->uploadedFileFactory->createUploadedFile(
            is_string($value['tmp_name']) ?
	            $this->streamFactory->createStream($value['tmp_name']) : $value['tmp_name'],
            $value['size'],
            $value['error'],
	        $value['name'],
	        $value['type']
        );
    }

	/**
	 * Normalize an array of file specifications.
	 *
	 * Loops through all nested files and returns a normalized array of
	 * UploadedFileInterface instances.
	 *
	 * @param array $files
	 * @return array
	 */
    private function normalizeNestedFileSpec(array $files = []): array {
        $normalizedFiles = [];
	    /**
	     * @var array{tmp_name: array, size: array, error: array, name: array, type: array} $files
	     */
        foreach (array_keys($files['tmp_name']) as $key) {
            $spec = [
                'tmp_name' => $files['tmp_name'][$key],
                'size'     => $files['size'][$key],
                'error'    => $files['error'][$key],
                'name'     => $files['name'][$key],
                'type'     => $files['type'][$key],
            ];
            $normalizedFiles[$key] = $this->createUploadedFileFromSpec($spec);
        }

        return $normalizedFiles;
    }

	/**
	 * @param string $authority
	 * @return array{?string, ?int}
	 */
    private static function extractHostAndPortFromAuthority(string $authority): array {
        $uri = 'http://' . $authority;
        $parts = parse_url($uri);
        if ($parts === false) {
            return [null, null];
        }

        $host = $parts['host'] ?? null;
        $port = $parts['port'] ?? null;

        return [$host, $port];
    }

    /**
     * Get a Uri populated with values from $_SERVER.
     */
    public function getUriFromGlobals(): UriInterface {
        $uri = $this->uriFactory->createUri();

        $uri = $uri->withScheme(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http');

        $hasPort = false;
        if (isset($_SERVER['HTTP_HOST'])) {
            [$host, $port] = self::extractHostAndPortFromAuthority((string)($_SERVER['HTTP_HOST'] ?? ''));
            if ($host !== null) {
                $uri = $uri->withHost($host);
            }

            if ($port !== null) {
                $hasPort = true;
                $uri = $uri->withPort($port);
            }
        } elseif (isset($_SERVER['SERVER_NAME'])) {
            $uri = $uri->withHost((string)$_SERVER['SERVER_NAME']);
        } elseif (isset($_SERVER['SERVER_ADDR'])) {
            $uri = $uri->withHost((string)$_SERVER['SERVER_ADDR']);
        }

        if (!$hasPort && isset($_SERVER['SERVER_PORT'])) {
            $uri = $uri->withPort((int)$_SERVER['SERVER_PORT']);
        }

        $hasQuery = false;
        if (isset($_SERVER['REQUEST_URI'])) {
            $requestUriParts = explode('?', (string)$_SERVER['REQUEST_URI'], 2);
			$scriptDir = dirname((string)$_SERVER['SCRIPT_NAME']);
			if ($scriptDir !== '/' && str_starts_with($requestUriParts[0], $scriptDir)) {
				$requestUriParts[0] = substr($requestUriParts[0], strlen($scriptDir));
			}
            $uri = $uri->withPath($requestUriParts[0]);
            if (isset($requestUriParts[1])) {
                $hasQuery = true;
                $uri = $uri->withQuery($requestUriParts[1]);
            }
        }

        if (!$hasQuery && isset($_SERVER['QUERY_STRING'])) {
            $uri = $uri->withQuery((string)$_SERVER['QUERY_STRING']);
        }

        return $uri;
    }
}