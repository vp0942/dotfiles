<?php

namespace Walnut\Lib\DecorAuto\Decorator;

final readonly class DecoratorContext {
	public function __construct(
		public object $instance,
		public string $methodName,
		public array  $parameters,
	) {}
}
