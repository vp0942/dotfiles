<?php

namespace Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint;

use Walnut\Lib\DecorAuto\Decorator\MethodFilter\AnyMethodFilter;
use Walnut\Lib\DecorAuto\Decorator\MethodFilter\MethodFilter;
use Walnut\Lib\DecorAuto\Decorator\MethodFilter\WhitelistMethodFilter;

abstract readonly class InsertionPoint {
	public MethodFilter $methodFilter;
	public function __construct(string|MethodFilter $methodFilter = new AnyMethodFilter) {
		$this->methodFilter = is_string($methodFilter) ?
			new WhitelistMethodFilter($methodFilter) : $methodFilter;
	}
}