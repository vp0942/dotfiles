<?php

namespace Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint;

use Attribute;

#[Attribute]
final readonly class Before extends InsertionPoint {}