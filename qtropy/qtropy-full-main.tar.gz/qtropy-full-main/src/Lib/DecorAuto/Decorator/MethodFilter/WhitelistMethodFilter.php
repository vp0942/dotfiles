<?php

namespace Walnut\Lib\DecorAuto\Decorator\MethodFilter;

final readonly class WhitelistMethodFilter implements MethodFilter {
	/**
	 * @var string[]
	 */
	private array $allowedMethods;

	public function __construct(string ... $allowedMethods) {
		$this->allowedMethods = $allowedMethods;
	}

	public function matches(string $methodName, string $interfaceName): bool {
		return in_array($methodName, $this->allowedMethods, true);
	}
}
