<?php

namespace Walnut\Lib\DecorAuto\Decorator\MethodFilter;

interface MethodFilter {
	public function matches(string $methodName, string $interfaceName): bool;
}
