<?php

namespace Walnut\Lib\DecorAuto\Decorator\MethodFilter;

final readonly class AnyMethodFilter implements MethodFilter {
	public function matches(string $methodName, string $interfaceName): bool {
		return true;
	}
}
