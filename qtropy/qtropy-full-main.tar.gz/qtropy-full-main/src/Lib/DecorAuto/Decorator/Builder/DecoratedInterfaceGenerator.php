<?php

namespace Walnut\Lib\DecorAuto\Decorator\Builder;

use Walnut\Lib\DecorAuto\Implementation\Builder\CodeBuilder;
use Walnut\Lib\DecorAuto\Implementation\Model\InterfaceImplementation;
use Walnut\Lib\DecorAuto\Implementation\NameGenerator\ClassNameGenerator;
use Walnut\Lib\DecorAuto\InterfaceModel\Builder\InterfaceModelBuilder;
use Walnut\Lib\DecorAuto\InterfaceModel\Builder\InterfaceModelBuilderException;

final readonly class DecoratedInterfaceGenerator {
	public function __construct(
		private DecoratorModelBuilder     $decoratorModelBuilder,
		private InterfaceModelBuilder     $interfaceModelBuilder,
		private DecoratedInterfaceBuilder $decoratedInterfaceBuilder,
		private ClassNameGenerator        $classNameGenerator,
	) {}

	/**
	 * @param class-string $interfaceName
	 * @param class-string $decoratorClassName
	 * @return InterfaceImplementation
	 * @throws DecoratedInterfaceBuilderException
	 */
	public function getDecoratedInterface(string $interfaceName, string $decoratorClassName): InterfaceImplementation {
		try {
			return $this->buildDecoratedInterface($interfaceName, $decoratorClassName);
		} catch (DecoratorModelBuilderException|InterfaceModelBuilderException $ex) {
			// @codeCoverageIgnoreStart
			throw new DecoratedInterfaceBuilderException(
				"Builder error: " . $ex->getMessage(),
				previous: $ex
			);
			// @codeCoverageIgnoreEnd
		}
	}

	/**
	 * @param class-string $interfaceName
	 * @param class-string $decoratorClassName
	 * @return InterfaceImplementation
	 * @throws DecoratedInterfaceBuilderException|DecoratorModelBuilderException|InterfaceModelBuilderException
	 */
	private function buildDecoratedInterface(string $interfaceName, string $decoratorClassName): InterfaceImplementation {
		$interfaceModel = $this->interfaceModelBuilder->getInterfaceModel($interfaceName);
		$decoratorModel = $this->decoratorModelBuilder->getDecoratorModel($decoratorClassName);
		$methodDecorator = new MethodDecorator($decoratorModel, $interfaceName, new CodeBuilder);

		$interfaceName = $interfaceModel->className;

		$methods = [];
		foreach($interfaceModel->methods as $method) {
			$methods[] = $methodDecorator->implementMethod($method);
		}
		$methods = implode(PHP_EOL, $methods);

		$decoratedClassName = $this->classNameGenerator
			->generateClassName($interfaceName, $decoratorClassName);

		return $this->decoratedInterfaceBuilder->build(
			$decoratedClassName,
			$interfaceName,
			$decoratorClassName,
			$methods
		);
	}
}