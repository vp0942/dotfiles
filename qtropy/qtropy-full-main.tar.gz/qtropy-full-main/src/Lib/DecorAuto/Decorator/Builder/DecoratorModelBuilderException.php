<?php

namespace Walnut\Lib\DecorAuto\Decorator\Builder;

use RuntimeException;

final class DecoratorModelBuilderException extends RuntimeException {}