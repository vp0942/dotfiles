<?php

namespace Walnut\Lib\DecorAuto\Decorator\Builder;

use Walnut\Lib\DecorAuto\Decorator\DecoratorContext;
use Walnut\Lib\DecorAuto\Implementation\Builder\InterfaceImplementationBuilder;
use Walnut\Lib\DecorAuto\Implementation\Model\InterfaceImplementation;

final readonly class DecoratedInterfaceDefaultBuilder implements DecoratedInterfaceBuilder {
	public function __construct(
		private InterfaceImplementationBuilder $interfaceImplementationBuilder
	) {}

	/**
	 * @param class-string $decoratedClassName
	 * @param class-string $sourceInterfaceName
	 * @param class-string $decoratorClassName
	 * @param string $classMethods
	 * @return InterfaceImplementation
	 */
	public function build(
		string $decoratedClassName,
		string $sourceInterfaceName,
		string $decoratorClassName,
		string $classMethods
	): InterfaceImplementation {
		$implementation = $this->interfaceImplementationBuilder->build(
			$decoratedClassName,
			$sourceInterfaceName,
			[
				'instance' => "\\$sourceInterfaceName",
				'decorator' => "\\$decoratorClassName"
			],
			$classMethods
		);

		$sourceCode = $implementation->sourceCode;
		if (str_contains($sourceCode, DecoratorContext::class)) {
			$sourceCode = str_replace([
				'new \\' . DecoratorContext::class,
				'final class'
			], [
				'new DecoratorContext',
				'use ' . DecoratorContext::class . ';' . PHP_EOL . 'final class'
			], $sourceCode);
		}

		return new InterfaceImplementation(
			$decoratedClassName,
			$sourceCode
		);
	}
}