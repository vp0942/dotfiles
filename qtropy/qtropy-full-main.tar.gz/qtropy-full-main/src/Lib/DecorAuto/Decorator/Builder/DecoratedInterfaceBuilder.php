<?php

namespace Walnut\Lib\DecorAuto\Decorator\Builder;

use Walnut\Lib\DecorAuto\Implementation\Model\InterfaceImplementation;

interface DecoratedInterfaceBuilder {
	/**
	 * @param class-string $decoratedClassName
	 * @param class-string $sourceInterfaceName
	 * @param class-string $decoratorClassName
	 * @param string $classMethods
	 * @return InterfaceImplementation
	 */
	public function build(
		string $decoratedClassName,
		string $sourceInterfaceName,
		string $decoratorClassName,
		string $classMethods
	): InterfaceImplementation;
}