<?php

namespace Walnut\Lib\DecorAuto\Decorator\Builder;

use RuntimeException;

final class DecoratedInterfaceBuilderException extends RuntimeException {}