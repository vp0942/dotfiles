<?php

namespace Walnut\Lib\DecorAuto\Decorator\Builder;

use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\{Around};
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\After;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\AfterReturning;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\AfterThrowing;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\Before;
use Walnut\Lib\DecorAuto\Decorator\Model\{DecoratorMethod, DecoratorModel};
use Walnut\Lib\DecorAuto\Implementation\Builder\CodeBuilder;
use Walnut\Lib\DecorAuto\Implementation\Builder\ImplementationMethodBuilder;
use Walnut\Lib\DecorAuto\InterfaceModel\Model\InterfaceMethod;

final readonly class MethodDecorator implements ImplementationMethodBuilder {
	/**
	 * @param DecoratorModel $decoratorModel
	 * @param class-string $interfaceName
	 * @param CodeBuilder $codeBuilder
	 */
	public function __construct(
		private DecoratorModel $decoratorModel,
		private string         $interfaceName,
		private CodeBuilder    $codeBuilder,
	) {}

	/**
	 * @param array<DecoratorMethod> $decoratorCalls
	 */
	private function addMethodsToBuilder(array $decoratorCalls): void {
		foreach($decoratorCalls as $decoratorCall) {
			$this->codeBuilder->addRow($decoratorCall->toExpression() . ';');
		}
	}

	/**
	 * @return array<string, DecoratorMethod[]>
	 */
	private function generateDecoratorCalls(string $methodName): array {
		$decoratorCalls = [
			After::class => [],
			AfterReturning::class => [],
			AfterThrowing::class => [],
			Around::class => [],
			Before::class => [],
		];
		foreach($this->decoratorModel->methods as $decoratorMethod) {
			if (!$decoratorMethod->insertionPoint->methodFilter->matches($methodName, $this->interfaceName)) {
				continue;
			}
			$decoratorType = $decoratorMethod->insertionPoint::class;
			$decoratorCalls[$decoratorType][] = $decoratorMethod;
		}
		return $decoratorCalls;
	}

	/**
	 * @param InterfaceMethod $method
	 * @param DecoratorMethod[] $decoratorCalls
	 * @return string
	 */
	private function getMainCall(InterfaceMethod $method, array $decoratorCalls): string {
		$mainCall = "\$this->instance->" . $method->callExpression();
		foreach($decoratorCalls as $decoratorCall) {
			$mainCall = str_replace('--callback-placeholder--',
				"fn() => " . $mainCall, $decoratorCall->toExpression());
		}
		return $mainCall;
	}

	public function implementMethod(InterfaceMethod $method): string {
		$retExp = $method->returnType === 'void' ? '' : 'return ';
		$decoratorCalls = $this->generateDecoratorCalls($method->methodName);

		$hasAfter = count($decoratorCalls[After::class]) > 0;
		$hasAfterReturning = count($decoratorCalls[AfterReturning::class]) > 0;
		$hasAfterThrowing = count($decoratorCalls[AfterThrowing::class]) > 0;

		$codeBuilder = $this->codeBuilder->reset()->indentRight();
		$codeBuilder->addRow($method->argumentExpression() . " {")->indentRight();

		$this->addMethodsToBuilder($decoratorCalls[Before::class]);
		if ($hasAfterThrowing || $hasAfter) {
			$codeBuilder->addRow("try {")->indentRight();
		}

		$mainCall = $this->getMainCall($method, $decoratorCalls[Around::class]);
		$codeBuilder->addRow(($hasAfterReturning && $retExp ?
			"\$result = " : $retExp) . $mainCall . ';');

		if ($hasAfterThrowing) {
			$codeBuilder->indentLeft()->addRow("} catch (\Throwable \$throwable) {")->indentRight();
			$this->addMethodsToBuilder($decoratorCalls[AfterThrowing::class]);
			$codeBuilder->addRow('throw $throwable;');
			if (!$hasAfter) {
				$codeBuilder->indentLeft()->addRow("}");
			}
		}
		if ($hasAfter) {
			$codeBuilder->indentLeft()->addRow("} finally {")->indentRight();
			$this->addMethodsToBuilder($decoratorCalls[After::class]);
			$codeBuilder->indentLeft()->addRow("}");
		}
		$this->addMethodsToBuilder($decoratorCalls[AfterReturning::class]);
		if ($hasAfterReturning && $retExp) {
			$codeBuilder->addRow("return \$result;");
		}
		$codeBuilder->indentLeft()->addRow("}");
		$code = $codeBuilder->build();
		if (!$retExp && str_contains($code, '$result')) {
			$code = str_replace('$result', 'null', $code);
		}
		return $code;
	}

}