<?php

namespace Walnut\Lib\DecorAuto\Decorator\Builder;

use Walnut\Lib\DecorAuto\Decorator\Model\DecoratorModel;

interface DecoratorModelBuilder {
	/**
	 * @param class-string $decoratorClassName
	 * @return DecoratorModel
	 * @throws DecoratorModelBuilderException
	 */
	public function getDecoratorModel(string $decoratorClassName): DecoratorModel;
}