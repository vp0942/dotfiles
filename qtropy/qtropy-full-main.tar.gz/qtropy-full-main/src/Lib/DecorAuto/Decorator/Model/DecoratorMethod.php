<?php

namespace Walnut\Lib\DecorAuto\Decorator\Model;

use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\InsertionPoint;

final readonly class DecoratorMethod {
	/**
	 * @var string[]
	 */
	public array $parameters;
	public function __construct(
		public string         $methodName,
		public InsertionPoint $insertionPoint,
		string ... $parameters,
	) {
		$this->parameters = $parameters;
	}

	public function toExpression(): string {
		return sprintf("\$this->decorator->%s(%s)",
			$this->methodName,
			implode(', ', $this->parameters)
		);
	}
}