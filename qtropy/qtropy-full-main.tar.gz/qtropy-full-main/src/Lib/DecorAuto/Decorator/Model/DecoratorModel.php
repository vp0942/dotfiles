<?php

namespace Walnut\Lib\DecorAuto\Decorator\Model;

final readonly class DecoratorModel {
	/**
	 * @var DecoratorMethod[]
	 */
	public array $methods;

	/**
	 * @param class-string $className
	 * @param DecoratorMethod ...$methods
	 */
	public function __construct(
		public string   $className,
		DecoratorMethod ... $methods
	) {
		$this->methods = $methods;
	}
}