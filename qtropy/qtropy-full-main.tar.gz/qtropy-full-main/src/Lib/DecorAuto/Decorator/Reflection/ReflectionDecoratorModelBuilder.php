<?php

namespace Walnut\Lib\DecorAuto\Decorator\Reflection;

use Closure;
use ReflectionAttribute;
use ReflectionClass;
use ReflectionException;
use ReflectionNamedType;
use ReflectionType;
use Throwable;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\{Around};
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\AfterReturning;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\AfterThrowing;
use Walnut\Lib\DecorAuto\Decorator\Attribute\InsertionPoint\InsertionPoint;
use Walnut\Lib\DecorAuto\Decorator\Builder\DecoratorModelBuilder;
use Walnut\Lib\DecorAuto\Decorator\Builder\DecoratorModelBuilderException;
use Walnut\Lib\DecorAuto\Decorator\DecoratorContext;
use Walnut\Lib\DecorAuto\Decorator\Model\DecoratorMethod;
use Walnut\Lib\DecorAuto\Decorator\Model\DecoratorModel;

final readonly class ReflectionDecoratorModelBuilder implements DecoratorModelBuilder {

	/**
	 * @param class-string $decoratorClassName
	 * @return DecoratorModel
	 * @throws DecoratorModelBuilderException
	 */
	public function getDecoratorModel(string $decoratorClassName): DecoratorModel {
		try {
			return $this->buildDecoratorModel($decoratorClassName);
		} catch (ReflectionException $ex) {
			// @codeCoverageIgnoreStart
			throw new DecoratorModelBuilderException(
				"Reflection error: " . $ex->getMessage(),
				previous: $ex
			);
			// @codeCoverageIgnoreEnd
		}
	}

	/**
	 * @param class-string $decoratorClassName
	 * @return DecoratorModel
	 * @throws ReflectionException|DecoratorModelBuilderException
	 */
	private function buildDecoratorModel(string $decoratorClassName): DecoratorModel {
		$r = new ReflectionClass($decoratorClassName);
		$methods = [];
		foreach($r->getMethods() as $reflectionMethod) {
			$a = $reflectionMethod->getAttributes(InsertionPoint::class, ReflectionAttribute::IS_INSTANCEOF)[0] ?? null;
			if ($a) {
				$insertionPoint = $a->newInstance();

				$callbackAllowed = $insertionPoint instanceof Around;
				$resultAllowed = $insertionPoint instanceof AfterReturning;
				$throwableAllowed = $insertionPoint instanceof AfterThrowing;

				$arguments = [];
				foreach($reflectionMethod->getParameters() as $reflectionParameter) {
					$arguments[] = $this->buildParameterExpression(
						$reflectionParameter->getType(),
						$callbackAllowed, $resultAllowed, $throwableAllowed
					);
				}

				$methods[$reflectionMethod->getName()] = new DecoratorMethod(
					$reflectionMethod->getName(),
					$insertionPoint,
					...$arguments
				);
			}
		}
		return new DecoratorModel($decoratorClassName, ...$methods);
	}

	private function buildParameterExpression(
		?ReflectionType $type, bool $callbackAllowed, bool $resultAllowed, bool $throwableAllowed
	): string {
		$validator = static fn(bool $condition, string $value = ''): string => $condition ? $value :
			throw new DecoratorModelBuilderException("Unexpected argument type");
		return !($type instanceof ReflectionNamedType) ? 'null' :
			match($type->getName()) {
				DecoratorContext::class => sprintf("new \%s(\$this, __FUNCTION__, func_get_args())", DecoratorContext::class),
				Throwable::class => $validator($throwableAllowed, '$throwable'),
				Closure::class => $validator($callbackAllowed, '\Closure::fromCallable(--callback-placeholder--)'),
				'callable' => $validator($callbackAllowed, '--callback-placeholder--'),
				'array' => $validator(true, 'func_get_args()'),
				'mixed' => $validator($resultAllowed, '$result'),
				default => $validator(false)
			};
	}

}