<?php

namespace Walnut\Lib\DecorAuto\InterfaceModel\Model;

final readonly class InterfaceMethodParameter {
	public function __construct(
		public string  $argumentName,
		public ?string $typeName,
		public bool    $isVariadic = false,
		public ?string $defaultValue = null
	) {}

	public function callExpression(): string {
		return ($this->isVariadic ? '...' : '') . '$' . $this->argumentName;
	}

	public function argumentExpression(): string {
		return
			(isset($this->typeName) ? $this->typeName . ' ' : '') .
			($this->isVariadic ? '...' : '') .
			'$' . $this->argumentName .
			(isset($this->defaultValue) ? ' = ' . $this->defaultValue : '');
	}
}