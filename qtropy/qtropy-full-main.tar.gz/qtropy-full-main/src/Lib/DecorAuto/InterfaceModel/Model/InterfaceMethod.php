<?php

namespace Walnut\Lib\DecorAuto\InterfaceModel\Model;

final readonly class InterfaceMethod {
	/**
	 * @var InterfaceMethodParameter[]
	 */
	public array $parameters;
	public function __construct(
		public string            $methodName,
		public ?string           $returnType,
		InterfaceMethodParameter ... $parameters,
	) {
		$this->parameters = $parameters;
	}

	public function callExpression(): string {
		return $this->methodName . '(' . implode(', ', array_map(
			static fn(InterfaceMethodParameter $parameter): string =>
				$parameter->callExpression(), $this->parameters)) . ')';
	}

	public function argumentExpression(): string {
		return 'public function ' . $this->methodName . '(' . implode(', ', array_map(
			static fn(InterfaceMethodParameter $parameter): string =>
				$parameter->argumentExpression(), $this->parameters)) . ')' .
			(isset($this->returnType) ? ': ' . $this->returnType : '');
	}
}