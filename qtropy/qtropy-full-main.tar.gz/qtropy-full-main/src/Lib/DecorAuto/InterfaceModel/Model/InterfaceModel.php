<?php

namespace Walnut\Lib\DecorAuto\InterfaceModel\Model;

final readonly class InterfaceModel {
	/**
	 * @var InterfaceMethod[]
	 */
	public array $methods;

	/**
	 * @param class-string $className
	 * @param InterfaceMethod ...$methods
	 */
	public function __construct(
		public string   $className,
		InterfaceMethod ... $methods
	) {
		$this->methods = $methods;
	}
}