<?php

namespace Walnut\Lib\DecorAuto\InterfaceModel\Builder;

use Walnut\Lib\DecorAuto\InterfaceModel\Model\InterfaceModel;

interface InterfaceModelBuilder {
	/**
	 * @param class-string $interfaceName
	 * @return InterfaceModel
	 * @throws InterfaceModelBuilderException
	 */
	public function getInterfaceModel(string $interfaceName): InterfaceModel;
}