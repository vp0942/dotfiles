<?php

namespace Walnut\Lib\DecorAuto\InterfaceModel\Builder;

use RuntimeException;

final class InterfaceModelBuilderException extends RuntimeException {}