<?php

namespace Walnut\Lib\DecorAuto\InterfaceModel\Reflection;

use ReflectionIntersectionType;
use ReflectionNamedType;
use ReflectionType;
use ReflectionUnionType;

final readonly class ReflectionTypeHelper {
	private function getNamedType(ReflectionNamedType $type, bool $allowsNull = false): string {
		return ($type->getName() !== 'mixed' && $allowsNull && $type->allowsNull() ? '?' : '') .
			($type->isBuiltin() ? '' : '\\') . $type->getName();
	}
	public function getTypeOf(ReflectionType|null $type): ?string {
		return match(true) {
			$type instanceof ReflectionIntersectionType => implode('&',
				array_map($this->getNamedType(...), $type->getTypes())),
			$type instanceof ReflectionUnionType => implode('|',
				array_map($this->getNamedType(...), $type->getTypes())),
			$type instanceof ReflectionNamedType => $this->getNamedType($type, true),
			default => null,
		};
	}
}