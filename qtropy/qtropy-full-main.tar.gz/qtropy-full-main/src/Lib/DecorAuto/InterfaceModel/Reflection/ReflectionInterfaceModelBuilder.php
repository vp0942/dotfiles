<?php

namespace Walnut\Lib\DecorAuto\InterfaceModel\Reflection;

use ReflectionClass;
use ReflectionException;
use ReflectionParameter;
use Walnut\Lib\DecorAuto\InterfaceModel\Builder\InterfaceModelBuilder;
use Walnut\Lib\DecorAuto\InterfaceModel\Builder\InterfaceModelBuilderException;
use Walnut\Lib\DecorAuto\InterfaceModel\Model\InterfaceMethod;
use Walnut\Lib\DecorAuto\InterfaceModel\Model\InterfaceMethodParameter;
use Walnut\Lib\DecorAuto\InterfaceModel\Model\InterfaceModel;

final readonly class ReflectionInterfaceModelBuilder implements InterfaceModelBuilder {

	public function __construct(
		private ReflectionTypeHelper $typeHelper
	) { }

	/**
	 * @param class-string $interfaceName
	 * @return InterfaceModel
	 * @throws InterfaceModelBuilderException
	 */
	public function getInterfaceModel(string $interfaceName): InterfaceModel {
		try {
			return $this->buildInterfaceModel($interfaceName);
		} catch (ReflectionException $ex) {
			// @codeCoverageIgnoreStart
			throw new InterfaceModelBuilderException(
				"Reflection error: " . $ex->getMessage(),
				previous: $ex
			);
			// @codeCoverageIgnoreEnd
		}
	}

	private function buildMethodParameter(ReflectionParameter $reflectionParameter): InterfaceMethodParameter {
		$parameterName = $reflectionParameter->getName();
		$typeName = $this->typeHelper->getTypeOf($reflectionParameter->getType());
		return new InterfaceMethodParameter(
			$parameterName,
			$typeName,
			$reflectionParameter->isVariadic(),
			$reflectionParameter->isDefaultValueAvailable() ?
				var_export($reflectionParameter->getDefaultValue(), true) : null
		);
	}

	/**
	 * @param class-string $interfaceName
	 * @return InterfaceModel
	 * @throws ReflectionException|InterfaceModelBuilderException
	 */
	private function buildInterfaceModel(string $interfaceName): InterfaceModel {
		$r = new ReflectionClass($interfaceName);
		if (!$r->isInterface()) {
			throw new InterfaceModelBuilderException("Only interfaces can be targeted");
		}
		$methods = [];
		foreach($r->getMethods() as $method) {
			$methodName = $method->getName();
			$parameters = [];
			foreach($method->getParameters() as $reflectionParameter) {
				$parameters[$reflectionParameter->getName()] =
					$this->buildMethodParameter($reflectionParameter);
			}
			$methods[$methodName] = new InterfaceMethod(
				$methodName,
				$this->typeHelper->getTypeOf($method->getReturnType()),
				...$parameters
			);
		}
		return new InterfaceModel($interfaceName, ...$methods);
	}
}