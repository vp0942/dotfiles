<?php

namespace Walnut\Lib\DecorAuto\Implementation\Model;

/**
 * @template T
 * @template D
 */
final readonly class InterfaceImplementation {
	/**
	 * @param class-string $className
	 * @param string $sourceCode
	 */
	public function __construct(
		public string $className,
		public string $sourceCode
	) {}
}