<?php

namespace Walnut\Lib\DecorAuto\Implementation\NameGenerator;

interface ClassNameGenerator {
	/**
	 * @param class-string $interfaceName
	 * @param string $implementationName
	 * @return string
	 */
	public function generateClassName(string $interfaceName, string $implementationName): string;
}