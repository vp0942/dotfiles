<?php

namespace Walnut\Lib\DecorAuto\Implementation\Builder;

use Walnut\Lib\DecorAuto\Implementation\Model\InterfaceImplementation;

interface InterfaceImplementationBuilder {
	/**
	 * @param class-string $decoratedClassName
	 * @param class-string $sourceInterfaceName
	 * @param array<string, class-string> $constructorArguments
	 * @param string $classMethods
	 * @return InterfaceImplementation
	 */
	public function build(
		string $decoratedClassName,
		string $sourceInterfaceName,
		array $constructorArguments,
		string $classMethods
	): InterfaceImplementation;
}