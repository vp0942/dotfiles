<?php

namespace Walnut\Lib\DecorAuto\Implementation\Builder;

use Walnut\Lib\DecorAuto\Implementation\Model\InterfaceImplementation;

final readonly class InterfaceImplementationDefaultBuilder implements InterfaceImplementationBuilder {
	/**
	 * @param class-string $decoratedClassName
	 * @param class-string $sourceInterfaceName
	 * @param array<string, class-string> $constructorArguments
	 * @param string $classMethods
	 * @return InterfaceImplementation
	 */
	public function build(
		string $decoratedClassName,
		string $sourceInterfaceName,
		array $constructorArguments,
		string $classMethods
	): InterfaceImplementation {
		$parts = explode('\\', $decoratedClassName);
		$endClassName = array_pop($parts);
		$namespace = implode('\\', $parts);

		$cArgs = [];
		foreach($constructorArguments as $argName => $argType) {
			$cArgs[] = "\t\tprivate readonly $argType \$$argName";
		}
		$cArgs = implode("," . PHP_EOL, $cArgs);

		$sourceCode = <<<CLASS
		namespace $namespace;
		final class $endClassName implements \\$sourceInterfaceName {
			public function __construct(
		$cArgs
			) {}
		$classMethods
		}
		CLASS;

		$sourceCode = str_replace(['\\' . $namespace . '\\', 'namespace ;' ], '', $sourceCode);

		return new InterfaceImplementation(
			$decoratedClassName,
			$sourceCode
		);
	}
}
