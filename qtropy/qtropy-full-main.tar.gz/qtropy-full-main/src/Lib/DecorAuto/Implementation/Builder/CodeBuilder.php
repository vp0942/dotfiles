<?php

namespace Walnut\Lib\DecorAuto\Implementation\Builder;

final class CodeBuilder {
	private const TAB = "\t";

	/**
	 * @var string[]
	 */
	private array $rows = [];
	private int $tabOffset = 0;

	public function reset(): self {
		$this->rows = [];
		$this->tabOffset = 0;
		return $this;
	}

	public function indentRight(): self {
		$this->tabOffset++;
		return $this;
	}

	public function indentLeft(): self {
		if ($this->tabOffset > 0) {
			$this->tabOffset--;
		}
		return $this;
	}

	public function addRow(string $row): self {
		$this->rows[] = str_repeat(self::TAB, $this->tabOffset) . $row;
		return $this;
	}

	public function build(): string {
		return implode(PHP_EOL, $this->rows);
	}

}