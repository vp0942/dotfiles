<?php

namespace Walnut\Lib\DecorAuto\Implementation\Builder;

use Walnut\Lib\DecorAuto\InterfaceModel\Model\InterfaceMethod;

interface ImplementationMethodBuilder {
	public function implementMethod(InterfaceMethod $method): string;
}