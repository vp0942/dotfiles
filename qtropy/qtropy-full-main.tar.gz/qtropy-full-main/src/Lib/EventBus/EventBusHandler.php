<?php

declare(strict_types=1);

namespace Walnut\Lib\EventBus;

use Walnut\Lib\EventBus\Loader\EventListenerLoader;
use Walnut\Lib\EventBus\Parser\EventListenerParser;

final class EventBusHandler implements EventBus {
	/**
	 * @var array<class-string, array<class-string, callable>>
	 */
	private ?array $listenerClassCache = null;
	/**
	 * @var array<class-string, callable[]>
	 */
	private ?array $listenerCache = null;

	/**
	 * @param class-string[] $eventListeners
	 */
	public function __construct(
		private readonly EventListenerLoader $loader,
		private readonly EventListenerParser $parser,
		private readonly array $eventListeners
	) {}

	/**
	 * @return array<array<class-string, EventListenerCallback[]>>
	 */
	private function parseClasses(): array {
		$result = [];
		foreach($this->eventListeners as $eventListenerClass) {
			$result[$eventListenerClass] = $this->parser
				->parseEventListenerClass($eventListenerClass);
		}
		return $result;
	}

	/**
	 * @param class-string $className
	 * @return callable[]
	 */
	private function parseListeners(string $className): array {
		$result = [];
		$this->listenerClassCache ??= $this->parseClasses();
		foreach($this->listenerClassCache as $listenerClassName => $classListeners) {
			if (array_key_exists( $className, $classListeners)) {
				$listenerClass = $this->loader->loadEventListener($listenerClassName);
				foreach($classListeners[$className] as $listenerData) {
					$methodName = $listenerData->listenerMethod;
					$result[$listenerData->priority->value] ??= [];
					$result[$listenerData->priority->value][] = $listenerClass->$methodName(...);
				}
			}
		}
		krsort($result);
		return array_merge(...$result);
	}

	/**
	 * @param class-string $className
	 * @return callable[]
	 */
	private function getListeners(string $className): array {
		return $this->listenerCache[$className] ??= $this->parseListeners($className);
	}

	/** @param object|object[] $event */
	public function dispatchEvent(object|array $event): void {
		$events = is_array($event) ? $event : [$event];
		foreach($events as $e) {
			foreach($this->getListeners($e::class) as $listener) {
				$listener($e);
			}
		}
	}
}