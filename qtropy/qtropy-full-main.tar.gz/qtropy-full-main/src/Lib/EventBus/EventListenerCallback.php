<?php

declare(strict_types=1);

namespace Walnut\Lib\EventBus;

final readonly class EventListenerCallback {
	public function __construct(
		public string        $listenerMethod,
		public EventPriority $priority
	) {}
}