<?php

namespace Walnut\Lib\EventBus\Loader;

use Walnut\Lib\EventBus\EventListenerNotFound;

interface EventListenerLoader {
	/**
	 * @param class-string $eventListener
	 * @return object
	 * @throws EventListenerNotFound
	 */
	public function loadEventListener(string $eventListener): object;
}
