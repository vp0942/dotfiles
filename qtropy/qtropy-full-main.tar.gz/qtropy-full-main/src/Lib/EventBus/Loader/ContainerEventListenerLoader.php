<?php

namespace Walnut\Lib\EventBus\Loader;

use Psr\Container\ContainerExceptionInterface;
use Psr\Container\ContainerInterface;
use Walnut\Lib\EventBus\EventListenerNotFound;

final readonly class ContainerEventListenerLoader implements EventListenerLoader {
	public function __construct(
		private ContainerInterface $container
	) {}

	/**
	 * @param class-string $eventListener
	 * @return object
	 * @throws EventListenerNotFound
	 */
	public function loadEventListener(string $eventListener): object {
		if ($this->container->has($eventListener)) {
			try {
				return $this->container->get($eventListener);
			} catch (ContainerExceptionInterface $ex) {
				throw new EventListenerNotFound(
					sprintf("Unable to load invalid event listener %s", $eventListener),
					previous: $ex);
			}
		}
		throw new EventListenerNotFound(
			sprintf("Unable to load event listener %s", $eventListener));
	}
}
