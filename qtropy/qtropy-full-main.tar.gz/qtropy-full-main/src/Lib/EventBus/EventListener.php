<?php

declare(strict_types=1);

namespace Walnut\Lib\EventBus;

use Attribute;

#[Attribute(Attribute::TARGET_METHOD | Attribute::IS_REPEATABLE)]
final readonly class EventListener {
	/**
	 * @param class-string $event
	 */
	public function __construct(
		public string        $event,
		public EventPriority $priority = EventPriority::normal
	) {}
}