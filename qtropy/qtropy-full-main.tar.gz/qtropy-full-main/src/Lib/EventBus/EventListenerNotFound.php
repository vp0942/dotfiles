<?php

namespace Walnut\Lib\EventBus;

use RuntimeException;

final class EventListenerNotFound extends RuntimeException {}