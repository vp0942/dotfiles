<?php

declare(strict_types=1);

namespace Walnut\Lib\EventBus;

interface EventBus {
	/** @param object|object[] $event */
	public function dispatchEvent(object|array $event): void;
}