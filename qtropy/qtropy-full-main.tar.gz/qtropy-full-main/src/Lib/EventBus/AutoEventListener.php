<?php

declare(strict_types=1);

namespace Walnut\Lib\EventBus;

use Attribute;

#[Attribute(Attribute::TARGET_CLASS)]
final readonly class AutoEventListener {}