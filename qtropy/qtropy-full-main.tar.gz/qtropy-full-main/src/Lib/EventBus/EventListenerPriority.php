<?php

declare(strict_types=1);

namespace Walnut\Lib\EventBus;

use Attribute;

#[Attribute(Attribute::TARGET_METHOD)]
final readonly class EventListenerPriority {
	public function __construct(
		public EventPriority $priority = EventPriority::normal
	) {}
}