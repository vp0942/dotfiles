<?php

namespace Walnut\Lib\EventBus\Parser;

use Walnut\Lib\EventBus\EventListenerCallback;

interface EventListenerParser {
	/**
	 * @param class-string $className
	 * @return array<class-string, EventListenerCallback[]>
	 */
	public function parseEventListenerClass(string $className): array;
}
