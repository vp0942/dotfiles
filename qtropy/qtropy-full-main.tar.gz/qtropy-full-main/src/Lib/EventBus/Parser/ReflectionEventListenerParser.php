<?php

namespace Walnut\Lib\EventBus\Parser;

use ReflectionClass;
use ReflectionMethod;
use ReflectionNamedType;
use ReflectionUnionType;
use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\EventBus\EventListener;
use Walnut\Lib\EventBus\EventListenerCallback;
use Walnut\Lib\EventBus\EventListenerPriority;
use Walnut\Lib\EventBus\EventPriority;

final readonly class ReflectionEventListenerParser implements EventListenerParser {
	/**
	 * @param class-string $className
	 * @return array<class-string, EventListenerCallback[]>
	 */
	public function parseEventListenerClass(string $className): array {
		$rClass = new ReflectionClass($className);
		$isAutoEventListener = count($rClass->getAttributes(AutoEventListener::class)) > 0;
		$result = [];
		foreach($rClass->getMethods(ReflectionMethod::IS_PUBLIC) as $reflectionMethod) {
			$methodName = $reflectionMethod->getName();
			if ($isAutoEventListener) {
				$priorityAttr = $reflectionMethod->getAttributes(EventListenerPriority::class)[0] ?? null;
				$priority = $priorityAttr?->newInstance()?->priority ?? EventPriority::normal;

				$param = $reflectionMethod->getParameters()[0] ?? null;
				$type = $param?->getType();
				if ($type instanceof ReflectionUnionType) {
					foreach($type->getTypes() as $uType) {
						if ($uType instanceof ReflectionNamedType) {
							$uClass = $uType->getName();
							$result[$uClass] ??= [];
							$result[$uClass][] = new EventListenerCallback(
								$methodName, $priority
							);
						}
					}
				} elseif ($type instanceof ReflectionNamedType) {
					$class = $type->getName();
					$result[$class] ??= [];
					$result[$class][] = new EventListenerCallback(
						$methodName, $priority
					);
				}
			} else {
				foreach($reflectionMethod->getAttributes(EventListener::class) as $attribute) {
					$eventListener = $attribute->newInstance();
					$result[$eventListener->event] ??= [];
					$result[$eventListener->event][] = new EventListenerCallback(
						$methodName, $eventListener->priority
					);
				}
			}
		}
		return $result;
	}
}
