<?php

namespace Walnut\Lib\EventBus;

enum EventPriority: int {
	case lowest = -2;
	case low = -1;
	case normal = 0;
	case high = 1;
	case highest = 2;
}
