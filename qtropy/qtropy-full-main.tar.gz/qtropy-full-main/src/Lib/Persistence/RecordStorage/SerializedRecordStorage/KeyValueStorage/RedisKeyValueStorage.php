<?php

namespace Walnut\Lib\Persistence\RecordStorage\SerializedRecordStorage\KeyValueStorage;

use Walnut\Lib\Persistence\Redis\RedisAdapter;
use Walnut\Lib\RecordStorage\KeyValueStorage\KeyNotFoundException;
use Walnut\Lib\RecordStorage\KeyValueStorage\KeyValueStorage;

/**
 * @package Walnut\Lib\Persistence\RecordStorage
 */
final readonly class RedisKeyValueStorage implements KeyValueStorage {
	public function __construct(
		private RedisAdapter $redisAdapter
	) { }

	public function store(string $key, string $value): void {
		$this->redisAdapter->getConnection()->set($key, $value);
	}

	public function retrieve(string $key): string {
		$c = $this->redisAdapter->getConnection();
		return $c->exists($key) ? $c->get($key) : throw new KeyNotFoundException;
	}
}
