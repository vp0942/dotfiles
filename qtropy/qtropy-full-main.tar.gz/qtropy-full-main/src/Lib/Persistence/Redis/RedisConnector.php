<?php

namespace Walnut\Lib\Persistence\Redis;

use Redis;

/**
 * Class RedisConnector
 * @package Walnut\Lib\Redis
 */
final class RedisConnector implements RedisAdapter {

	/**
	 * @psalm-suppress UndefinedClass
	 */
	private ?Redis $connection = null;

	public function __construct(private readonly string $host = '127.0.0.1') {}

	/**
	 * @psalm-suppress UndefinedClass
	 */
	public function getConnection(): Redis {
		return $this->connection ??= self::openConnection($this->host);
	}

	private static function openConnection(string $host): Redis {
		/**
		 * @psalm-suppress UndefinedClass
		 */
		$connection = new Redis();
		$connection->connect($host);
		return $connection;
	}

}