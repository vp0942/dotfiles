<?php

namespace Walnut\Lib\Persistence\Redis;

use Redis;

/**
 * Interface RedisAdapter
 * @package Walnut\Lib\Redis
 */
interface RedisAdapter {
	/**
	 * @psalm-suppress UndefinedClass
	 */
	public function getConnection(): Redis;
}
