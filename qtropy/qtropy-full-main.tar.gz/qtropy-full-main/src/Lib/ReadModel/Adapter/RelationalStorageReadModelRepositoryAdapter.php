<?php /** @noinspection PhpDocSignatureInspection */

namespace Walnut\Lib\ReadModel\Adapter;

use Walnut\Lib\DbOrm\RelationalStorageFetcher;
use Walnut\Lib\DbQueryBuilder\Expression\RawExpression;
use Walnut\Lib\DbQueryBuilder\QueryPart\QueryFilter;
use Walnut\Lib\DbQueryBuilder\Quoter\SqlQuoter;
use Walnut\Lib\ReadModel\Filter\ReadModelFilter;
use Walnut\Lib\ReadModel\OrderBy\OrderBy;
use Walnut\Lib\ReadModel\PageLimit\PageLimit;
use Walnut\Lib\ReadModel\Repository\ReadModelRepository;

/**
 * @template K of string|int
 * @implements ReadModelRepository<array, K>
 */
final readonly class RelationalStorageReadModelRepositoryAdapter implements ReadModelRepository {
	public function __construct(
		private RelationalStorageFetcher $fetcher,
		private SqlQuoter                $sqlQuoter,
		private string                   $keyName
	) {}

	public function count(): int {
		return count($this->all());
	}

	/**
	 * @param K $entityId
	 */
	public function existsById(string|int|object $entityId): bool {
		return is_array($this->byId($entityId));
	}

	/**
	 * @return iterable<array>
	 */
	public function all(): iterable {
		return $this->fetcher->fetchData(new QueryFilter(
			new RawExpression("1")
		));
	}

	/**
	 * @param iterable<K> $entityIds
	 * @return iterable<array>
	 */
	public function allById(iterable $entityIds): iterable {
		return $this->fetchList($entityIds);
	}

	/**
	 * @param K $entityId
	 * @return array|null
	 */
	public function byId(string|int|object $entityId): array|null {
		return $this->fetch($entityId);
	}

	/**
	 * @param ReadModelFilter|null $filter
	 * @param OrderBy|null $orderBy
	 * @param PageLimit|null $pageLimit
	 * @return iterable<array>
	 */
	public function allByFilter(
		ReadModelFilter $filter = null,
		OrderBy $orderBy = null,
		PageLimit $pageLimit = null
	): iterable {
		return $this->all(); //@TODO
	}

	/**
	 * @param ReadModelFilter|null $filter
	 * @param OrderBy|null $orderBy
	 * @return array|null
	 */
	public function byFilter(
		ReadModelFilter $filter = null,
		OrderBy $orderBy = null,
	): object|array|null {
		return $this->all()[0] ?? null; //@TODO
	}

	/**
	 * @param K $entityId
	 * @return array|null
	 */
	private function fetch(string|int $entityId): ?array {
		/**
		 * @var ?array
		 */
		return $this->fetcher->fetchData(new QueryFilter(
			new RawExpression(
				$this->sqlQuoter->quoteIdentifier($this->keyName) .
				" = " .
				$this->sqlQuoter->quoteValue($entityId))
		))[0] ?? null;
	}

	/**
	 * @param iterable<K> $entityId
	 * @return array<array>
	 */
	private function fetchList(iterable $entityIds): array {
		return $this->fetcher->fetchData(new QueryFilter(
			new RawExpression(
				sprintf("%s IN (%s)",
					$this->sqlQuoter->quoteIdentifier($this->keyName),
					implode(', ', array_map(
						$this->sqlQuoter->quoteValue(...),
						[...$entityIds]
					))
				)
			)
		));
	}

}