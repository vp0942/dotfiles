<?php /** @noinspection PhpDocSignatureInspection */

namespace Walnut\Lib\ReadModel\Adapter;

use Walnut\Lib\ReadModel\Filter\ReadModelFilter;
use Walnut\Lib\ReadModel\OrderBy\OrderBy;
use Walnut\Lib\ReadModel\PageLimit\PageLimit;
use Walnut\Lib\RecordStorage\RecordStorageAccessor;
use Walnut\Lib\ReadModel\Repository\ReadModelRepository;

/**
 * @template K of string|int
 * @implements ReadModelRepository<array, K>
 */
final readonly class RecordStorageReadModelRepositoryAdapter implements ReadModelRepository {
	/**
	 * @param RecordStorageAccessor<K> $accessor
	 * @param string $keyName
	 */
	public function __construct(
		private RecordStorageAccessor $accessor,
		private string                $keyName
	) {}

	public function count(): int {
		return count($this->accessor->all());
	}

	/**
	 * @param K $entityId
	 */
	public function existsById(string|int|object $entityId): bool {
		return is_array($this->byId($entityId));
	}

	/**
	 * @return iterable<array>
	 */
	public function all(): iterable {
		return $this->accessor->all();
	}

	/**
	 * @param iterable<K> $entityIds
	 * @return iterable<array>
	 */
	public function allById(iterable $entityIds): iterable {
		$entityIds = [...$entityIds];
		return array_values(
			array_filter(
				$this->accessor->all(),
				fn(array $entity): bool =>
					in_array($entity[$this->keyName], $entityIds, true)
			)
		);
	}

	/**
	 * @param K $entityId
	 * @return array|null
	 */
	public function byId(string|int|object $entityId): array|null {
		return $this->accessor->byKey($entityId);
	}

	/**
	 * @param ReadModelFilter|null $filter
	 * @param OrderBy|null $orderBy
	 * @param PageLimit|null $pageLimit
	 * @return iterable<array>
	 */
	public function allByFilter(
		ReadModelFilter $filter = null,
		OrderBy $orderBy = null,
		PageLimit $pageLimit = null
	): iterable {
		return $this->all(); //@TODO
	}

	/**
	 * @param ReadModelFilter|null $filter
	 * @param OrderBy|null $orderBy
	 * @return array|null
	 */
	public function byFilter(
		ReadModelFilter $filter = null,
		OrderBy $orderBy = null,
	): object|array|null {
		return $this->all()[0] ?? null; //@TODO
	}

}