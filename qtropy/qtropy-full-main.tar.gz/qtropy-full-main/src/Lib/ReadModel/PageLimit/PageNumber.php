<?php

namespace Walnut\Lib\ReadModel\PageLimit;

use InvalidArgumentException;

final readonly class PageNumber {
	public function __construct(public int $value) {
		if ($value <= 0) {
			throw new InvalidArgumentException(
				sprintf("A page number cannot be negative, %d given", $value)
			);
		}
	}
}
