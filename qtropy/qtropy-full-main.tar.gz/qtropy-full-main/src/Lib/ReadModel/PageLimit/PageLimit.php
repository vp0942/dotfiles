<?php

namespace Walnut\Lib\ReadModel\PageLimit;

final readonly class PageLimit {
	public function __construct(
		public PageSize   $pageSize,
		public PageNumber $page = new PageNumber(1)
	) {}
}
