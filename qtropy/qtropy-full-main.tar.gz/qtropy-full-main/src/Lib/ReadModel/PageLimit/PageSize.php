<?php

namespace Walnut\Lib\ReadModel\PageLimit;

use InvalidArgumentException;

final readonly class PageSize {
	public function __construct(public int $value) {
		if ($value <= 0) {
			throw new InvalidArgumentException(
				sprintf("A page size cannot be a negative number, %d given", $value)
			);
		}
	}
}
