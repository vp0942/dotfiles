<?php

namespace Walnut\Lib\ReadModel\OrderBy;

enum OrderByDirection {
	case ascending;
	case descending;
}
