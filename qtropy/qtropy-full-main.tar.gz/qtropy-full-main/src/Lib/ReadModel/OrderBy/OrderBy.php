<?php

namespace Walnut\Lib\ReadModel\OrderBy;

final readonly class OrderBy {
	/**
	 * @var OrderByField[]
	 */
	public array $orderByFields;

	public function __construct(
		OrderByField ...$orderByFields
	) {
		$this->orderByFields = $orderByFields;
	}
}
