<?php

namespace Walnut\Lib\ReadModel\OrderBy;

final readonly class OrderByField {
	private function __construct(
		public string           $fieldName,
		public OrderByDirection $direction
	) {}

	public static function ascending(string $fieldName): self {
		return new self($fieldName, OrderByDirection::ascending);
	}

	public static function descending(string $fieldName): self {
		return new self($fieldName, OrderByDirection::descending);
	}
}
