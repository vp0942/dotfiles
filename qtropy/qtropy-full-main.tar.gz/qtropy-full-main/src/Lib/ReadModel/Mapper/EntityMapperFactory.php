<?php

namespace Walnut\Lib\ReadModel\Mapper;

interface EntityMapperFactory {
	/**
	 * @template T of object
	 * @param class-string<T> $modelName
	 * @return EntityMapper<T, string|int|object, array, string|int>
	 */
	public function getMapper(string $modelName): EntityMapper;
}
