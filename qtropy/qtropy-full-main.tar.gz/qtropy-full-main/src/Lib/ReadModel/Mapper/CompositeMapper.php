<?php

namespace Walnut\Lib\ReadModel\Mapper;

/**
 * @template Tm of object|array
 * @template Km of string|int|object
 * @template Ts of object|array
 * @template Ks of string|int|object
 * @implements EntityMapper<Tm, Km, Ts, Ks>
 */
final readonly class CompositeMapper implements EntityMapper {
	/**
	 * @template Tx of object|array
	 * @param EntityMapper<Tm, Tx> $firstMapper
	 * @param EntityMapper<Tx, Ts> $secondMapper
	 */
	public function __construct(
		private EntityMapper $firstMapper,
		private EntityMapper $secondMapper,
	) {}

	/**
	 * @param Ts $source
	 * @return Tm
	 */
	public function fromSourceEntity(object|array $source): object|array {
		return $this->firstMapper->fromSourceEntity(
			$this->secondMapper->fromSourceEntity($source)
		);
	}

	/**
	 * @param Km $mapped
	 * @return Ks
	 */
	public function toSourceId(string|int|object $mapped): string|int|object {
		return $this->secondMapper->toSourceId(
			$this->firstMapper->toSourceId($mapped)
		);
	}

}
