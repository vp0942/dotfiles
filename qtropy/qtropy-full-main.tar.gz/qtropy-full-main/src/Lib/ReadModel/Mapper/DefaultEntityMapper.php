<?php

namespace Walnut\Lib\ReadModel\Mapper;

use Walnut\Lib\DataType\Importer\ClassHydrator;
use Walnut\Lib\JsonSerializer\JsonSerializer;

/**
 * @template Tm of object
 * @template Km of string|int|object
 * @template Ks of string|int
 * @implements EntityMapper<Tm, Km, array, Ks>
 */
final readonly class DefaultEntityMapper implements EntityMapper {
	/**
	 * @param JsonSerializer $jsonSerializer
	 * @param ClassHydrator $classHydrator
	 * @param class-string<Tm> $className
	 */
	public function __construct(
		private JsonSerializer $jsonSerializer,
		private ClassHydrator  $classHydrator,
		private string         $className,
	) {}

	/**
	 * @param array $source
	 * @return Tm
	 */
	public function fromSourceEntity(object|array $source): object {
		return $this->classHydrator->importValue($source, $this->className);
	}

	/**
	 * @param Km $mapped
	 * @return Ks
	 */
	public function toSourceId(string|int|object $mapped): string|int|object {
		/** @var Ks */
		return $this->jsonSerializer->decode(
			$this->jsonSerializer->encode($mapped),
			true
		);
	}

}
