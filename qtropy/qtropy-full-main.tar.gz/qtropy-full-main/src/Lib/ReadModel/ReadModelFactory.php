<?php

namespace Walnut\Lib\ReadModel;

use Walnut\Lib\Container\Container;
use Walnut\Lib\DataType\Importer\ClassHydrator;
use Walnut\Lib\DbDataModel\DataModelBuilder;
use Walnut\Lib\DbOrm\RelationalStorageFactory;
use Walnut\Lib\DbQueryBuilder\Quoter\SqlQuoter;
use Walnut\Lib\JsonSerializer\JsonSerializer;
use Walnut\Lib\ReadModel\Adapter\RecordStorageReadModelRepositoryAdapter;
use Walnut\Lib\ReadModel\Adapter\RelationalStorageReadModelRepositoryAdapter;
use Walnut\Lib\RecordStorage\ArrayDataAccessor\ArrayDataAccessorFactory;
use Walnut\Lib\ReadModel\Configuration\ReadModelConfiguration;
use Walnut\Lib\ReadModel\Configuration\Record;
use Walnut\Lib\ReadModel\Configuration\Relational;
use Walnut\Lib\ReadModel\Mapper\CompositeMapper;
use Walnut\Lib\ReadModel\Mapper\DefaultEntityMapper;
use Walnut\Lib\ReadModel\Mapper\EntityMapper;
use Walnut\Lib\ReadModel\Mapper\EntityMapperFactory;
use Walnut\Lib\ReadModel\Repository\ReadModelRepository;
use Walnut\Lib\ReadModel\Repository\ReadModelRepositoryFactory;
use Walnut\Lib\ReadModel\Repository\MappedReadModelRepository;

final readonly class ReadModelFactory implements EntityMapperFactory, ReadModelRepositoryFactory {
	/**
	 * @param Container $container
	 * @param ArrayDataAccessorFactory $arrayDataAccessorFactory
	 * @param RelationalStorageFactory $relationalStorageFactory
	 * @param DataModelBuilder $dataModelBuilder
	 * @param SqlQuoter $sqlQuoter
	 * @param JsonSerializer $jsonSerializer
	 * @param ClassHydrator $classHydrator
	 * @param ReadModelConfiguration $readModelConfiguration
	 */
	public function __construct(
		private Container                $container,
		private ArrayDataAccessorFactory $arrayDataAccessorFactory,
		private RelationalStorageFactory $relationalStorageFactory,
		private DataModelBuilder         $dataModelBuilder,
		private SqlQuoter                $sqlQuoter,
		private JsonSerializer           $jsonSerializer,
		private ClassHydrator            $classHydrator,
		private ReadModelConfiguration   $readModelConfiguration
	) {}

	/**
	 * @template T
	 * @param class-string<T> $modelName
	 * @return EntityMapper<T, string|int|object, array, string|int>
	 */
	public function getMapper(string $modelName): EntityMapper {
		$mapper = $this->readModelConfiguration->readModelOf($modelName)->mapper;
		$chain = [];
		if ($mapper->autoMap) {
			$chain[] = new DefaultEntityMapper(
				$this->jsonSerializer,
				$this->classHydrator,
				$mapper->autoMap === true ? $modelName : $mapper->autoMap,
			);
		}
		foreach($mapper->additionalMappers as $additionalMapper) {
			$chain[] = $this->container->instanceOf($additionalMapper);
		}
		$result = array_shift($chain);
		while(!empty($chain)) {
			$result = new CompositeMapper(array_shift($chain), $result);
		}
		return $result;
	}

	/**
	 * @template T of object
	 * @param class-string<T> $modelName
	 * @return ReadModelRepository<T, string|int|object>
	 */
	public function getRepository(string $modelName): ReadModelRepository {
		$model = $this->readModelConfiguration->readModelOf($modelName);
		$repository = $model->repository;

		$adapter = match($repository::class) {
			Record::class => new RecordStorageReadModelRepositoryAdapter(
				$this->arrayDataAccessorFactory->accessor($repository->recordKey),
				$model->identity?->key ?? 'id'
			),
			Relational::class => new RelationalStorageReadModelRepositoryAdapter(
				$this->relationalStorageFactory->getFetcher($dbDataModel = $this->dataModelBuilder->build($repository->dbDataModel)),
				$this->sqlQuoter,
				$dbDataModel->part($dbDataModel->modelRoot->modelRoot)->keyField->name
			)
		};
		return new MappedReadModelRepository($adapter, $this->getMapper($modelName));
	}

}
