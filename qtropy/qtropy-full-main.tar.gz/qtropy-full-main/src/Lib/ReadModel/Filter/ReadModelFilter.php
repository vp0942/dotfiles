<?php

namespace Walnut\Lib\ReadModel\Filter;

interface ReadModelFilter {}
