<?php

namespace Walnut\Lib\ReadModel\Repository;

interface ReadModelRepositoryFactory {
	/**
	 * @template T of object
	 * @param class-string<T> $modelName
	 * @return ReadModelRepository<T, string|int|object>
	 */
	public function getRepository(string $modelName): ReadModelRepository;
}
