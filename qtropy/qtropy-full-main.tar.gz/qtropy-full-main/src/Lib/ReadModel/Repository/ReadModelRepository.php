<?php

namespace Walnut\Lib\ReadModel\Repository;

use Walnut\Lib\ReadModel\Filter\ReadModelFilter;
use Walnut\Lib\ReadModel\OrderBy\OrderBy;
use Walnut\Lib\ReadModel\PageLimit\PageLimit;

/**
 * @template T of object|array
 * @template K of string|int|object
 */
interface ReadModelRepository {
	public function count(): int;
	/**
	 * @param T $entity
	 */
	/**
	 * @param K $entityId
	 */
	public function existsById(string|int|object $entityId): bool;
	/**
	 * @return iterable<T>
	 */
	public function all(): iterable;
	/**
	 * @param iterable<K> $entityIds
	 * @return iterable<T>
	 */
	public function allById(iterable $entityIds): iterable;
	/**
	 * @param K $entityId
	 * @return T|null
	 */
	public function byId(string|int|object $entityId): object|array|null;

	/**
	 * @param ReadModelFilter|null $filter
	 * @param OrderBy|null $orderBy
	 * @param PageLimit|null $pageLimit
	 * @return iterable<T>
	 */
	public function allByFilter(
		ReadModelFilter $filter = null,
		OrderBy $orderBy = null,
		PageLimit $pageLimit = null
	): iterable;

	/**
	 * @param ReadModelFilter|null $filter
	 * @param OrderBy|null $orderBy
	 * @return T|null
	 */
	public function byFilter(
		ReadModelFilter $filter = null,
		OrderBy $orderBy = null,
	): object|array|null;
}
