<?php

namespace Walnut\Lib\ReadModel\Repository;

use Walnut\Lib\ReadModel\Filter\ReadModelFilter;
use Walnut\Lib\ReadModel\Mapper\EntityMapper;
use Walnut\Lib\ReadModel\OrderBy\OrderBy;
use Walnut\Lib\ReadModel\PageLimit\PageLimit;

/**
 * @template Tm of object|array
 * @template Km of string|int|object
 * @template Ts of object|array
 * @template Ks of string|int|object
 * @implements ReadModelRepository<Tm, Km>
 */
final readonly class MappedReadModelRepository implements ReadModelRepository {
	/**
	 * @param ReadModelRepository<Ts, Ks> $repository
	 * @param EntityMapper<Tm, Km, Ts, Ks> $mapper
	 */
	public function __construct(
		private ReadModelRepository $repository,
		private EntityMapper        $mapper
	) {}

	public function count(): int {
		return $this->repository->count();
	}

	/**
	 * @param Km $entityId
	 */
	public function existsById(string|int|object $entityId): bool {
		return $this->repository->existsById($this->mapper->toSourceId($entityId));
	}

	/**
	 * @return iterable<Tm>
	 */
	public function all(): iterable {
		return $this->fromSourceEntities($this->repository->all());
	}

	/**
	 * @param iterable<Km> $entityIds
	 * @return iterable<Tm>
	 */
	public function allById(iterable $entityIds): iterable {
		return $this->fromSourceEntities(
			$this->repository->allById(
				$this->toSourceIds($entityIds)
			)
		);
	}

	/**
	 * @param Km $entityId
	 * @return Tm|null
	 */
	public function byId(string|int|object $entityId): object|array|null {
		$result = $this->repository->byId($this->mapper->toSourceId($entityId));
		return isset($result) ? $this->mapper->fromSourceEntity($result) : null;
	}

	/**
	 * @param iterable<Km> $ids
	 * @return iterable<Ks>
	 */
	private function toSourceIds(iterable $ids): iterable {
		foreach($ids as $id) {
			yield $this->mapper->toSourceId($id);
		}
	}

	/**
	 * @param ReadModelFilter|null $filter
	 * @param OrderBy|null $orderBy
	 * @param PageLimit|null $pageLimit
	 * @return iterable<Tm>
	 */
	public function allByFilter(
		ReadModelFilter $filter = null,
		OrderBy $orderBy = null,
		PageLimit $pageLimit = null
	): iterable {
		return $this->fromSourceEntities(
			$this->repository->allByFilter(
				$filter, $orderBy, $pageLimit
			)
		);
	}

	/**
	 * @param ReadModelFilter|null $filter
	 * @param OrderBy|null $orderBy
	 * @return Tm|null
	 */
	public function byFilter(
		ReadModelFilter $filter = null,
		OrderBy $orderBy = null,
	): object|array|null {
		$result = $this->repository->byFilter($filter, $orderBy);
		return isset($result) ? $this->mapper->fromSourceEntity($result) : null;
	}

	/**
	 * @param iterable<Ts> $entities
	 * @return iterable<Tm>
	 */
	private function fromSourceEntities(iterable $entities): iterable {
		foreach($entities as $entity) {
			yield $this->mapper->fromSourceEntity($entity);
		}
	}

}
