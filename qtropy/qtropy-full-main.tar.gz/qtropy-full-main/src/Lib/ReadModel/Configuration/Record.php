<?php

namespace Walnut\Lib\ReadModel\Configuration;

final readonly class Record {
	/**
	 * @param string $recordKey
	 */
	public function __construct(
		public string $recordKey,
	) {}

	public static function withKey(
		string $recordKey,
	): self {
		return new self($recordKey);
	}
}