<?php

namespace Walnut\Lib\ReadModel\Configuration;

use Attribute;

#[Attribute]
final readonly class ReadModel {
	/**
	 * @param class-string $className
	 */
	public function __construct(
		public string $className,
	) {}
}