<?php

namespace Walnut\Lib\ReadModel\Configuration;

use Attribute;
use Walnut\Lib\ReadModel\Mapper\EntityMapper;

#[Attribute]
final readonly class Mapper {
	/**
	 * @var array<class-string<EntityMapper>>
	 */
	public array $additionalMappers;

	/**
	 * @param bool|class-string $autoMap
	 * @param class-string<EntityMapper> ...$additionalMappers
	 */
	public function __construct(
		public bool|string $autoMap = true,
		string ... $additionalMappers
	) {
		$this->additionalMappers = $additionalMappers;
	}

	/**
	 * @param class-string<EntityMapper> ...$additionalMappers
	 */
	public static function auto(string ... $additionalMappers): self {
		return new self(true, ...$additionalMappers);
	}

	/**
	 * @param class-string<EntityMapper> ...$mappers
	 */
	public static function manual(string ... $mappers): self {
		return new self(false, ...$mappers);
	}

	/**
	 * @param class-string $className
	 * @param class-string<EntityMapper> ...$additionalMappers
	 */
	public static function to(string $className, string ... $additionalMappers): self {
		return new self($className, ...$additionalMappers);
	}
}