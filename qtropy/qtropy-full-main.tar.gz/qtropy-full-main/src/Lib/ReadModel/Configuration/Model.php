<?php

namespace Walnut\Lib\ReadModel\Configuration;

final readonly class Model {
	/**
	 * @param Record|Relational $repository
	 * @param Mapper|null $mapper
	 */
	public function __construct(
		public Record|Relational $repository,
		public ?Mapper           $mapper,
	) {}

	public static function of(
		Record|Relational $repository,
		Mapper $mapper = null,
	): self {
		return new self(
			$repository,
			$mapper,
		);
	}
}