<?php

namespace Walnut\Lib\ReadModel\Configuration;

use InvalidArgumentException;

final readonly class ReadModelConfiguration {

	/**
	 * @var array<class-string, Entry>
	 */
	private array $readModels;

	public function __construct(
		Entry ... $readModels
	) {
		$models = [];
		foreach($readModels as $readModel) {
			$models[$readModel->modelName] = $readModel;
		}
		$this->readModels = $models;
	}

	/**
	 * @param array<class-string, Model> $config
	 * @return static
	 */
	public static function fromConfig(array $config): self {
		$entries = [];
		foreach($config as $modelName => $modelData) {
			$entries[] = new Entry($modelName, ...(array)$modelData);
		}
		return new self(... $entries);
	}

	public function readModelOf(string $className): Entry {
		return $this->readModels[$className] ??
			throw new InvalidArgumentException(
				sprintf("No configuration found for read model %s", $className)
			);
	}
}