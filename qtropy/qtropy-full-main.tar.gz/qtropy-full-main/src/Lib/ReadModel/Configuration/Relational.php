<?php

namespace Walnut\Lib\ReadModel\Configuration;

use Walnut\Lib\DbDataModel\DataModel;

final readonly class Relational {
	/**
	 * @param class-string<DataModel> $dbDataModel
	 */
	public function __construct(
		public string $dbDataModel
	) {}

	/**
	 * @param class-string<DataModel> $dbDataModel
	 * @return static
	 */
	public static function withModel(string $dbDataModel): self {
		return new self($dbDataModel);
	}
}