<?php

namespace Walnut\Lib\Mailbox;

final class Attachment {

	public function __construct(
		public readonly string $attachmentName,
		public readonly string $attachmentContent
	) {}

}