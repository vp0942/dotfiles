<?php

namespace Walnut\Lib\Mailbox;

interface Mailbox {
	public function send(Message $message): ?string;
}