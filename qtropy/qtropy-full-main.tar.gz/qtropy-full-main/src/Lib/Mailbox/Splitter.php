<?php

namespace Walnut\Lib\Mailbox;

final class Splitter implements Mailbox {

	/** @var Mailbox[] $mailboxes */
	private array $mailboxes;

	public function __construct(Mailbox ... $mailboxes) {
		$this->mailboxes = $mailboxes;
	}

	public function send(Message $message): ?string {
		foreach($this->mailboxes as $mailbox) {
			$result = $mailbox->send($message);
		}
		return $result ?? null;
	}


}