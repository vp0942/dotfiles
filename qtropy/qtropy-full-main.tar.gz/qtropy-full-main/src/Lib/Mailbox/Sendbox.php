<?php

namespace Walnut\Lib\Mailbox;

final class Sendbox implements Mailbox {

	public function __construct(private readonly string $targetFolder) {}

	protected function prepareRecipient(Recipient $recipient): string {
		$name = $recipient->name;
		return $recipient->email . (isset($name) ? " <$name>" : '');
	}

	public function send(Message $message): ?string {
		$messageId = 'message-' . date('Y-m-d-H-i-s') . '-' . substr(microtime(true), 11);
		$messageDump = '<pre>From: ' . $this->prepareRecipient($message->sender) . '
Reply To: ' . ($message->replyTo ? $this->prepareRecipient($message->replyTo) : '-') . '
To: ' . implode(", ", array_map($this->prepareRecipient(...), $message->recipients[RecipientType::to->value] ?? [])) . '
CC: ' . implode(", ", array_map($this->prepareRecipient(...), $message->recipients[RecipientType::cc->value] ?? [])) . '
BCC: ' . implode(", ", array_map($this->prepareRecipient(...), $message->recipients[RecipientType::bcc->value] ?? [])) . '
Subject: ' . $message->subject . '
Body:
</pre><hr/>
' . $message->body . '
		';
		file_put_contents("$this->targetFolder/$messageId.html", $messageDump);
		foreach($message->attachments as $attachment) {
			file_put_contents("$this->targetFolder/$messageId.attachment." . $attachment->getAttachmentName(),
				$attachment->getAttachmentContent());
		}
		return null;
	}

}