<?php

namespace Walnut\Lib\Mailbox;

class Recipient {
	public function __construct(
		public readonly string $email,
		public readonly string|null $name = null,
		public readonly RecipientType $position = RecipientType::to
	) {}
}