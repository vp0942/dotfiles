<?php

namespace Walnut\Lib\Mailbox;

use Walnut\Module\Kernel\Util\Wither;

class Message {
	use Wither;

	private function __construct(
		public readonly string $subject,
		public readonly string $body,
		public readonly array $recipients,
		public readonly array $attachments,
		public readonly Recipient $replyTo,
		public readonly Recipient $sender
	) {
	}

	public function toRecipient(Recipient $recipient): self {
		$recipients = $this->recipients;
		$recipients[$recipient->position->value][] = $recipient;
		return $this->with(recipients: $recipients);
	}

	public static function create(
		string $subject,
		string $body,
		array $attachments,
		Recipient $replyTo,
		Recipient $sender
	): self {
		return new self(
			$subject, $body, [], $attachments, $replyTo, $sender
		);
	}

}