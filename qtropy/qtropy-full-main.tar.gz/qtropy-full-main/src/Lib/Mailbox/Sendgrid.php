<?php

namespace Walnut\Lib\Mailbox;

final class Sendgrid implements Mailbox {

	public function __construct(private readonly string $apiKey) {}

	private function prepareRecipient(Recipient $recipient): array {
		$node = ['email' => $recipient->email];
		$name = $recipient->name;
		if (isset($name)) {
			$node['name'] = $name;
		}
		return $node;
	}

	protected function prepareRequestBody(Message $message): array {
		$body = [
			'personalizations' => [[
				'to' => array_map($this->prepareRecipient(...),
					$message->recipients[RecipientType::to->value]),
				'subject' => $message->subject
			]],
			'from' => $this->prepareRecipient($message->sender),
			'content' => [[
				'type' => 'text/html',
				'value' => $message->body
			]]
		];
		if ($r = $message->replyTo) {
			$body['reply_to'] = $this->prepareRecipient($r);
		}
		return $body;
	}

	public function send(Message $message): ?string {
		$result = $this->doRequest('POST', 'https://api.sendgrid.com/v3/mail/send',
			json_encode($this->prepareRequestBody($message)), [
				"Authorization: Bearer $this->apiKey",
  			    "Content-Type: application/json"
			]
		);
		$matches = null;
		preg_match("/HTTP\/1.\d (\d{3})/", $result, $matches);
		$httpCode = $matches[1];
		if ($httpCode[0] == '2') {
			return null;
		}
		return explode("\r\n\r\n", $result)[1];
	}

	function doRequest(string $method, string $url, ?string $postData, array $headers) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HEADER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

		$response = curl_exec($ch);

		curl_close($ch);
		return $response;
	}

}