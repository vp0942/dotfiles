<?php

namespace Walnut\Lib\Mailbox;

enum RecipientType: int {
	case to = 1;
	case cc = 2;
	case bcc = 3;
}