<?php

namespace Walnut\Lib\Security;

final readonly class RsaPublicKey {

	/**
	 * @var string
	 */
	private string $key;

	/**
	 * RsaPublicKey constructor.
	 * @param string $key
	 */
	public function __construct(string $key) {
		$this->key = $key;
	}

	public function encrypt(string $text): string {
		openssl_public_encrypt($text, $result, $this->key, OPENSSL_PKCS1_OAEP_PADDING);
		return base64_encode($result);
	}

	public function decrypt(string $text): ?string {
		openssl_public_decrypt(base64_decode($text), $result, $this->key);
		return $result;
	}

	public function verify(string $text, string $signature): bool {
		return (bool)openssl_verify($text, base64_decode($signature), $this->key);
	}

}
