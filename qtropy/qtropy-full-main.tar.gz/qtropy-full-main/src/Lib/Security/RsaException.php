<?php

namespace Walnut\Lib\Security;

use RuntimeException;

final class RsaException extends RuntimeException {

	private function __construct(string $message) {
		parent::__construct($message);
	}

	public static function unableToCreatePrivateKey(): self {
		return new self("Unable to create private key");
	}

	public static function unableToCreatePublicKey(): self {
		return new self("Unable to create public key");
	}

	public static function unableToExportKey(string $openssl_error_string): self {
		return new self("Unable to export key: $openssl_error_string");
	}

}
