<?php

namespace Walnut\Lib\Security;

final readonly class RsaPrivateKey {

	/**
	 * @var resource
	 */
	private mixed $key;

	/**
	 * RsaPrivateKey constructor.
	 * @param string $key
	 * @param string $password
	 */
	public function __construct(string $key, string $password = '') {
		$resource = openssl_pkey_get_private($key, $password);
		if ($resource === false) {
			throw RsaException::unableToCreatePrivateKey();
		}
		$this->key = $resource;
	}

	public function getPublicKey(): RsaPublicKey {
		$details = openssl_pkey_get_details($this->key);
		$key = $details ? ($details['key'] ?? null) : false;
		if (!$key) {
			throw RsaException::unableToCreatePublicKey();
		}
		return new RsaPublicKey($key);

	}

	public function encrypt(string $text): string {
		openssl_private_encrypt($text, $result, $this->key);
		return base64_encode($result);
	}

	public function decrypt(string $text): ?string {
		openssl_private_decrypt(base64_decode($text), $result, $this->key, OPENSSL_PKCS1_OAEP_PADDING);
		return $result;
	}

	public function sign(string $text): string {
		openssl_sign($text, $result, $this->key);
		return base64_encode($result);
	}

	public function export(?string $password, array $config): string {
		$z = openssl_pkey_export($this->key, $privateKey, $password, $config);
		if ($z === false) {
			// @codeCoverageIgnoreStart
			throw RsaException::unableToExportKey((string)openssl_error_string());
			// @codeCoverageIgnoreEnd
		}
		return $privateKey;
	}

}
