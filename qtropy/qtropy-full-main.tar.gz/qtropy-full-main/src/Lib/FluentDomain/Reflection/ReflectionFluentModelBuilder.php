<?php

namespace Walnut\Lib\FluentDomain\Reflection;

use ReflectionAttribute;
use ReflectionClass;
use ReflectionException;
use ReflectionMethod;
use ReflectionNamedType;
use ReflectionParameter;
use ReflectionProperty;
use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\ImplementationOf;
use Walnut\Lib\FluentDomain\Attribute\PreRunDecorator;
use Walnut\Lib\FluentDomain\Attribute\Reference;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\DirectReturnValue;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\ReturnValueBuilder;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\VoidReturnValue;
use Walnut\Lib\FluentDomain\Builder\FluentModelBuilder;
use Walnut\Lib\FluentDomain\Builder\FluentModelBuilderException;
use Walnut\Lib\FluentDomain\Model\FluentMethod;
use Walnut\Lib\FluentDomain\Model\FluentMethodParameter;
use Walnut\Lib\FluentDomain\Model\FluentModel;

final readonly class ReflectionFluentModelBuilder implements FluentModelBuilder {

	public function __construct(
		//private readonly ReflectionTypeHelper $typeHelper
	) { }

	/**
	 * @param class-string $interfaceName
	 * @return FluentModel
	 * @throws FluentModelBuilderException
	 */
	public function getFluentModel(string $interfaceName): FluentModel {
		try {
			return $this->buildFluentModel($interfaceName);
		} catch (ReflectionException $ex) {
			// @codeCoverageIgnoreStart
			throw new FluentModelBuilderException(
				"Reflection error: " . $ex->getMessage(),
				previous: $ex
			);
			// @codeCoverageIgnoreEnd
		}
	}

	private function buildMethodParameter(ReflectionParameter $reflectionParameter): FluentMethodParameter {
		$parameterName = $reflectionParameter->getName();
		return new FluentMethodParameter(
			$parameterName,
			$reflectionParameter->isVariadic(),
			$reflectionParameter->isDefaultValueAvailable() ?
				var_export($reflectionParameter->getDefaultValue(), true) : null
		);
	}

	/**
	 * @param class-string $interfaceName
	 * @return FluentModel
	 * @throws ReflectionException|FluentModelBuilderException
	 */
	private function buildFluentModel(string $interfaceName): FluentModel {
		$r = new ReflectionClass($interfaceName);
		if (!$r->isInterface()) {
			throw new FluentModelBuilderException("Only interfaces can be targeted");
		}
		$implementationOf = $this->getAttribute($r, ImplementationOf::class) ??
			(($pc = $r->getParentClass()) ?
				new ImplementationOf($pc->getName()) :
				new ImplementationOf($r->getName())
			);
		$dataContext = $this->getAttribute($r, DataContext::class) ?? new DataContext;

		$methods = [];
		foreach($r->getMethods() as $method) {
			$methodName = $method->getName();
			$functionality =
				$this->getAttribute($method, Reference::class) ??
				$this->getAttribute($method, DomainCommand::class) ??
				$this->getAttribute($method, DataQuery::class) ??
				throw new FluentModelBuilderException("No functionality found for method $methodName");

			$parameters = [];
			foreach($method->getParameters() as $reflectionParameter) {
				$parameters[$reflectionParameter->getName()] =
					$this->buildMethodParameter($reflectionParameter);
			}
			$returnValue =
				$this->getAttribute($method, ReturnValueBuilder::class) ?? (
					(($ret = $method->getReturnType()) instanceof ReflectionNamedType) && $ret->getName() === 'void' ?
						new VoidReturnValue : new DirectReturnValue
				);

			$preRunDecorators = $this->getAttributes($method, PreRunDecorator::class);

			$methods[$methodName] = new FluentMethod(
				$methodName,
				$functionality,
				$preRunDecorators,
				$returnValue,
				... $parameters
			);
		}
		return new FluentModel($interfaceName, $implementationOf, $dataContext, ...$methods);
	}


	/**
	 * @template T of object
	 * @param ReflectionClass|ReflectionMethod|ReflectionProperty $r
	 * @param class-string<T> $className
	 * @return ?T
	 */
	private function getAttribute(
		ReflectionClass|ReflectionMethod|ReflectionProperty $r,
		string $className
	): ?object {
		/**
		 * @var ?T
		 */
		return ($r->getAttributes($className)[0] ?? null)?->newInstance();
	}

	/**
	 * @template T
	 * @param ReflectionClass|ReflectionMethod|ReflectionProperty $r
	 * @param class-string<T> $className
	 * @return array<T>
	 */
	private function getAttributes(ReflectionClass|ReflectionMethod|ReflectionProperty $r, string $className): array {
		return array_map(static fn(ReflectionAttribute $reflectionAttribute) =>
			$reflectionAttribute->newInstance(), $r->getAttributes($className));
	}

}