<?php

namespace Walnut\Lib\FluentDomain\Attribute;

use Attribute;

#[Attribute]
final readonly class ImplementationOf {
	/**
	 * @param class-string $targetInterface
	 */
	public function __construct(public string $targetInterface) {}
}