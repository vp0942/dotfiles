<?php

namespace Walnut\Lib\FluentDomain\Attribute;

use Attribute;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;

#[Attribute]
final readonly class DomainCommand {
	/**
	 * @param class-string $domainCommand
	 */
	public function __construct(
		public string        $domainCommand,
		public ParameterList $parameterList = new ParameterList(new ContextParameter),
	) {}
}
