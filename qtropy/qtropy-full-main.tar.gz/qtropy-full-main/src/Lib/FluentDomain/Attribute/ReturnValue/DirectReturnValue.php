<?php

namespace Walnut\Lib\FluentDomain\Attribute\ReturnValue;

use Attribute;

#[Attribute]
final readonly class DirectReturnValue {}
