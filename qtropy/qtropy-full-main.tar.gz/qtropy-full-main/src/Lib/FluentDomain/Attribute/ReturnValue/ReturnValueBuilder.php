<?php

namespace Walnut\Lib\FluentDomain\Attribute\ReturnValue;

use Attribute;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;

#[Attribute]
final readonly class ReturnValueBuilder {
	/**
	 * @param class-string $builderClass
	 */
	public function __construct(
		public string        $builderClass,
		public ParameterList $parameterList = new ParameterList(
			new ContextParameter
		),
	) {}
}
