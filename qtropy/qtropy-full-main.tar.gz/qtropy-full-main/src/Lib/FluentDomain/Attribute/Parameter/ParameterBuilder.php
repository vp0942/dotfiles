<?php

namespace Walnut\Lib\FluentDomain\Attribute\Parameter;

use Attribute;

#[Attribute]
final readonly class ParameterBuilder {
	/**
	 * @param class-string $builderClass
	 */
	public function __construct(
		public string        $builderClass,
		public ParameterList $parameterList = new ParameterList(new ContextParameter),
	) {}
}
