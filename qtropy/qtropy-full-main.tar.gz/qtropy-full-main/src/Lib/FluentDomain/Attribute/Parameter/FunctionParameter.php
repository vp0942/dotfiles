<?php

namespace Walnut\Lib\FluentDomain\Attribute\Parameter;

use Attribute;

#[Attribute]
final readonly class FunctionParameter {
	public function __construct(public string $parameterName) {}
}
