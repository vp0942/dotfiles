<?php

namespace Walnut\Lib\FluentDomain\Attribute\Parameter;

final readonly class ParameterList {
	/**
	 * @var array<ParameterBuilder|ContextParameter|FunctionParameter>
	 */
	public array $parameters;

	public function __construct(ParameterBuilder|ContextParameter|FunctionParameter ... $parameters) {
		$this->parameters = $parameters;
	}
}
