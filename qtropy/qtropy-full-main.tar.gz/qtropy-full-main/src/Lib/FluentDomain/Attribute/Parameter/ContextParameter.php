<?php

namespace Walnut\Lib\FluentDomain\Attribute\Parameter;

use Attribute;

#[Attribute]
final readonly class ContextParameter {
	public function __construct(public string|null $parameterName = null) {}
}
