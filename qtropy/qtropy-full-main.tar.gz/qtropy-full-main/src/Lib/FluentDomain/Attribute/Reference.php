<?php

namespace Walnut\Lib\FluentDomain\Attribute;

use Attribute;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;

#[Attribute]
final readonly class Reference {
	/**
	 * @param class-string $domainProxy
	 */
	public function __construct(
		public string        $domainProxy,
		public ParameterList $parameterList = new ParameterList
	) {}
}
