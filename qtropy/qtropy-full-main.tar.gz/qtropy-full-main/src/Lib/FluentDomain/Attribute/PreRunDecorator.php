<?php

namespace Walnut\Lib\FluentDomain\Attribute;

use Attribute;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;

#[Attribute]
final readonly class PreRunDecorator {
	/**
	 * @param class-string $decoratorClass
	 */
	public function __construct(
		public string        $decoratorClass,
		public ParameterList $parameterList = new ParameterList(new ContextParameter),
	) {}
}
