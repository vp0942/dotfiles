<?php

namespace Walnut\Lib\FluentDomain\Attribute;

use Attribute;

#[Attribute]
final readonly class DataContext {
	/**
	 * @var array<string, class-string|class-string[]>
	 */
	public array $context;
	/**
	 * @param array<string, class-string|class-string[]>|class-string $targetEntity
	 */
	public function __construct(array|string $targetEntity = null) {
		$this->context = match(true) {
			$targetEntity === null => [],
			is_array($targetEntity) => $targetEntity,
			default => [
				'contextParam' => $targetEntity
			]
		};
	}
}
