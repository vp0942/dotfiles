<?php

namespace Walnut\Lib\FluentDomain\CommandBus;

interface CommandBus {
	public function execute(callable $command): mixed;
}