<?php

namespace Walnut\Lib\FluentDomain\CommandBus;

use Walnut\Lib\EventBus\EventBus;

final readonly class EventDrivenCommandBus implements CommandBus {
	public function __construct(
		private EventBus $eventBus
	) {}

	public function execute(callable $command): mixed {
		$result = $command();
		if (is_object($result) || is_array($result)) {
			$this->eventBus->dispatchEvent($result);
		}
		return $result;
	}
}