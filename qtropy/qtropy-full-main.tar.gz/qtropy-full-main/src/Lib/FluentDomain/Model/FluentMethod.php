<?php

namespace Walnut\Lib\FluentDomain\Model;

use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\PreRunDecorator;
use Walnut\Lib\FluentDomain\Attribute\Reference;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\DirectReturnValue;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\ReturnValueBuilder;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\VoidReturnValue;

final readonly class FluentMethod {
	/**
	 * @var FluentMethodParameter[]
	 */
	public array $parameters;
	/** @param PreRunDecorator[] $preRunDecorators */
	public function __construct(
		public string                                               $methodName,
		public Reference|DataQuery|DomainCommand                    $functionality,
		public array                                                $preRunDecorators,
		public VoidReturnValue|DirectReturnValue|ReturnValueBuilder $returnValue,
		FluentMethodParameter ... $parameters,
	) {
		$this->parameters = $parameters;
	}
}