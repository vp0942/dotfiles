<?php

namespace Walnut\Lib\FluentDomain\Model;

final readonly class FluentContext {
	/**
	 * @var FluentContextModel[]
	 */
	public array $models;

	/**
	 * @param FluentContextModel ...$models
	 */
	public function __construct(
		FluentContextModel ... $models
	) {
		$arr = [];
		foreach($models as $model) {
			$arr[$model->fluentModel->implementationOf->targetInterface] = $model;
		}
		$this->models = $arr;
	}
}