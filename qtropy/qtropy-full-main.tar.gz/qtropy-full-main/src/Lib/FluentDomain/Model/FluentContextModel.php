<?php

namespace Walnut\Lib\FluentDomain\Model;

final readonly class FluentContextModel {
	public function __construct(
		public FluentModel $fluentModel,
		public string      $implementationClassName
	) {}
}