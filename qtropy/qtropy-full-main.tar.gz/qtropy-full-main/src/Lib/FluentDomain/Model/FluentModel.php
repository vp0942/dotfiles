<?php

namespace Walnut\Lib\FluentDomain\Model;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\ImplementationOf;

final readonly class FluentModel {
	/**
	 * @var FluentMethod[]
	 */
	public array $methods;

	/**
	 * @param class-string $className
	 * @param ImplementationOf $implementationOf
	 * @param DataContext $dataContext
	 * @param FluentMethod ...$methods
	 */
	public function __construct(
		public string           $className,
		public ImplementationOf $implementationOf,
		public DataContext      $dataContext,
		FluentMethod ... $methods
	) {
		$this->methods = $methods;
	}
}