<?php

namespace Walnut\Lib\FluentDomain\Model;

final readonly class FluentMethodParameter {
	public function __construct(
		public string  $argumentName,
		//public readonly ?string $typeName,
		public bool    $isVariadic = false,
		public ?string $defaultValue = null
	) {}

	public function callExpression(): string {
		return ($this->isVariadic ? '...' : '') . '$' . $this->argumentName;
	}

	public function argumentExpression(): string {
		return
			//(isset($this->typeName) ? $this->typeName . ' ' : '') .
			($this->isVariadic ? '...' : '') .
			'$' . $this->argumentName .
			(isset($this->defaultValue) ? ' = ' . $this->defaultValue : '');
	}
}