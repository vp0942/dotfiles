<?php

namespace Walnut\Lib\FluentDomain\Builder;

use Walnut\Lib\FluentDomain\Model\FluentContext;

interface FluentContextBuilder {
	public function getFluentContext(string ... $interfaceNames): FluentContext;
}