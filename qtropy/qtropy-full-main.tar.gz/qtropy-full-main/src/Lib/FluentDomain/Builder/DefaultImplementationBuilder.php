<?php

namespace Walnut\Lib\FluentDomain\Builder;

use RuntimeException;
use Walnut\Lib\Container\Container;
use Walnut\Lib\DecorAuto\Implementation\Builder\CodeBuilder;
use Walnut\Lib\DecorAuto\Implementation\Builder\InterfaceImplementationBuilder;
use Walnut\Lib\DecorAuto\Implementation\Model\InterfaceImplementation;
use Walnut\Lib\DecorAuto\InterfaceModel\Builder\InterfaceModelBuilder;
use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterBuilder;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\DirectReturnValue;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\ReturnValueBuilder;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\VoidReturnValue;
use Walnut\Lib\FluentDomain\CommandBus\CommandBus;
use Walnut\Lib\FluentDomain\Model\FluentContext;

final readonly class DefaultImplementationBuilder implements ImplementationBuilder {

	public function __construct(
		private CodeBuilder                    $codeBuilder,
		private InterfaceModelBuilder          $interfaceModelBuilder,
		private InterfaceImplementationBuilder $interfaceImplementationBuilder,
	) {}

	/**
	 * @param class-string $interfaceName
	 * @param FluentContext $fluentContext
	 * @return InterfaceImplementation
	 * @throws FluentModelBuilderException
	 */
	public function getImplementationOf(string $interfaceName, FluentContext $fluentContext): InterfaceImplementation {
		$fluentContextModel = $fluentContext->models[$interfaceName] ?? throw new RuntimeException(
			"No fluent model found for interface $interfaceName"
		);
		$interfaceModel = $this->interfaceModelBuilder->getInterfaceModel($interfaceName);

		$implementationClassName = $fluentContextModel->implementationClassName;
		$fluentModel = $fluentContextModel->fluentModel;

		$cArgs = [
			'container' => '\\' . Container::class
		];
		foreach($fluentModel->dataContext->context as $varName => $varType) {
			$cArgs[$varName] = '\\' . (
				is_array($varType) ? implode('|\\', $varType) : $varType
			);
		}
		$cBus = '\\' . CommandBus::class;
		$methods = [];

		foreach($fluentModel->methods as $methodName => $fluentMethod) {
			$interfaceMethod = $interfaceModel->methods[$methodName] ?? throw new RuntimeException(
				"No method $methodName found in interface $interfaceName"
			);
			$codeBuilder = $this->codeBuilder;

			$codeBuilder->reset()->indentRight();
			$codeBuilder->addRow($interfaceMethod->argumentExpression() . " {")->indentRight();

			foreach($fluentMethod->preRunDecorators as $preRunDecorator) {
				$decoratorArgs = $this->getParameterList($preRunDecorator->parameterList);
				$codeRow = "\$this->container->instanceOf(\\{$preRunDecorator->decoratorClass}::class)($decoratorArgs);";
				$codeBuilder->addRow($codeRow);
			}

			$args = $this->getParameterList($fluentMethod->functionality->parameterList);

			$functionality = $fluentMethod->functionality;

			$expr = match($functionality::class) {
				DomainCommand::class => "\$this->container->instanceOf($cBus::class)->execute(fn() => \$this->container->instanceOf(\\{$fluentMethod->functionality->domainCommand}::class)($args))",
				DataQuery::class => "\$this->container->instanceOf(\\{$fluentMethod->functionality->dataQuery}::class)($args)",
				default => ($targetClass = $fluentContext->models[$functionality->domainProxy]->implementationClassName) ?
					"new \\$targetClass(\$this->container, $args)" :
					throw new RuntimeException(
						"No domain proxy {$functionality->domainProxy} found for method $methodName"
					)
			};
			$codeRow = match($fluentMethod->returnValue::class) {
				VoidReturnValue::class => "$expr;",
				DirectReturnValue::class => "return $expr;",
				ReturnValueBuilder::class =>
					"return \$this->container->instanceOf(\\" . $fluentMethod->returnValue->builderClass . "::class)($expr" .
						(count($fluentMethod->returnValue->parameterList->parameters) > 0 ? ', ' : '') .
						$this->getParameterList($fluentMethod->returnValue->parameterList) .
					");"
			};
			$codeBuilder->addRow($codeRow);
			$codeBuilder->indentLeft()->addRow("}");

			$methods[$methodName] = $codeBuilder->build();
		}
		$methods = implode(PHP_EOL, $methods);

		$implementation = $this->interfaceImplementationBuilder->build(
			$implementationClassName,
			$interfaceName,
			$cArgs,
			$methods
		);

		$sourceCode = $implementation->sourceCode;
		if (str_contains($sourceCode, Container::class)) {
			$sourceCode = str_replace([
				'private readonly \\' . Container::class,
				'final class'
			], [
				'private readonly Container',
				'use ' . Container::class . ';' . PHP_EOL . 'final class'
			], $sourceCode);
		}

		return new InterfaceImplementation(
			$implementation->className,
			$sourceCode,
		);
	}

	private function getParameterList(ParameterList $parameterList): string {
		$params = [];
		foreach($parameterList->parameters as $parameter) {
			$params[] = match($parameter::class) {
				FunctionParameter::class => "\$" . $parameter->parameterName,
				ContextParameter::class => "\$this->" . ($parameter->parameterName ?? 'contextParam'),
				ParameterBuilder::class =>
					"\$this->container->instanceOf(\\" . $parameter->builderClass . "::class)(" .
						$this->getParameterList($parameter->parameterList) .
					")"
			};
		}
		return implode(', ', $params);
	}

}