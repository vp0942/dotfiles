<?php

namespace Walnut\Lib\FluentDomain\Builder;

use RuntimeException;

final class FluentModelBuilderException extends RuntimeException {}