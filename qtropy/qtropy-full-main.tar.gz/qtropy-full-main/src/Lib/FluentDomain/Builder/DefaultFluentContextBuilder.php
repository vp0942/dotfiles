<?php

namespace Walnut\Lib\FluentDomain\Builder;

use Walnut\Lib\DecorAuto\Implementation\NameGenerator\ClassNameGenerator;
use Walnut\Lib\FluentDomain\Model\FluentContext;
use Walnut\Lib\FluentDomain\Model\FluentContextModel;

final readonly class DefaultFluentContextBuilder implements FluentContextBuilder {
	public function __construct(
		private ClassNameGenerator $classNameGenerator,
		private FluentModelBuilder $fluentModelBuilder
	) {}

	public function getFluentContext(string ... $interfaceNames): FluentContext {
		$models = [];
		foreach($interfaceNames as $interfaceName) {
			$fluentModel = $this->fluentModelBuilder->getFluentModel($interfaceName);
			$models[] = new FluentContextModel(
				$fluentModel,
				$this->classNameGenerator->generateClassName(
					$fluentModel->implementationOf->targetInterface,
					'FluentContext'
				)
			);
		}
		return new FluentContext(...$models);
	}
}