<?php

namespace Walnut\Lib\FluentDomain\Builder;

use Walnut\Lib\DecorAuto\Implementation\Model\InterfaceImplementation;
use Walnut\Lib\FluentDomain\Model\FluentContext;

interface ImplementationBuilder {
	/**
	 * @param class-string $interfaceName
	 * @param FluentContext $fluentContext
	 * @return InterfaceImplementation
	 * @throws FluentModelBuilderException
	 */
	public function getImplementationOf(string $interfaceName, FluentContext $fluentContext): InterfaceImplementation;
}