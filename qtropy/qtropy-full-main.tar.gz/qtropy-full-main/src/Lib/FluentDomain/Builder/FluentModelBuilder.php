<?php

namespace Walnut\Lib\FluentDomain\Builder;

use Walnut\Lib\FluentDomain\Model\FluentModel;

interface FluentModelBuilder {
	/**
	 * @param class-string $interfaceName
	 * @return FluentModel
	 * @throws FluentModelBuilderException
	 */
	public function getFluentModel(string $interfaceName): FluentModel;
}