<?php

namespace Walnut\Lib\WriteModel;

use Walnut\Lib\Container\Container;
use Walnut\Lib\DataType\Importer\ClassHydrator;
use Walnut\Lib\DbDataModel\DataModelBuilder;
use Walnut\Lib\DbOrm\RelationalStorageFactory;
use Walnut\Lib\DbQueryBuilder\Quoter\SqlQuoter;
use Walnut\Lib\IdentityGenerator\IdentityGenerator;
use Walnut\Lib\JsonSerializer\JsonSerializer;
use Walnut\Lib\RecordStorage\ArrayDataAccessor\ArrayDataAccessorFactory;
use Walnut\Lib\WriteModel\Adapter\RelationalStorageWriteModelRepositoryAdapter;
use Walnut\Lib\WriteModel\Configuration\WriteModelConfiguration;
use Walnut\Lib\WriteModel\Configuration\Relational;
use Walnut\Lib\WriteModel\IdentityGenerator\DefaultWriteModelIdentityGenerator;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGenerator;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGeneratorFactory;
use Walnut\Lib\WriteModel\Mapper\CompositeMapper;
use Walnut\Lib\WriteModel\Mapper\DefaultEntityMapper;
use Walnut\Lib\WriteModel\Mapper\EntityMapper;
use Walnut\Lib\WriteModel\Mapper\EntityMapperFactory;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Lib\WriteModel\Repository\WriteModelRepositoryFactory;
use Walnut\Lib\WriteModel\Repository\MappedWriteModelRepository;

final readonly class WriteModelFactory implements EntityMapperFactory,
		WriteModelRepositoryFactory, WriteModelIdentityGeneratorFactory {
	/**
	 * @param Container $container
	 * param ArrayDataAccessorFactory $arrayDataAccessorFactory
	 * @param RelationalStorageFactory $relationalStorageFactory
	 * @param DataModelBuilder $dataModelBuilder
	 * @param SqlQuoter $sqlQuoter
	 * @param IdentityGenerator<string|int|object> $identityGenerator
	 * @param JsonSerializer $jsonSerializer
	 * @param ClassHydrator $classHydrator
	 * @param WriteModelConfiguration $writeModelConfiguration
	 */
	public function __construct(
		private Container                $container,
		//private readonly ArrayDataAccessorFactory $arrayDataAccessorFactory,
		private RelationalStorageFactory $relationalStorageFactory,
		private DataModelBuilder         $dataModelBuilder,
		private SqlQuoter                $sqlQuoter,
		private IdentityGenerator        $identityGenerator,
		private JsonSerializer           $jsonSerializer,
		private ClassHydrator            $classHydrator,
		private WriteModelConfiguration  $writeModelConfiguration
	) {}

	/**
	 * @template T
	 * @param class-string<T> $modelName
	 * @return EntityMapper<T, string|int|object, array, string|int>
	 */
	public function getMapper(string $modelName): EntityMapper {
		$mapper = $this->writeModelConfiguration->writeModelOf($modelName)->mapper;
		$chain = [];
		if ($mapper->autoMap) {
			$chain[] = new DefaultEntityMapper(
				$this->jsonSerializer,
				$this->classHydrator,
				$mapper->autoMap === true ? $modelName : $mapper->autoMap,
				$this->writeModelConfiguration->writeModelOf($modelName)
					->identity?->className
			);
		}
		foreach($mapper->additionalMappers as $additionalMapper) {
			$chain[] = $this->container->instanceOf($additionalMapper);
		}
		$result = array_shift($chain);
		while(!empty($chain)) {
			$result = new CompositeMapper(array_shift($chain), $result);
		}
		return $result;
	}

	/**
	 * @param class-string $modelName
	 * @return WriteModelIdentityGenerator<string|int>
	 */
	public function getIdentityGenerator(string $modelName): WriteModelIdentityGenerator {
		$model = $this->writeModelConfiguration->writeModelOf($modelName);
		$identityGenerator = $model->identity->generator;
		return $identityGenerator ?
			$this->container->instanceOf($identityGenerator) :
			new DefaultWriteModelIdentityGenerator(
				$this->classHydrator,
				$this->identityGenerator,
				$model->identity?->className
			);
	}

	/**
	 * @template T of object
	 * @param class-string<T> $modelName
	 * @return WriteModelRepository<T, string|int|object>
	 */
	public function getRepository(string $modelName): WriteModelRepository {
		$model = $this->writeModelConfiguration->writeModelOf($modelName);
		$repository = $model->repository;

		$adapter = match($repository::class) {
			/*Record::class => new RecordStorageWriteModelRepositoryAdapter(
				$this->arrayDataAccessorFactory->accessor($repository->recordKey),
				$model->identity?->key ?? 'id'
			),*/
			Relational::class => new RelationalStorageWriteModelRepositoryAdapter(
				$this->relationalStorageFactory->getFetcher($dbDataModel = $this->dataModelBuilder->build($repository->dbDataModel)),
				$this->relationalStorageFactory->getSynchronizer($dbDataModel),
				$this->sqlQuoter,
				$dbDataModel->part($dbDataModel->modelRoot->modelRoot)->keyField->name
			)
		};
		return new MappedWriteModelRepository($adapter, $this->getMapper($modelName));
	}

}
