<?php

namespace Walnut\Lib\WriteModel\IdentityGenerator;

interface WriteModelIdentityGeneratorFactory {
	/**
	 * @param class-string $modelName
	 * @return WriteModelIdentityGenerator<string|int>
	 */
	public function getIdentityGenerator(string $modelName): WriteModelIdentityGenerator;
}
