<?php

namespace Walnut\Lib\WriteModel\IdentityGenerator;

use Walnut\Lib\DataType\Importer\ClassHydrator;
use Walnut\Lib\IdentityGenerator\IdentityGenerator;

/**
 * @template K of string|int|object
 * @implements WriteModelIdentityGenerator<K>
 */
final readonly class DefaultWriteModelIdentityGenerator implements WriteModelIdentityGenerator {
	/**
	 * @param ClassHydrator $classHydrator
	 * @param IdentityGenerator<string|int> $identityGenerator
	 * @param class-string<K>|null $identityClassName
	 */
	public function __construct(
		private ClassHydrator     $classHydrator,
		private IdentityGenerator $identityGenerator,
		private ?string           $identityClassName
	) {}

	/**
	 * @return K
	 */
	public function generateIdentity(): string|int|object {
		$id = $this->identityGenerator->generateId();
		if (!$this->identityClassName) {
			return $id;
		}
		return $this->classHydrator->importValue($id, $this->identityClassName);
	}
}
