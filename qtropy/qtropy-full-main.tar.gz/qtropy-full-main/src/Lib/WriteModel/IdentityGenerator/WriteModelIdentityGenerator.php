<?php

namespace Walnut\Lib\WriteModel\IdentityGenerator;

/**
 * @template K of string|int|object
 */
interface WriteModelIdentityGenerator {
	/**
	 * @return K
	 */
	public function generateIdentity(): string|int|object;
}
