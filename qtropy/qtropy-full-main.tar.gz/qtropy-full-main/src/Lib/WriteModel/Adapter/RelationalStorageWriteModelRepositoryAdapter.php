<?php /** @noinspection PhpDocSignatureInspection */

namespace Walnut\Lib\WriteModel\Adapter;

use Walnut\Lib\DbOrm\RelationalStorageFetcher;
use Walnut\Lib\DbOrm\RelationalStorageSynchronizer;
use Walnut\Lib\DbQueryBuilder\Expression\RawExpression;
use Walnut\Lib\DbQueryBuilder\QueryPart\QueryFilter;
use Walnut\Lib\DbQueryBuilder\Quoter\SqlQuoter;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;

/**
 * @template K of string|int
 * @implements WriteModelRepository<array, K>
 */
final readonly class RelationalStorageWriteModelRepositoryAdapter implements WriteModelRepository {
	public function __construct(
		private RelationalStorageFetcher      $fetcher,
		private RelationalStorageSynchronizer $synchronizer,
		private SqlQuoter                     $sqlQuoter,
		private string                        $keyName
	) {}

	public function count(): int {
		return count($this->all());
	}

	/**
	 * @param array $entity
	 */
	public function remove(object|array $entity): void {
		$oldEntity = $this->fetch($entity[$this->keyName]);
		if ($oldEntity) {
			$this->synchronizer->synchronizeData([$oldEntity], []);
		}
	}

	public function removeAll(): void {
		$this->synchronizer->synchronizeData($this->all(), []);
	}

	/**
	 * @param iterable<array> $entities
	 */
	public function removeEntities(iterable $entities): void {
		$this->removeEntitiesById(
			array_map(
				fn(array $entity) => $entity[$this->keyName],
				$entities
			)
		);
	}

	/**
	 * @param iterable<K> $entityIds
	 */
	public function removeEntitiesById(iterable $entityIds): void {
		$oldEntities = $this->fetchList($entityIds);
		$this->synchronizer->synchronizeData($oldEntities, []);
	}

	/**
	 * @param K $entityId
	 */
	public function removeById(string|int|object $entityId): void {
		$this->removeEntitiesById([$entityId]);
	}

	/**
	 * @param K $entityId
	 */
	public function existsById(string|int|object $entityId): bool {
		return is_array($this->byId($entityId));
	}

	/**
	 * @return iterable<array>
	 */
	public function all(): iterable {
		return $this->fetcher->fetchData(new QueryFilter(
			new RawExpression("1")
		));
	}

	/**
	 * @param iterable<K> $entityIds
	 * @return iterable<array>
	 */
	public function allById(iterable $entityIds): iterable {
		return $this->fetchList($entityIds);
	}

	/**
	 * @param K $entityId
	 * @return array|null
	 */
	public function byId(string|int|object $entityId): array|null {
		return $this->fetch($entityId);
	}

	/**
	 * @param array $entity
	 */
	public function store(object|array $entity): void {
		$oldEntity = $this->fetch($entity[$this->keyName]);
		$this->synchronizer->synchronizeData($oldEntity ? [$oldEntity] : [], [$entity]);
	}

	/**
	 * @param iterable<array> $entities
	 */
	public function storeEntities(iterable $entities): void {
		$entities = [...$entities];
		$oldEntities = $this->fetchList(
			array_map(
				fn(array $entity) => $entity[$this->keyName],
				$entities
			)
		);
		$this->synchronizer->synchronizeData($oldEntities, $entities);
	}




	/**
	 * @param K $entityId
	 * @return array|null
	 */
	private function fetch(string|int $entityId): ?array {
		/**
		 * @var ?array
		 */
		return $this->fetcher->fetchData(new QueryFilter(
			new RawExpression(
				$this->sqlQuoter->quoteIdentifier($this->keyName) .
				" = " .
				$this->sqlQuoter->quoteValue($entityId))
		))[0] ?? null;
	}

	/**
	 * @param iterable<K> $entityId
	 * @return array<array>
	 */
	private function fetchList(iterable $entityIds): array {
		$entityIds = [...$entityIds];
		return count($entityIds) ? $this->fetcher->fetchData(new QueryFilter(
			new RawExpression(
				sprintf("%s IN (%s)",
					$this->sqlQuoter->quoteIdentifier($this->keyName),
					implode(', ', array_map(
						$this->sqlQuoter->quoteValue(...),
						$entityIds
					))
				)
			)
		)) : [];
	}

}