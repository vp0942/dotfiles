<?php /** @noinspection PhpDocSignatureInspection */

namespace Walnut\Lib\WriteModel\Adapter;

use Walnut\Lib\RecordStorage\RecordStorageAccessor;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;

/**
 * @template K of string|int
 * @implements WriteModelRepository<array, K>
 */
final readonly class RecordStorageWriteModelRepositoryAdapter implements WriteModelRepository {
	/**
	 * @param RecordStorageAccessor<K> $accessor
	 * @param string $keyName
	 */
	public function __construct(
		private RecordStorageAccessor $accessor,
		private string                $keyName
	) {}

	public function count(): int {
		return count($this->accessor->all());
	}

	/**
	 * @param array $entity
	 */
	public function remove(object|array $entity): void {
		$this->removeEntities([$entity]);
	}

	public function removeAll(): void {
		$this->removeEntities($this->accessor->all());
	}

	/**
	 * @param iterable<array> $entities
	 */
	public function removeEntities(iterable $entities): void {
		foreach($entities as $entity) {
			$this->accessor->remove($entity[$this->keyName]);
		}
	}

	/**
	 * @param iterable<K> $entityIds
	 */
	public function removeEntitiesById(iterable $entityIds): void {
		foreach($entityIds as $entityId) {
			$this->accessor->remove($entityId);
		}
	}

	/**
	 * @param K $entityId
	 */
	public function removeById(string|int|object $entityId): void {
		$this->removeEntitiesById([$entityId]);
	}

	/**
	 * @param K $entityId
	 */
	public function existsById(string|int|object $entityId): bool {
		return is_array($this->byId($entityId));
	}

	/**
	 * @return iterable<array>
	 */
	public function all(): iterable {
		return $this->accessor->all();
	}

	/**
	 * @param iterable<K> $entityIds
	 * @return iterable<array>
	 */
	public function allById(iterable $entityIds): iterable {
		$entityIds = [...$entityIds];
		return array_values(
			array_filter(
				$this->accessor->all(),
				fn(array $entity): bool =>
					in_array($entity[$this->keyName], $entityIds, true)
			)
		);
	}

	/**
	 * @param K $entityId
	 * @return array|null
	 */
	public function byId(string|int|object $entityId): array|null {
		return $this->accessor->byKey($entityId);
	}

	/**
	 * @param array $entity
	 */
	public function store(object|array $entity): void {
		$this->storeEntities([$entity]);
	}

	/**
	 * @param iterable<array> $entities
	 */
	public function storeEntities(iterable $entities): void {
		foreach($entities as $entity) {
			$this->accessor->store($entity[$this->keyName], $entity);
		}
	}

}