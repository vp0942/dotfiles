<?php

namespace Walnut\Lib\WriteModel\Repository;

interface WriteModelRepositoryFactory {
	/**
	 * @template T of object
	 * @param class-string<T> $modelName
	 * @return WriteModelRepository<T, string|int|object>
	 */
	public function getRepository(string $modelName): WriteModelRepository;
}
