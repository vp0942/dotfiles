<?php

namespace Walnut\Lib\WriteModel\Repository;

use Walnut\Lib\WriteModel\Mapper\EntityMapper;

/**
 * @template Tm of object|array
 * @template Km of string|int|object
 * @template Ts of object|array
 * @template Ks of string|int|object
 * @implements WriteModelRepository<Tm, Km>
 */
final readonly class MappedWriteModelRepository implements WriteModelRepository {
	/**
	 * @param WriteModelRepository<Ts, Ks> $repository
	 * @param EntityMapper<Tm, Km, Ts, Ks> $mapper
	 */
	public function __construct(
		private WriteModelRepository $repository,
		private EntityMapper         $mapper
	) {}

	public function count(): int {
		return $this->repository->count();
	}

	/**
	 * @param Tm $entity
	 */
	public function remove(object|array $entity): void {
		$this->repository->remove(
			$this->mapper->toSourceEntity($entity)
		);
	}

	public function removeAll(): void {
		$this->repository->removeAll();
	}

	/**
	 * @param iterable<Tm> $entities
	 */
	public function removeEntities(iterable $entities): void {
		$this->repository->removeEntities(
			$this->toSourceEntities($entities)
		);
	}

	/**
	 * @param iterable<Km> $entityIds
	 */
	public function removeEntitiesById(iterable $entityIds): void {
		$this->repository->removeEntitiesById(
			$this->toSourceIds($entityIds)
		);
	}

	/**
	 * @param Km $entityId
	 */
	public function removeById(string|int|object $entityId): void {
		$this->repository->removeById($this->mapper->toSourceId($entityId));
	}

	/**
	 * @param Km $entityId
	 */
	public function existsById(string|int|object $entityId): bool {
		return $this->repository->existsById($this->mapper->toSourceId($entityId));
	}

	/**
	 * @return iterable<Tm>
	 */
	public function all(): iterable {
		return $this->fromSourceEntities($this->repository->all());
	}

	/**
	 * @param iterable<Km> $entityIds
	 * @return iterable<Tm>
	 */
	public function allById(iterable $entityIds): iterable {
		return $this->fromSourceEntities(
			$this->repository->allById(
				$this->toSourceIds($entityIds)
			)
		);
	}

	/**
	 * @param Km $entityId
	 * @return Tm|null
	 */
	public function byId(string|int|object $entityId): object|array|null {
		$result = $this->repository->byId($this->mapper->toSourceId($entityId));
		return isset($result) ? $this->mapper->fromSourceEntity($result) : null;
	}

	/**
	 * @param Tm $entity
	 */
	public function store(object|array $entity): void {
		$this->repository->store($this->mapper->toSourceEntity($entity));
	}

	/**
	 * @param iterable<Tm> $entities
	 */
	public function storeEntities(iterable $entities): void {
		$this->repository->storeEntities(
			$this->toSourceEntities($entities)
		);
	}

	/**
	 * @param iterable<Ts> $entities
	 * @return iterable<Tm>
	 */
	private function fromSourceEntities(iterable $entities): iterable {
		foreach($entities as $entity) {
			yield $this->mapper->fromSourceEntity($entity);
		}
	}

	/**
	 * @param iterable<Tm> $entities
	 * @return iterable<Ts>
	 */
	private function toSourceEntities(iterable $entities): iterable {
		foreach($entities as $entity) {
			yield $this->mapper->toSourceEntity($entity);
		}
	}

	/**
	 * @param iterable<Km> $ids
	 * @return iterable<Ks>
	 */
	private function toSourceIds(iterable $ids): iterable {
		foreach($ids as $id) {
			yield $this->mapper->toSourceId($id);
		}
	}

}
