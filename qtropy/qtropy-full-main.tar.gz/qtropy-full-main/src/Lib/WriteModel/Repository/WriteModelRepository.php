<?php

namespace Walnut\Lib\WriteModel\Repository;

/**
 * @template T of object|array
 * @template K of string|int|object
 */
interface WriteModelRepository {
	public function count(): int;
	/**
	 * @param T $entity
	 */
	public function remove(object|array $entity): void;
	public function removeAll(): void;
	/**
	 * @param iterable<T> $entities
	 */
	public function removeEntities(iterable $entities): void;
	/**
	 * @param iterable<K> $entityIds
	 */
	public function removeEntitiesById(iterable $entityIds): void;
	/**
	 * @param K $entityId
	 */
	public function removeById(string|int|object $entityId): void;
	/**
	 * @param K $entityId
	 */
	public function existsById(string|int|object $entityId): bool;
	/**
	 * @return iterable<T>
	 */
	public function all(): iterable;
	/**
	 * @param iterable<K> $entityIds
	 * @return iterable<T>
	 */
	public function allById(iterable $entityIds): iterable;
	/**
	 * @param K $entityId
	 * @return T|null
	 */
	public function byId(string|int|object $entityId): object|array|null;
	/**
	 * @param T $entity
	 */
	public function store(object|array $entity): void;
	/**
	 * @param iterable<T> $entities
	 */
	public function storeEntities(iterable $entities): void;
}
