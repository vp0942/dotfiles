<?php

namespace Walnut\Lib\WriteModel\Mapper;

use Walnut\Lib\DataType\Importer\ClassHydrator;
use Walnut\Lib\JsonSerializer\JsonSerializer;

/**
 * @template Tm of object
 * @template Km of string|int|object
 * @template Ks of string|int
 * @implements EntityMapper<Tm, Km, array, Ks>
 */
final readonly class DefaultEntityMapper implements EntityMapper {
	/**
	 * @param JsonSerializer $jsonSerializer
	 * @param ClassHydrator $classHydrator
	 * @param class-string<Tm> $className
	 * @param class-string<Km>|null $identityClassName
	 */
	public function __construct(
		private JsonSerializer $jsonSerializer,
		private ClassHydrator  $classHydrator,
		private string         $className,
		private ?string        $identityClassName,
	) {}

	/**
	 * @param Tm $mapped
	 * @return array
	 */
	public function toSourceEntity(object|array $mapped): array {
		return (array)$this->jsonSerializer->decode(
			$this->jsonSerializer->encode($mapped),
			true
		);
	}

	/**
	 * @param array $source
	 * @return Tm
	 */
	public function fromSourceEntity(object|array $source): object {
		return $this->classHydrator->importValue($source, $this->className);
	}

	/**
	 * @param Ks $source
	 * @return Km
	 */
	public function fromSourceId(string|int|object $source): string|int|object {
		return $this->identityClassName ?
			$this->classHydrator->importValue($source, $this->identityClassName) :
			$source;
	}

	/**
	 * @param Km $mapped
	 * @return Ks
	 */
	public function toSourceId(string|int|object $mapped): string|int|object {
		/** @var Ks */
		return $this->jsonSerializer->decode(
			$this->jsonSerializer->encode($mapped),
			true
		);
	}

}
