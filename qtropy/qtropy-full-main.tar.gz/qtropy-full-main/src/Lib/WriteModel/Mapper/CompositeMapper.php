<?php

namespace Walnut\Lib\WriteModel\Mapper;

/**
 * @template Tm of object|array
 * @template Km of string|int|object
 * @template Ts of object|array
 * @template Ks of string|int|object
 * @implements EntityMapper<Tm, Km, Ts, Ks>
 */
final readonly class CompositeMapper implements EntityMapper {
	/**
	 * @template Tx of object|array
	 * @template Kx of string|int|object
	 * @param EntityMapper<Tm, Km, Tx, Kx> $firstMapper
	 * @param EntityMapper<Tx, Kx, Ts, Ks> $secondMapper
	 */
	public function __construct(
		private EntityMapper $firstMapper,
		private EntityMapper $secondMapper,
	) {}

	/**
	 * @param Tm $mapped
	 * @return Ts
	 */
	public function toSourceEntity(object|array $mapped): object|array {
		return $this->secondMapper->toSourceEntity(
			$this->firstMapper->toSourceEntity($mapped)
		);
	}
	/**
	 * @param Km $mapped
	 * @return Ks
	 */
	public function toSourceId(string|int|object $mapped): string|int|object {
		return $this->secondMapper->toSourceId(
			$this->firstMapper->toSourceId($mapped)
		);
	}

	/**
	 * @param Ts $source
	 * @return Tm
	 */
	public function fromSourceEntity(object|array $source): object|array {
		return $this->firstMapper->fromSourceEntity(
			$this->secondMapper->fromSourceEntity($source)
		);
	}

	/**
	 * @param Ks $source
	 * @return Km
	 */
	public function fromSourceId(string|int|object $source): string|int|object {
		return $this->firstMapper->fromSourceId(
			$this->secondMapper->fromSourceId($source)
		);
	}
}
