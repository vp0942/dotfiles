<?php

namespace Walnut\Lib\WriteModel\Mapper;

/**
 * @template Tm of object|array
 * @template Km of string|int|object
 * @template Ts of object|array
 * @template Ks of string|int|object
 */
interface EntityMapper {
	/**
	 * @param Tm $mapped
	 * @return Ts
	 */
	public function toSourceEntity(object|array $mapped): object|array;
	/**
	 * @param Km $mapped
	 * @return Ks
	 */
	public function toSourceId(string|int|object $mapped): string|int|object;
	/**
	 * @param Ts $source
	 * @return Tm
	 */
	public function fromSourceEntity(object|array $source): object|array;
	/**
	 * @param Ks $source
	 * @return Km
	 */
	public function fromSourceId(string|int|object $source): string|int|object;
}
