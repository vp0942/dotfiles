<?php

namespace Walnut\Lib\WriteModel\Configuration;

/**
 * @template T of object
 */
final readonly class Entry {
	/**
	 * @param class-string<T> $modelName
	 * @param Record|Relational $repository
	 * @param Identity|null $identity
	 * @param Mapper|null $mapper
	 */
	public function __construct(
		public string            $modelName,
		public Record|Relational $repository,
		public ?Identity         $identity,
		public ?Mapper           $mapper,
	) {}
}