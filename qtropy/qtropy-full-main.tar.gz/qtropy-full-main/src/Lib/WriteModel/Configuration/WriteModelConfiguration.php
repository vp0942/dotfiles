<?php

namespace Walnut\Lib\WriteModel\Configuration;

use InvalidArgumentException;

final readonly class WriteModelConfiguration {

	/**
	 * @var array<class-string, Entry>
	 */
	private array $writeModels;

	public function __construct(
		Entry ... $writeModels
	) {
		$models = [];
		foreach($writeModels as $writeModel) {
			$models[$writeModel->modelName] = $writeModel;
		}
		$this->writeModels = $models;
	}

	/**
	 * @param array<class-string, Model> $config
	 * @return static
	 */
	public static function fromConfig(array $config): self {
		$entries = [];
		foreach($config as $modelName => $modelData) {
			$entries[] = new Entry($modelName, ...(array)$modelData);
		}
		return new self(... $entries);
	}

	public function writeModelOf(string $className): Entry {
		return $this->writeModels[$className] ??
			throw new InvalidArgumentException(
				sprintf("No configuration found for write model %s", $className)
			);
	}
}