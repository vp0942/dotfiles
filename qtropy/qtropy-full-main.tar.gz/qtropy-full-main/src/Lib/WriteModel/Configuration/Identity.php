<?php

namespace Walnut\Lib\WriteModel\Configuration;

/**
 * @template T of object
 */
final readonly class Identity {
	/**
	 * @param string $key
	 * @param class-string<T>|null $className
	 * @param class-string|null $generator
	 */
	public function __construct(
		public string  $key,
		public ?string $className,
		public ?string $generator
	) {}

	/**
	 * @template T of object
	 * @param string $key
	 * @param class-string<T>|null $className
	 * @param class-string|null $generator
	 * @return self<T>
	 */
	public static function with(
		string $key = 'id',
		string $className = null,
		string $generator = null,
	): self {
		return new self($key, $className, $generator);
	}
}