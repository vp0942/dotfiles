<?php

namespace Walnut\Lib\WriteModel\Configuration;

final readonly class Model {
	/**
	 * @param Record|Relational $repository
	 * @param Mapper|null $mapper
	 * @param Identity|null $identity
	 */
	public function __construct(
		public Record|Relational $repository,
		public ?Mapper           $mapper,
		public ?Identity         $identity,
	) {}

	public static function of(
		Record|Relational $repository,
		Mapper $mapper = null,
		Identity $identity = null,
	): self {
		return new self(
			$repository,
			$mapper,
			$identity,
		);
	}
}