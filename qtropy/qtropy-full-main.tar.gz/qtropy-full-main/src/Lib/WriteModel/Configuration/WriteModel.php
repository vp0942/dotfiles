<?php

namespace Walnut\Lib\WriteModel\Configuration;

use Attribute;

#[Attribute]
final readonly class WriteModel {
	/**
	 * @param class-string $className
	 */
	public function __construct(
		public string $className,
	) {}
}