<?php

namespace Walnut\Module\Notification\Presentation\View;

use Walnut\Module\Notification\Application\Context\_MemberNotifications;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Model\NotificationTypeGroup;

final readonly class NotificationViewBuilder {

	/**
	 * @param string $pageTitle
	 * @param array<string, string> $labels
	 */
	public function __construct(
		private _MemberNotifications $memberNotifications,
		private string               $pageTitle,
		private array                $labels,
	) {}

	/** @param NotificationTypeGroup[] $searchTypes */
	public function pageView(
		array $searchTypes,
	): NotificationsView {
		return new NotificationsView(
			$this->pageTitle,
			$searchTypes,
			$this->labels,
		);
	}

	/** @param NotificationTypeGroup[] $searchTypes */
	public function listView(
		array $searchTypes
	): NotificationListView {
		return new NotificationListView(
			$this->memberNotifications->byType($searchTypes)
		);
	}

}