<?php

namespace Walnut\Module\Notification\Presentation\View;

use Walnut\Module\Notification\Application\Model\NotificationData;

final readonly class NotificationListView {
	/** @param NotificationData[] $notifications */
	public function __construct(
		public array $notifications
	) {}
}