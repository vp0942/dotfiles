<?php

namespace Walnut\Module\Notification\Presentation\View;

use Walnut\Module\Notification\Domain\Model\NotificationTypeGroup;

final readonly class NotificationsView {
	/**
	 * @param string $pageTitle
	 * @param NotificationTypeGroup[] $searchTypes
	 * @param array<string, string> $labels
	 */
	public function __construct(
		public string $pageTitle,
		public array  $searchTypes,
		public array  $labels,
	) {}

}