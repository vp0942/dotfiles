<?php

namespace Walnut\Module\Notification\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Module\Notification\Domain\Command\RemoveNotification;
use Walnut\Module\Notification\Domain\Model\Notification;

#[DataContext(Notification::class)]
interface _MemberNotification {
	#[DomainCommand(RemoveNotification::class, new ParameterList(
		new ContextParameter,
	))]
	public function remove(): void;
}