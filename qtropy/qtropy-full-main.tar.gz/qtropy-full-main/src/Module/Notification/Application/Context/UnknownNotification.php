<?php

namespace Walnut\Module\Notification\Application\Context;

use InvalidArgumentException;
use Walnut\Module\Notification\Domain\Model\NotificationId;

final class UnknownNotification extends InvalidArgumentException {
	private const unknownId = "Notification with ID '%s' cannot be found";
	public static function withId(NotificationId $notificationId): never {
		throw new self(sprintf(self::unknownId, (string)$notificationId));
	}
}