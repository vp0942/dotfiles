<?php

namespace Walnut\Module\Notification\Application\Context;

use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Notification\Domain\Model\Notification;
use Walnut\Module\Notification\Domain\Model\NotificationId;

final readonly class NotificationById {
	public function __construct(
		#[WriteModel(Notification::class)]
		private WriteModelRepository $repository
	) {}

	public function __invoke(NotificationId $notificationId): Notification {
		return $this->repository->byId($notificationId) ??
			UnknownNotification::withId($notificationId);
	}
}