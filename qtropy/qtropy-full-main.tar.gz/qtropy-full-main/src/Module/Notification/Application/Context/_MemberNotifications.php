<?php

namespace Walnut\Module\Notification\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterBuilder;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\Reference;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Notification\Application\Model\NotificationData;
use Walnut\Module\Notification\Application\Query\NotificationsByTypeQuery;
use Walnut\Module\Notification\Application\Query\NotificationsCountQuery;
use Walnut\Module\Notification\Domain\Model\NotificationId;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Model\NotificationTypeGroup;

#[DataContext(Member::class)]
interface _MemberNotifications {
	#[Reference(_MemberNotification::class, new ParameterList(
		new ParameterBuilder(
			NotificationById::class,
			new ParameterList(
				new FunctionParameter('notificationId')
			)
		)
	))]
	public function notification(NotificationId $notificationId): _MemberNotification;

	/**
	 * @param NotificationTypeGroup[] $notificationTypes
	 * @return NotificationData[]
	 */
	#[DataQuery(NotificationsByTypeQuery::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('notificationTypes')
	))]
	public function byType(array $notificationTypes): array;

	#[DataQuery(NotificationsCountQuery::class, new ParameterList(
		new ContextParameter
	))]
	public function count(): int;
}