<?php

namespace Walnut\Module\Notification\Application\Model;

use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Notification\Domain\Model\NotificationDetails;
use Walnut\Module\Notification\Domain\Model\NotificationType;

final readonly class NotificationData {
	public function __construct(
		public string           $notificationId,
		public string           $message,
		public string|null      $relatedId,
		public DateAndTime      $notificationDate,
		public NotificationDetails $details,
	) {}
}