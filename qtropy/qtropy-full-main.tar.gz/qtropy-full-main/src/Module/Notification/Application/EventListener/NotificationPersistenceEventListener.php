<?php

namespace Walnut\Module\Notification\Application\EventListener;

use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Notification\Domain\Event\NotificationAdded;
use Walnut\Module\Notification\Domain\Event\NotificationRemoved;
use Walnut\Module\Notification\Domain\Model\Notification;

#[AutoEventListener]
final readonly class NotificationPersistenceEventListener {

	public function __construct(
		#[WriteModel(Notification::class)]
		private WriteModelRepository $writeModelRepository
	) {}

	public function onNotificationAdded(NotificationAdded $event): void {
		$this->writeModelRepository->store($event->notification);
	}

	public function onNotificationRemoved(NotificationRemoved $event): void {
		$this->writeModelRepository->removeById($event->notification->notificationId);
	}

}