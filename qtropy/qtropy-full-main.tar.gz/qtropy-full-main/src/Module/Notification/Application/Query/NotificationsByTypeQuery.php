<?php

namespace Walnut\Module\Notification\Application\Query;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Notification\Application\Model\NotificationData;
use Walnut\Module\Notification\Domain\Model\NotificationTypeGroup;

interface NotificationsByTypeQuery {
	/**
	 * @param NotificationTypeGroup[] $notificationTypeGroups
	 * @return NotificationData[]
	 */
	public function __invoke(Member $member, array $notificationTypeGroups): array;
}