<?php

namespace Walnut\Module\Notification\Domain\Event;

use Walnut\Module\Notification\Domain\Model\Notification;

final readonly class NotificationRemoved {
	public function __construct(
		public Notification $notification
	) {}
}