<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

use Walnut\Lib\DataType\ArrayData;
use Walnut\Lib\DataType\RefValue;

final readonly class ReceivedExplanationRequest {
	/**
	 * @param NotificationExplanationData[] $requests
	 */
	public function __construct(
		public NotificationContentData $content,
		#[ArrayData(items: new RefValue(NotificationExplanationData::class))]
		public array $requests
	) {}
}