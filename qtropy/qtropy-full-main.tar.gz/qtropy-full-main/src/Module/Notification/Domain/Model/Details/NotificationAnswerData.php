<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

final readonly class NotificationAnswerData {
	public function __construct(
		public NotificationContentData $answer,
		public NotificationMemberData $answeredBy,
	) {}
}