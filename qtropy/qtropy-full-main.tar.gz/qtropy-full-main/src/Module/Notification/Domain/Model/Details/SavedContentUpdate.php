<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Kernel\Domain\Model\MemberId;

final readonly class SavedContentUpdate {
	public function __construct(
		public NotificationContentData $content,
		public NotificationMemberData $member
	) {}
}