<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

final readonly class ReceivedFollowRequest {
	public function __construct(
		public NotificationMemberData $requestedBy
	) {}
}