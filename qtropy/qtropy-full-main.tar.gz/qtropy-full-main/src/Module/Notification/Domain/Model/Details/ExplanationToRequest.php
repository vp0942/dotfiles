<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

final readonly class ExplanationToRequest {
	public function __construct(
		public NotificationContentData $content,
		public NotificationMemberData $member
	) {}
}