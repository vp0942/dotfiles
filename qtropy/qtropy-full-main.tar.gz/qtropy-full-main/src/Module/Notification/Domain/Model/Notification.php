<?php

namespace Walnut\Module\Notification\Domain\Model;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Uuid\Uuid;

final readonly class Notification {
	public function __construct(
		public NotificationId   $notificationId,
		public MemberId         $memberId,
		public string           $message,
		public DateAndTime      $notificationDate,
		public NotificationDetails $details,
		public Uuid|null        $relatedId,
	) {}
}