<?php

namespace Walnut\Module\Notification\Domain\Model;

enum NotificationTypeGroup: int {
	case message        = 1 << 0;
	case contentUpdate  = (1 << 3) | (1 << 4) | (1 << 7) | (1 << 8) | (1 << 11);
	case contentRequest = (1 << 1) | (1 << 2) | (1 << 5) | (1 << 6);
	case followRequest  = (1 << 9) | (1 << 10);

	public static function tryFromKey(string $key): ?self {
		foreach(self::cases() as $case) {
			if ($case->name === $key) {
				return $case;
			}
		}
		return null;
	}

}