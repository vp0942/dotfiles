<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

use Walnut\Module\Content\Domain\Model\ContentType;

final readonly class NotificationContentData {
	public function __construct(
		public string $contentId,
		public string $contentKey,
		public string $title,
		public ContentType $contentType,
	) {}
}