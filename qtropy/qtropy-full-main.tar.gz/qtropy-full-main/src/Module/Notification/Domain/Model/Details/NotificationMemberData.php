<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

final readonly class NotificationMemberData {
	public function __construct(
		public string $memberId,
		public string $username,
		public string|null $profilePicture = null,
	) {}
}