<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

use Walnut\Lib\DataType\ArrayData;
use Walnut\Lib\DataType\RefValue;

final readonly class TrackedQuestionAnswer {
	/**
	 * @param NotificationAnswerData[] $answers
	 */
	public function __construct(
		public NotificationContentData $question,
		#[ArrayData(items: new RefValue(NotificationAnswerData::class))]
		public array $answers
	) {}
}