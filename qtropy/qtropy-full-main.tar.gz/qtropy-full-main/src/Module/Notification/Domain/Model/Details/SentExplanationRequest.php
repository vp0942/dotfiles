<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

final readonly class SentExplanationRequest {
	public function __construct(
		public NotificationContentData $content,
		public NotificationExplanationData $request
	) {}
}