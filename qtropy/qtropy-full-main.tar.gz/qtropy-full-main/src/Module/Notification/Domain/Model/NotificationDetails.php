<?php

namespace Walnut\Module\Notification\Domain\Model;

use ReflectionClass;
use Walnut\Module\Kernel\Exception\ProcessException;

final readonly class NotificationDetails {
	public function __construct(
		public NotificationType $notificationType,
		public object $details,
	) {}

	/**
	 * @param int $notificationType
	 * @param array<string, mixed> $details
	 * @return static
	 */
	public static function fromValues(int $notificationType, array $details): self {
		$t = NotificationType::tryFrom($notificationType) ??
			throw new ProcessException(sprintf("Unrecognized content type: %d", $notificationType));
		$r = new ReflectionClass(__NAMESPACE__ . '\\Details\\' . $t->name);
		return new self(
			$t,
			$r->newInstanceArgs($details)
		);
	}
}