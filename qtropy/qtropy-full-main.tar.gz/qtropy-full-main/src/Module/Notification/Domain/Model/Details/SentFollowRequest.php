<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

final readonly class SentFollowRequest {
	public function __construct(
		public NotificationMemberData $sentTo
	) {}
}