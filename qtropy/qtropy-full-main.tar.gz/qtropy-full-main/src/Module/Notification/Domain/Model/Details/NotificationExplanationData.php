<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

use Walnut\Lib\DataType\ArrayData;
use Walnut\Lib\DataType\ObjectData;
use Walnut\Lib\DataType\StringData;

final readonly class NotificationExplanationData {
	/**
	 * @param array<string, string> $messages
	 */
	public function __construct(
		public NotificationMemberData $member,
		#[ObjectData(additionalProperties: new StringData)]
		public array|object $messages
	) {}
}