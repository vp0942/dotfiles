<?php

namespace Walnut\Module\Notification\Domain\Model;

enum NotificationType: int {
	case Message                    = 1 << 0;

	case SentAnswerRequest          = 1 << 1;
	case ReceivedAnswerRequest      = 1 << 2;
	case AnswerToRequest            = 1 << 3;
	case TrackedQuestionAnswer      = 1 << 4;

	case SentExplanationRequest     = 1 << 5;
	case ReceivedExplanationRequest = 1 << 6;
	//case ExplanationToRequest       = 1 << 7;
	case SavedContentUpdate         = 1 << 8;

	case SentFollowRequest          = 1 << 9;
	case ReceivedFollowRequest      = 1 << 10;

	case SharedNote                 = 1 << 11;

	public static function tryFromKey(string $key): ?self {
		foreach(self::cases() as $case) {
			if ($case->name === $key) {
				return $case;
			}
		}
		return null;
	}

}