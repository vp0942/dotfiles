<?php

namespace Walnut\Module\Notification\Domain\Model\Details;

final readonly class SentAnswerRequest {
	public function __construct(
		public NotificationContentData $question,
		public NotificationMemberData $sentTo
	) {}
}