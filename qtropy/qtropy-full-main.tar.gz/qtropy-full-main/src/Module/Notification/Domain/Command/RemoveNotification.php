<?php

namespace Walnut\Module\Notification\Domain\Command;

use Walnut\Module\Notification\Domain\Event\NotificationRemoved;
use Walnut\Module\Notification\Domain\Model\Notification;

final readonly class RemoveNotification {
	public function __invoke(
		Notification $notification
	): NotificationRemoved {
		return new NotificationRemoved($notification);
	}
}