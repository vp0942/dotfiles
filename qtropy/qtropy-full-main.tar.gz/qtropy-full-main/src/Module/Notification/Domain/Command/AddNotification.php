<?php

namespace Walnut\Module\Notification\Domain\Command;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\SystemTime;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Notification\Domain\Event\NotificationAdded;
use Walnut\Module\Notification\Domain\Model\Notification;
use Walnut\Module\Notification\Domain\Model\NotificationDetails;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Repository\NotificationIdProvider;

final readonly class AddNotification {
	public function __construct(
		private NotificationIdProvider $notificationIdProvider,
		private SystemTime             $systemTime
	) {}

	public function __invoke(
		MemberId $memberId,
		string $message,
		NotificationDetails $details,
		Uuid|null $relatedId
	): NotificationAdded {
		return new NotificationAdded(
			new Notification(
				$this->notificationIdProvider->generateFor(
					$memberId,
					$details->notificationType,
					$relatedId
				),
				$memberId,
				$message,
				$this->systemTime->now(),
				$details,
				$relatedId
			)
		);
	}
}