<?php

namespace Walnut\Module\Notification\Domain\Service;

use Walnut\Module\Notification\Domain\Model\NotificationDetails;

interface NotificationDetailsImporter {
	/** @param array<string, mixed> $details */
	public function fromValues(int $notificationType, array $details): NotificationDetails;
}