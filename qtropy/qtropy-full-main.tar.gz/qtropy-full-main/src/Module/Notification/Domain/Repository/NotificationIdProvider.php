<?php

namespace Walnut\Module\Notification\Domain\Repository;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Notification\Domain\Model\NotificationId;
use Walnut\Module\Notification\Domain\Model\NotificationType;

interface NotificationIdProvider {
	public function findFor(
		MemberId $memberId,
		NotificationType $notificationType,
		Uuid|null $targetId
	): NotificationId|null;

	public function generateFor(
		MemberId $memberId,
		NotificationType $notificationType,
		Uuid|null $targetId
	): NotificationId;
}