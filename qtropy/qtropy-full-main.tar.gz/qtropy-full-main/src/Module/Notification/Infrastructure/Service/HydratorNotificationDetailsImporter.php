<?php

namespace Walnut\Module\Notification\Infrastructure\Service;

use Walnut\Lib\DataType\Exception\InvalidValue;
use Walnut\Lib\DataType\Importer\ClassHydrator;
use Walnut\Module\Kernel\Exception\ProcessException;
use Walnut\Module\Notification\Domain\Model\NotificationDetails;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Service\NotificationDetailsImporter;

final readonly class HydratorNotificationDetailsImporter implements NotificationDetailsImporter {
	public function __construct(
		private ClassHydrator $classHydrator
	) {}

	/** @param array<string, mixed> $details */
	public function fromValues(int $notificationType, array $details): NotificationDetails {
		$t = NotificationType::tryFrom($notificationType) ??
			throw new ProcessException(sprintf("Unrecognized content type: %d", $notificationType));

		$className =
			str_replace(
				'\\NotificationDetails',
				'\\Details\\' . $t->name,
				NotificationDetails::class
			);
		try {
			$detailsValue = $this->classHydrator->importValue($details, $className);
		} catch (\Throwable $e) {
			echo $e->getMessage();
			echo $e;
			die;
		}
		return new NotificationDetails($t, $detailsValue);
	}
}