<?php

namespace Walnut\Module\Notification\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGenerator;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Notification\Domain\Model\Notification;
use Walnut\Module\Notification\Domain\Model\NotificationId;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Repository\NotificationIdProvider;

final readonly class DbNotificationIdProvider implements NotificationIdProvider {
	private const query = "
		SELECT notification_id 
		FROM member_notifications 
		WHERE member_id = :memberId AND related_id = :targetId
    ";

	public function __construct(
		#[WriteModel(Notification::class)]
		private readonly WriteModelIdentityGenerator $identityGenerator,
		private readonly QueryExecutor $queryExecutor,
	) {}

	public function findFor(
		MemberId $memberId,
		NotificationType $notificationType,
		Uuid|null $targetId
	): NotificationId|null {
		$notificationId = $targetId ? $this->queryExecutor->execute(self::query, [
			'memberId' => $memberId->value->binaryValue,
			'targetId' => $targetId->binaryValue
		])->singleValue() : null;
		return $notificationId ?
			new NotificationId(Uuid::fromBinary($notificationId)) :
			null;
	}

	public function generateFor(
		MemberId $memberId,
		NotificationType $notificationType,
		Uuid|null $targetId
	): NotificationId {
		return $this->findFor($memberId, $notificationType, $targetId) ??
			$this->identityGenerator->generateIdentity();
	}
}