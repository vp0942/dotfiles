<?php

namespace Walnut\Module\Notification\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Lib\JsonSerializer\JsonSerializer;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Notification\Application\Model\NotificationData;
use Walnut\Module\Notification\Application\Query\NotificationsByTypeQuery;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Model\NotificationTypeGroup;
use Walnut\Module\Notification\Domain\Service\NotificationDetailsImporter;

final readonly class DbNotificationsByTypeQuery implements NotificationsByTypeQuery {
	private const query = <<<SQL
		SELECT 
		    BIN_TO_UUID(n.notification_id) as notificationId,
		    n.message,
		    n.notification_type AS notificationType,
		    n.details,
		    n.notification_date AS notificationDate,
		    IF(ISNULL(n.related_id), NULL, BIN_TO_UUID(n.related_id)) as relatedId
		FROM member_notifications n
		WHERE n.member_id = :memberId AND n.notification_type IN (%s)
		ORDER BY n.notification_date DESC
SQL;

	public function __construct(
		private NotificationDetailsImporter $notificationDetailsImporter,
		private JsonSerializer $jsonSerializer,
		private QueryExecutor $queryExecutor
	) {}

	/**
	 * @param NotificationTypeGroup[] $notificationTypeGroups
	 * @return NotificationData[]
	 */
	public function __invoke(Member $member, array $notificationTypeGroups): array {
		return array_map($this->toData(...), $this->queryExecutor->execute(
			sprintf(self::query, $this->toSql($notificationTypeGroups)), [
				'memberId' => $member->memberId->value->binaryValue
			]
		)->all());
	}

	/**
	 * @param NotificationTypeGroup[] $notificationTypeGroups
	 * @return string
	 */
	private function toSql(array $notificationTypeGroups): string {
		$notificationTypes = [];
		$notificationTypeGroups = $notificationTypeGroups ?: NotificationTypeGroup::cases();
		foreach(NotificationType::cases() as $notificationType) {
			foreach($notificationTypeGroups as $notificationTypeGroup) {
				if ($notificationType->value & $notificationTypeGroup->value) {
					$notificationTypes[] = $notificationType;
					break;
				}
			}
		}
		return implode(', ', array_map(
			static fn(NotificationType $notificationType): int => $notificationType->value,
			$notificationTypes));
	}

	private function toData(array $row): NotificationData {
		$row['notificationDate'] = new DateAndTime($row['notificationDate']);
		$row['details'] = $this->notificationDetailsImporter->fromValues(
			(int)$row['notificationType'],
			$this->jsonSerializer->decode((string)$row['details'], true)
		);
		unset($row['notificationType']);
		return new NotificationData(... $row);
	}
}