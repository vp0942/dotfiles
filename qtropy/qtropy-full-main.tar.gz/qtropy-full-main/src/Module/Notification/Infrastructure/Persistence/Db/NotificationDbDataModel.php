<?php

namespace Walnut\Module\Notification\Infrastructure\Persistence\Db;

use Walnut\Lib\DbDataModel\Attribute\Fields;
use Walnut\Lib\DbDataModel\Attribute\KeyField;
use Walnut\Lib\DbDataModel\Attribute\ModelRoot;
use Walnut\Lib\DbDataModel\Attribute\Table;

#[ModelRoot('notifications')]
final readonly class NotificationDbDataModel {
	public function __construct(
		#[Table('member_notifications'), KeyField('notification_id'), Fields(
			'member_id', 'message', 'notification_date', 'notification_type',
			'details', 'related_id'
		)]
		public array $notifications,
	) {}
}