<?php

namespace Walnut\Module\Notification\Infrastructure\Persistence\Db;

use Walnut\Lib\JsonSerializer\JsonSerializer;
use Walnut\Lib\WriteModel\Mapper\EntityMapper;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Notification\Domain\Model\Notification;
use Walnut\Module\Notification\Domain\Model\NotificationDetails;
use Walnut\Module\Notification\Domain\Model\NotificationId;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Service\NotificationDetailsImporter;

/**
 * @implements EntityMapper<Notification, NotificationId, array, string>
 */
final readonly class NotificationMapper implements EntityMapper {
	public function __construct(
		private NotificationDetailsImporter $notificationDetailsImporter,
		private JsonSerializer $jsonSerializer
	) {}

	/**
	 * @param Notification $mapped
	 * @return array
	 */
	public function toSourceEntity(object|array $mapped): array {
		return [
			'notification_id' => $mapped->notificationId->value->binaryValue,
			'member_id' => $mapped->memberId->value->binaryValue,
			'message' => $mapped->message,
			'notification_date' => $mapped->notificationDate->format('Y-m-d H:i:s'),
			'notification_type' => $mapped->details->notificationType->value,
			'details' => $this->jsonSerializer->encode($mapped->details->details),
			'related_id' => $mapped->relatedId?->binaryValue ?? null
		];
	}

	/**
	 * @param NotificationId $mapped
	 * @return string
	 */
	public function toSourceId(object|int|string $mapped): string {
		return $mapped->value->binaryValue;
	}

	/**
	 * @param array $source
	 * @return Notification
	 */
	public function fromSourceEntity(object|array $source): Notification {
		return new Notification(
			new NotificationId(Uuid::fromBinary((string)($source['notification_id'] ?? ''))),
			new MemberId(Uuid::fromBinary((string)($source['member_id'] ?? ''))),
			(string)($source['message'] ?? ''),
			new DateAndTime((string)($source['notification_date'] ?? '')),
			$this->notificationDetailsImporter->fromValues(
				(int)($source['notification_type'] ?? ''),
				$this->jsonSerializer->decode((string)($source['details'] ?? ''), true)
			),
			($relatedId = (string)($source['related_id'] ?? '')) ? Uuid::fromBinary($relatedId) : null
		);
	}

	/**
	 * @param string $source
	 * @return NotificationId
	 */
	public function fromSourceId(object|int|string $source): NotificationId {
		return new NotificationId(Uuid::fromBinary($source));
	}
}
