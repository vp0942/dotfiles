<?php

namespace Walnut\Module\Notification\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\NotificationAlerts;
use Walnut\Module\Notification\Application\Query\NotificationsCountQuery;
use Walnut\Module\Notification\Domain\Model\NotificationType;

final readonly class DbNotificationsCountQuery implements NotificationsCountQuery {
	private const query = <<<SQL
		SELECT count(n.notification_id)
		FROM member_notifications n
		WHERE n.member_id = :memberId AND n.notification_type IN (%s)
SQL;

	public function __construct(
		private QueryExecutor $queryExecutor
	) {}

	public function __invoke(Member $member): int {
		return $this->queryExecutor->execute(
			sprintf(self::query, $this->toSql($member->profileDetails->notificationAlerts)), [
				'memberId' => $member->memberId->value->binaryValue
			]
		)->singleValue();
	}

	private function toSql(NotificationAlerts $notificationAlerts): string {
		$notificationTypes = [];
		$notificationTypeGroups = $notificationAlerts->values;
		foreach(NotificationType::cases() as $notificationType) {
			foreach($notificationTypeGroups as $notificationTypeGroup) {
				if ($notificationType->value & $notificationTypeGroup->value) {
					$notificationTypes[] = $notificationType;
					break;
				}
			}
		}
		return implode(', ', array_map(
			static fn(NotificationType $notificationType): int => $notificationType->value,
			$notificationTypes)) ?: '-1';
	}
}