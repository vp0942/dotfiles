<?php

namespace Walnut\Module\Notification\Infrastructure\Delivery\Http\Api;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpDelete;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\JsonResponseBody;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\NoContentResponse;
use Walnut\Module\Notification\Application\Context\_MemberNotification;
use Walnut\Module\Notification\Application\Context\_MemberNotifications;
use Walnut\Module\Notification\Domain\Model\NotificationId;

final readonly class HttpApiNotificationController {
	public function __construct(
		private _MemberNotifications $memberNotifications,
	) {}

	private function getEntry(NotificationId $notificationId): _MemberNotification {
		return $this->memberNotifications->notification($notificationId);
	}

	#[HttpGet('/count'), JsonResponseBody]
	public function notificationsCount(): int {
		return $this->memberNotifications->count();
	}

	#[HttpDelete('/{notificationId}'), NoContentResponse]
	public function removeNotification(
		#[FromRoute] NotificationId $notificationId
	): void {
		$this->getEntry($notificationId)->remove();
	}
}