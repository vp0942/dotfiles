<?php /** @noinspection NestedTernaryOperatorInspection */

namespace Walnut\Module\Notification\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Page\PageViewModelFactory;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Model\NotificationTypeGroup;
use Walnut\Module\Notification\Presentation\View\NotificationListView;
use Walnut\Module\Notification\Presentation\View\NotificationViewBuilder;

final readonly class HttpPageNotificationsController {

	public function __construct(
		private NotificationViewBuilder $notificationViewBuilder,
		private PageViewModelFactory    $pageViewModelFactory,
	) {}

	/**
	 * @param string $notificationAlertTypes
	 * @return NotificationTypeGroup[]
	 */
	private static function searchTypes(string $notificationAlertTypes): array {
		return ($notificationAlertTypes === 'all' ? [] : array_filter(array_map(
			static fn(string $s): ?NotificationTypeGroup => NotificationTypeGroup::tryFromKey($s),
			explode(',', $notificationAlertTypes)
		))) ?: NotificationTypeGroup::cases();
	}

	#[HttpGet('/find/{notificationAlertTypes}'), ViewResponse]
	public function result(
		#[FromRoute] string $notificationAlertTypes = 'all',
	): NotificationListView {
		return $this->notificationViewBuilder->listView(
			self::searchTypes($notificationAlertTypes),
		);
	}

	#[HttpGet('/{notificationAlertTypes}'), ViewResponse]
	public function bySearchType(
		#[FromRoute] string $notificationAlertTypes = 'all',
	): PageViewModel {
		$view = $this->notificationViewBuilder->pageView(
			self::searchTypes($notificationAlertTypes),
		);
		return $this->pageViewModelFactory->page(
			$view->pageTitle,
			$view,
			'notifications',
		);
	}

	#[HttpGet, ViewResponse]
	public function page(
	): PageViewModel {
		return $this->bySearchType();
	}

}