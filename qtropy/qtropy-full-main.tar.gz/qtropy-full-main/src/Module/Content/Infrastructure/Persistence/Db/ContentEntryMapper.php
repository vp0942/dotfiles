<?php

namespace Walnut\Module\Content\Infrastructure\Persistence\Db;

use Walnut\Lib\WriteModel\Mapper\EntityMapper;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentInEditMode;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Content\Domain\Model\ContentTitle;
use Walnut\Module\Content\Domain\Model\ContentType;
use Walnut\Module\Content\Domain\Model\PointFrameContent;
use Walnut\Module\Content\Domain\Model\PublishedContent;
use Walnut\Module\Content\Domain\Model\UnpublishedContent;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Uuid\Uuid;

/**
 * @implements EntityMapper<ContentEntry, ContentId, array, string>
 */
final readonly class ContentEntryMapper implements EntityMapper {
	/**
	 * @param ContentEntry $mapped
	 * @return array
	 */
	public function toSourceEntity(object|array $mapped): array {
		return [
			'content_id' => $mapped->contentId->value->binaryValue,
			'content_key' => $mapped->contentKey->value,
			'author_member_id' => $mapped->authorMemberId->value->binaryValue,
			'date_created' => $mapped->dateCreated->format('Y-m-d H:i:s'),
			'content_type' => $mapped->contentType->value,
			'title' => $mapped->title?->value ?? null,
			'related_entry_id' => $mapped->relatedContentId?->value->binaryValue ?? null,
			'content' => $mapped->pointFrameContent?->content->content ?? null,
			'info' => $mapped->pointFrameContent?->info ?? null,
			'content_revision' => $mapped->pointFrameContent?->draftContent->content ?? null,
			'info_revision' => $mapped->pointFrameContent?->draftInfo ?? null,
			'last_revision_date' => ($mapped->pointFrameContent?->publishedOn ?? null)?->format('Y-m-d H:i:s')
		];
	}

	/**
	 * @param ContentId $mapped
	 * @return string
	 */
	public function toSourceId(object|int|string $mapped): string {
		return $mapped->value->binaryValue;
	}

	private function getContent(array $source): UnpublishedContent|PublishedContent|ContentInEditMode {
		$contentPublished = $source['content'] ?? null;
		$contentDraft = $source['content_revision'] ?? null;
		$infoPublished = $source['info'] ?? '';
		$infoDraft = $source['info_revision'] ?? '';
		$rd = $source['last_revision_date'] ?? null;
		$lastRevisionDate = $rd ? new DateAndTime($rd) : null;

		if ($contentPublished === null || $rd === null) {
			return new UnpublishedContent(new PointFrameContent((string)$contentDraft), $infoDraft);
		}
		return $contentDraft !== null ?
			new ContentInEditMode(
				new PointFrameContent($contentPublished),
                $infoPublished,
				$lastRevisionDate,
				new PointFrameContent($contentDraft),
                $infoDraft
			) : new PublishedContent(
				new PointFrameContent($contentPublished),
                $infoPublished,
				$lastRevisionDate,
			);
	}

	/**
	 * @param array $source
	 * @return ContentEntry
	 */
	public function fromSourceEntity(object|array $source): ContentEntry {
		$contentId = new ContentId(Uuid::fromBinary((string)($source['content_id'] ?? '')));
		$contentKey = new ContentKey((string)($source['content_key'] ?? ''));
		$authorMemberId = new MemberId(Uuid::fromBinary((string)($source['author_member_id'] ?? '')));
		$dateCreated = new DateAndTime((string)($source['date_created'] ?? ''));
		$title = new ContentTitle((string)($source['title'] ?? ''));

		return match(ContentType::tryFrom((int)($source['content_type'] ?? ''))) {
			ContentType::note => ContentEntry::note(
				$contentId, $contentKey, $authorMemberId,
				$dateCreated, $title, $this->getContent($source)
			),
			ContentType::treatise => ContentEntry::treatise(
				$contentId, $contentKey, $authorMemberId,
				$dateCreated, $title, $this->getContent($source)
			),
			ContentType::question => ContentEntry::question(
				$contentId, $contentKey, $authorMemberId,
				$dateCreated, $title, $this->getContent($source)
			),
			ContentType::answer => ContentEntry::answer(
				$contentId, $contentKey, $authorMemberId,
				$dateCreated,
				new ContentId(
					Uuid::fromBinary((string)($source['related_entry_id'] ?? ''))
				), $this->getContent($source)
			),
		};
	}

	/**
	 * @param string $source
	 * @return ContentId
	 */
	public function fromSourceId(object|int|string $source): ContentId {
		return new ContentId(Uuid::fromBinary($source));
	}
}
