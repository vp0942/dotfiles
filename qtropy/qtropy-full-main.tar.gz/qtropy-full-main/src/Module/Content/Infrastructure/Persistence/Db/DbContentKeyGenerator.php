<?php

namespace Walnut\Module\Content\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Content\Domain\Service\ContentKeyGenerator;

final readonly class DbContentKeyGenerator implements ContentKeyGenerator {
	private const QUERY = <<<SQL
		INSERT INTO `content_keys` VALUES (null)
	SQL
	;

	public function __construct(
		private readonly QueryExecutor $queryExecutor
	) {}

	/**
	 * @param string $prefix
	 * @return string
	 */
	public function generateKey(string $prefix): ContentKey {
		$query = self::QUERY;
		$this->queryExecutor->execute($query);
		return new ContentKey($prefix . $this->queryExecutor->lastIdentity());
	}

}