<?php

namespace Walnut\Module\Content\Infrastructure\Persistence\Db;

use Walnut\Lib\DbDataModel\Attribute\Fields;
use Walnut\Lib\DbDataModel\Attribute\KeyField;
use Walnut\Lib\DbDataModel\Attribute\ModelRoot;
use Walnut\Lib\DbDataModel\Attribute\Table;

#[ModelRoot('contentEntries')]
final readonly class ContentEntryDbDataModel {
	public function __construct(
		#[Table('content_entries'), KeyField('content_id'), Fields(
			'content_key', 'content_type', 'title', 'content', 'info',
			'content_revision', 'info_revision', 'author_member_id',
            'related_entry_id', 'date_created', 'last_revision_date'
		)]
		public array $contentEntries,
	) {}
}