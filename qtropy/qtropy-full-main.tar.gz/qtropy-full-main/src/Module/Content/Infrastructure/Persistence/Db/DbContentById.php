<?php

namespace Walnut\Module\Content\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Content\Application\Context\ContentById;
use Walnut\Module\Content\Application\Context\UnknownContent;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Kernel\Uuid\Uuid;

final readonly class DbContentById implements ContentById {
	public function __construct(
		#[WriteModel(ContentEntry::class)]
		private WriteModelRepository $repository,
		private QueryExecutor        $queryExecutor
	) {}

	public function __invoke(ContentId|ContentKey $contentId): ContentEntry {
		if ($contentId instanceof ContentKey) {
			$contentId = new ContentId(
				Uuid::fromBinary(
					$this->queryExecutor->execute(
						"SELECT content_id FROM content_entries WHERE content_key = ?", [
							$contentId->value
						]
					)->singleValue() ?? UnknownContent::withKey($contentId)
				)
			);
		}
		return $this->repository->byId($contentId) ??
			UnknownContent::withId($contentId);
	}
}