<?php

namespace Walnut\Module\Content\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Service\AnswerUniquenessChecker;
use Walnut\Module\Kernel\Domain\Model\MemberId;

final readonly class DbAnswerUniquenessChecker implements AnswerUniquenessChecker {

	public function __construct(
		private QueryExecutor $queryExecutor
	) {}

	public function questionIsAnswered(ContentId $questionId, MemberId $answeredById): string|null {
		return $this->queryExecutor->execute(
			"SELECT BIN_TO_UUID(content_id) FROM content_entries WHERE related_entry_id = ? AND author_member_id = ?", [
				$questionId->value->binaryValue,
				$answeredById->value->binaryValue
			]
		)->singleValue();
	}
}