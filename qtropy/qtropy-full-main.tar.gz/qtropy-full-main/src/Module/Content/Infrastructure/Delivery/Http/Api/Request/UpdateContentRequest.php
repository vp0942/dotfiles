<?php

namespace Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request;

use Walnut\Module\Content\Domain\Model\PointFrameContent;

final readonly class UpdateContentRequest {
	public function __construct(
		public PointFrameContent $content,
		public string $info,
	) {}
}