<?php

namespace Walnut\Module\Content\Infrastructure\Delivery\Http\Api;

use Walnut\Lib\HttpMapper\Attribute\ErrorHandler;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromJsonBody;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpDelete;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpPatch;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpPost;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\JsonResponseBody;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\NoContentResponse;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\RedirectResponse;
use Walnut\Module\Content\Application\Context\_MemberContent;
use Walnut\Module\Content\Application\Context\_MemberContentEntry;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Rejection\IncompatibleState;
use Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request\AddAnswerRequest;
use Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request\AddNoteRequest;
use Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request\AddQuestionRequest;
use Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request\AddTreatiseRequest;
use Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request\UpdateContentRequest;
use Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request\UpdateTitleRequest;

final readonly class HttpApiContentController {
	public function __construct(
		private _MemberContent $memberContent,
	) {}

	private function getEntry(ContentId $contentId): _MemberContentEntry {
		return $this->memberContent->entry($contentId);
	}

	#[HttpPatch('/{contentId}/draft'), NoContentResponse]
	public function editContent(#[FromRoute] ContentId $contentId): void {
		try {
			$this->getEntry($contentId)->startEdit();
		} catch (IncompatibleState) {}
	}

	#[HttpPost('/{contentId}/draft/publish'), NoContentResponse]
	public function publish(#[FromRoute] ContentId $contentId): void {
		$this->getEntry($contentId)->publish();
	}

	#[HttpDelete('/{contentId}/draft'), NoContentResponse]
	public function deleteContentDraft(#[FromRoute] ContentId $contentId): void {
		$this->getEntry($contentId)->discardChanges();
	}

	#[HttpPatch('/{contentId}/title'), NoContentResponse]
	public function updateTitle(
		#[FromRoute] ContentId $contentId,
        #[FromJsonBody] UpdateTitleRequest $updateTitleRequest
	): void {
		$this->getEntry($contentId)->updateTitle($updateTitleRequest->title);
	}

	#[HttpPatch('/{contentId}/draft/content'), NoContentResponse]
	public function updateContent(#[FromRoute] ContentId $contentId, #[FromJsonBody] UpdateContentRequest $updateContentRequest): void {
		try {
			$this->getEntry($contentId)->updateContent($updateContentRequest->content, $updateContentRequest->info);
		} catch (IncompatibleState) {
			$this->getEntry($contentId)->startEdit()->updateContent($updateContentRequest->content, $updateContentRequest->info);
		}
	}

	#[HttpDelete('/{contentId}'), NoContentResponse]
	public function deleteContent(#[FromRoute] ContentId $contentId): void {
		$this->getEntry($contentId)->remove();
	}

	#[HttpPost('/note/draft'), RedirectResponse]
	public function addNote(#[FromJsonBody] AddNoteRequest $addNoteRequest): string {
		return $this->memberContent->createNoteDraft(
			$addNoteRequest->title,
			$addNoteRequest->content
		)->contentKey();
	}

	#[HttpPost('/treatise/draft'), RedirectResponse]
	public function addTreatise(#[FromJsonBody] AddTreatiseRequest $addTreatiseRequest): string {
		return $this->memberContent->createTreatiseDraft(
			$addTreatiseRequest->title,
			$addTreatiseRequest->content
		)->contentKey();
	}

	#[HttpPost('/question/draft'), RedirectResponse]
	public function addQuestionDraft(#[FromJsonBody] AddQuestionRequest $addQuestionRequest): string {
		return $this->memberContent->createQuestionDraft(
			$addQuestionRequest->title,
			$addQuestionRequest->content
		)->contentKey();
	}

	#[HttpPost('/question/{contentId}/answer/draft'), RedirectResponse]
	public function addAnswerDraft(
		#[FromRoute] ContentId $contentId,
		#[FromJsonBody] AddAnswerRequest $addAnswerRequest
	): string {
		return $this->memberContent->question($contentId)->createAnswerDraft(
			$addAnswerRequest->content,
		)->contentKey();
	}

	#[ErrorHandler(IncompatibleState::class), JsonResponseBody(409)]
	public function onIncompatibleState(IncompatibleState $event): array {
		return [
			'error' => $event->getMessage()
		];
	}

}