<?php

namespace Walnut\Module\Content\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromQuery;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\DefaultRouteMatch;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Content\Presentation\AnonymousSearchResultView;
use Walnut\Module\Content\Presentation\IntroPageViewBuilder;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Qtropy\Presentation\AnonymousPageViewModelFactory;

final readonly class HttpPageContentController {
	public function __construct(
		private IntroPageViewBuilder $introPageViewBuilder,
		private AnonymousPageViewModelFactory $anonymousPageViewModelFactory,
	) {}

	//#[HttpGet('/intro'), ViewResponse]
	#[DefaultRouteMatch, ViewResponse]
	public function intro(
	): PageViewModel {
		return $this->anonymousPageViewModelFactory->page(
			'Qtropy',
			$this->introPageViewBuilder->view()
		);
	}

	#[HttpGet('/search'), ViewResponse]
	public function searchContent(
		#[FromQuery] $searchText
	): AnonymousSearchResultView {
		return $this->introPageViewBuilder->searchResultView($searchText);
	}
}