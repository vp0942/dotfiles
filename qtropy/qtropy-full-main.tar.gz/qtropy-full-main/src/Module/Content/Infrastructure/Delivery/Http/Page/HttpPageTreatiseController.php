<?php

namespace Walnut\Module\Content\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Content\Presentation\TreatiseViewBuilder;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Qtropy\Presentation\AnonymousPageViewModelFactory;

final readonly class HttpPageTreatiseController {

	public function __construct(
		private AnonymousPageViewModelFactory $pageViewModelFactory,
		private TreatiseViewBuilder $viewBuilder,
	) {}

	#[HttpGet("/{contentKey}"), ViewResponse]
	public function viewTreatise(
		#[FromRoute('contentKey')] ContentKey $contentKey
	): PageViewModel {
		return $this->pageViewModelFactory->page(
			"Treatise $contentKey",
			$this->viewBuilder->view($contentKey),
		);
	}

}