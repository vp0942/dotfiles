<?php

namespace Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request;

use Walnut\Module\Content\Domain\Model\PointFrameContent;

final readonly class AddAnswerRequest {
	public function __construct(
		public PointFrameContent $content
	) {}
}