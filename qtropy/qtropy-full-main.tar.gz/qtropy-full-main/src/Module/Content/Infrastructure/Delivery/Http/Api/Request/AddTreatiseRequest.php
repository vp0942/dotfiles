<?php

namespace Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request;

use Walnut\Module\Content\Domain\Model\ContentTitle;
use Walnut\Module\Content\Domain\Model\PointFrameContent;

final readonly class AddTreatiseRequest {
	public function __construct(
		public ContentTitle      $title,
		public PointFrameContent $content
	) {}
}