<?php

namespace Walnut\Module\Content\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Content\Presentation\AnswerViewBuilder;
use Walnut\Module\Content\Presentation\QuestionViewBuilder;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Qtropy\Presentation\AnonymousPageViewModelFactory;

final readonly class HttpPageQuestionController {

	public function __construct(
		private AnonymousPageViewModelFactory $pageViewModelFactory,
		private QuestionViewBuilder  $questionViewBuilder,
		private AnswerViewBuilder    $answerViewBuilder,
	) {}

	#[HttpGet("/{questionKey}/answer/{contentKey}"), ViewResponse]
	public function viewAnswer(
		#[FromRoute('questionKey')] ContentKey $questionKey,
		#[FromRoute('contentKey')] ContentKey $contentKey
	): PageViewModel {
		return $this->pageViewModelFactory->page(
			"Answer $contentKey",
			$this->answerViewBuilder->view($questionKey, $contentKey),
			''
		);
	}

	#[HttpGet("/{contentKey}"), ViewResponse]
	public function viewQuestion(
		#[FromRoute('contentKey')] ContentKey $contentKey
	): PageViewModel {
		$view = $this->questionViewBuilder->view($contentKey);
		return $this->pageViewModelFactory->page(
			"Question $contentKey",
			$view,
		);
	}

}