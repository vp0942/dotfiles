<?php

namespace Walnut\Module\Content\Infrastructure\Delivery\Http\Api\Request;

use Walnut\Module\Content\Domain\Model\ContentTitle;

final readonly class UpdateTitleRequest {
	public function __construct(
		public ContentTitle $title
	) {}
}