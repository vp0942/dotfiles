<?php

namespace Walnut\Module\Content\Presentation;

use Walnut\Module\Content\Application\Context\_Content;
use Walnut\Module\Content\Application\Context\UnknownContent;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Application\Context\_MemberFeed;
use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\PointFrameData;
use Walnut\Module\Feed\Application\Model\TreatiseData;
use Walnut\Module\Feed\Presentation\View\Answer\AnswerView;
use Walnut\Module\Feed\Presentation\View\Treatise\TreatiseEditView;
use Walnut\Module\Feed\Presentation\View\Treatise\TreatisePreview;
use Walnut\Module\Feed\Presentation\View\Treatise\TreatiseView;

final readonly class AnswerViewBuilder {

	public function __construct(
		private string $homeUrl,
		private string $loginUrl,
		private string $registerUrl,
		private _Content $content
	) {}

	private function getAnswer(ContentKey $questionKey, ContentKey $answerKey): PointFrameData {
		$answer = $this->content->pointFrame($answerKey);
		if (
			$answer &&
			$answer->contentData instanceof AnswerData &&
			$answer->contentData->question->contentKey == $questionKey
		) {
			return $answer;
		}
		UnknownContent::withKey($answerKey);
	}

	public function view(ContentKey $questionKey, ContentKey $answerKey): ContentView {
		return new ContentView(
			$this->homeUrl,
			$this->registerUrl,
			$this->loginUrl,
			new AnswerView(
				$this->getAnswer($questionKey, $answerKey),
				true
			)
		);
	}
}