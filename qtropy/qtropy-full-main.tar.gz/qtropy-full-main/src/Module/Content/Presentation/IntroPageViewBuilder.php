<?php

namespace Walnut\Module\Content\Presentation;

use Walnut\Module\Content\Application\Context\_Content;
use Walnut\Module\Content\Application\Context\_MemberContent;

final readonly class IntroPageViewBuilder {
	public function __construct(
		private string $loginUrl,
		private string $registerUrl,
		private string $serviceUrl,
		private string $homeUrl,
		private string $videoUrl,

		private _Content $content
	) {}

	public function view(): IntroView {
		return new IntroView(
			$this->loginUrl,
			$this->registerUrl,
			$this->serviceUrl,
			$this->homeUrl,
			$this->videoUrl,
		);
	}

	public function searchResultView(string $searchText): AnonymousSearchResultView {
		return new AnonymousSearchResultView(
			$searchText,
			$this->content->search($searchText)
		);
	}
}