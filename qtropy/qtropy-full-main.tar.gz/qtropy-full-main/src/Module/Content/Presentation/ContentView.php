<?php

namespace Walnut\Module\Content\Presentation;

use Walnut\Module\Feed\Presentation\View\Answer\AnswerView;
use Walnut\Module\Feed\Presentation\View\Question\QuestionView;
use Walnut\Module\Feed\Presentation\View\Treatise\TreatiseView;

final readonly class ContentView {
	public function __construct(
		public string $homeUrl,
		public string $loginUrl,
		public string $registerUrl,
		public QuestionView|AnswerView|TreatiseView $contentView
	) {}
}