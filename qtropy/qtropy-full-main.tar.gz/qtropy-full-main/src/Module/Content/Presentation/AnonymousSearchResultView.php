<?php

namespace Walnut\Module\Content\Presentation;

use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Model\TreatiseData;

final readonly class AnonymousSearchResultView {

	/** @param list<QuestionData|AnswerData|TreatiseData|NoteData> $entries */
	public function __construct(
		public string $searchText,
		public array $entries,
	) {}
}