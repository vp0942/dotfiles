<?php

namespace Walnut\Module\Content\Presentation;

final readonly class IntroView {
	public function __construct(
		public string $loginUrl,
		public string $registerUrl,
		public string $serviceUrl,
		public string $homeUrl,
		public string $videoUrl,
	) {}
}