<?php

namespace Walnut\Module\Content\Presentation;

use Walnut\Module\Content\Application\Context\_Content;
use Walnut\Module\Content\Application\Context\UnknownContent;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Application\Model\PointFrameData;
use Walnut\Module\Feed\Application\Model\TreatiseData;
use Walnut\Module\Feed\Presentation\View\Treatise\TreatiseView;

final readonly class TreatiseViewBuilder {

	public function __construct(
		private string $homeUrl,
		private string $loginUrl,
		private string $registerUrl,
		private _Content $content
	) {}

	private function getTreatise(ContentKey $treatiseKey): PointFrameData {
		$treatise = $this->content->pointFrame($treatiseKey);
		if ($treatise && $treatise->contentData instanceof TreatiseData) {
			return $treatise;
		}
		UnknownContent::withKey($treatiseKey);
	}

	public function view(ContentKey $contentKey): ContentView {
		return new ContentView(
			$this->homeUrl,
			$this->registerUrl,
			$this->loginUrl,
			new TreatiseView(
				$this->getTreatise($contentKey),
				true
			)
		);
	}

}