<?php

namespace Walnut\Module\Content\Domain\Event;

use Walnut\Module\Content\Domain\Model\ContentEntry;

final readonly class EditStarted {
	public function __construct(
		public ContentEntry $content,
		public ContentEntry $previousState
	) {}
}