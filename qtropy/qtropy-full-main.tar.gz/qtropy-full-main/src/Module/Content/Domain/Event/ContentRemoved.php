<?php

namespace Walnut\Module\Content\Domain\Event;

use Walnut\Module\Content\Domain\Model\ContentEntry;

final readonly class ContentRemoved {
	public function __construct(
		public ContentEntry $content
	) {}
}