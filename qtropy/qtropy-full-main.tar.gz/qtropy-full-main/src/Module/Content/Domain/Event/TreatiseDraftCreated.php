<?php

namespace Walnut\Module\Content\Domain\Event;

use Walnut\Module\Content\Domain\Model\ContentEntry;

final readonly class TreatiseDraftCreated {
	public function __construct(
		public ContentEntry $content
	) {}
}