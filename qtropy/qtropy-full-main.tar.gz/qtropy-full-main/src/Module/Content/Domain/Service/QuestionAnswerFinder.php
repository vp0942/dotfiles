<?php

namespace Walnut\Module\Content\Domain\Service;

use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\ContentId;

interface QuestionAnswerFinder {
	/** @return ContentEntry[] */
	public function allAnswersToQuestion(ContentId $contentId): array;
}