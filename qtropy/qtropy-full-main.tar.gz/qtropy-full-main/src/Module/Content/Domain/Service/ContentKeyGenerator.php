<?php

namespace Walnut\Module\Content\Domain\Service;

use Walnut\Module\Content\Domain\Model\ContentKey;

interface ContentKeyGenerator {
	public function generateKey(string $prefix): ContentKey;
}