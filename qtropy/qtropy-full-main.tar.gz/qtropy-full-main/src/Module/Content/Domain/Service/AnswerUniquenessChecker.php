<?php

namespace Walnut\Module\Content\Domain\Service;

use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Kernel\Domain\Model\MemberId;

interface AnswerUniquenessChecker {
	public function questionIsAnswered(ContentId $questionId, MemberId $answeredById): string|null;
}