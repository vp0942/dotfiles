<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Kernel\Domain\Model\MemberId;

final readonly class AnswerDraftAlreadyCreated {
	public function __construct(
		public MemberId $authorMemberId,
		public ContentId $contentId
	) {}
}