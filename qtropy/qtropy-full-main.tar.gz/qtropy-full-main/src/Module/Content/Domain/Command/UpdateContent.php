<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Module\Content\Domain\Event\ContentUpdated;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\PointFrameContent;

final readonly class UpdateContent {
	public function __invoke(
		ContentEntry $content,
		PointFrameContent $pointFrameContent,
        string $info
	): ContentUpdated {
		return new ContentUpdated(
			$content->withNewDraftContent($pointFrameContent, $info),
			$content,
		);
	}
}