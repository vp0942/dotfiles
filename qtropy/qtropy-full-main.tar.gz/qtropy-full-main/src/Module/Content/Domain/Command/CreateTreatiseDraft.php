<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGenerator;
use Walnut\Module\Content\Domain\Event\TreatiseDraftCreated;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\ContentTitle;
use Walnut\Module\Content\Domain\Model\PointFrameContent;
use Walnut\Module\Content\Domain\Model\UnpublishedContent;
use Walnut\Module\Content\Domain\Service\ContentKeyGenerator;
use Walnut\Module\Kernel\Time\SystemTime;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class CreateTreatiseDraft {
	public function __construct(
		private SystemTime                  $systemTime,
		#[WriteModel(ContentEntry::class)]
		private WriteModelIdentityGenerator $identityGenerator,
		private ContentKeyGenerator         $contentKeyGenerator,
	) {}

	public function __invoke(
		Member $authorMember,
		ContentTitle $contentTitle,
		PointFrameContent $pointFrameContent,
	): TreatiseDraftCreated {
		return new TreatiseDraftCreated(
			ContentEntry::treatise(
				$this->identityGenerator->generateIdentity(),
				$this->contentKeyGenerator->generateKey('T-'),
				$authorMember->memberId,
				$this->systemTime->now(),
				$contentTitle,
				new UnpublishedContent($pointFrameContent, '')
			)
		);
	}
}