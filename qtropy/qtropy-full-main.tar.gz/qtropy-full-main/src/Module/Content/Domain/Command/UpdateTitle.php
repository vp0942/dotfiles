<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Module\Content\Domain\Event\TitleUpdated;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\ContentTitle;

final readonly class UpdateTitle {
	public function __invoke(
		ContentEntry $content,
		ContentTitle $newTitle
	): TitleUpdated {
		return new TitleUpdated(
			$content->withNewTitle($newTitle),
			$content,
		);
	}
}