<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Module\Content\Domain\Event\ChangesPublished;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Kernel\Time\SystemTime;

final readonly class PublishChanges {
	public function __construct(
		private SystemTime $systemTime,
	) {}

	public function __invoke(
		ContentEntry $content
	): ChangesPublished {
		return new ChangesPublished(
			$content->withPublishedChanges($this->systemTime->now()),
			$content,
		);
	}
}