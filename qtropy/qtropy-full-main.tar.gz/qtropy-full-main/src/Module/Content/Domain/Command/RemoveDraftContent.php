<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Module\Content\Domain\Event\DraftContentRemoved;
use Walnut\Module\Content\Domain\Model\ContentEntry;

final readonly class RemoveDraftContent {
	public function __invoke(
		ContentEntry $content
	): DraftContentRemoved {
		return new DraftContentRemoved($content);
	}
}