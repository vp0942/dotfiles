<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Module\Content\Domain\Event\ContentRemoved;
use Walnut\Module\Content\Domain\Model\ContentEntry;

final readonly class RemoveContent {
	public function __invoke(
		ContentEntry $content
	): ContentRemoved {
		return new ContentRemoved($content);
	}
}