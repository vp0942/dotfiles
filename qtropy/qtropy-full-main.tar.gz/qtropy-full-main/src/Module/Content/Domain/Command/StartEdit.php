<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Module\Content\Domain\Event\EditStarted;
use Walnut\Module\Content\Domain\Model\ContentEntry;

final readonly class StartEdit {
	public function __invoke(
		ContentEntry $content
	): EditStarted {
		return new EditStarted(
			$content->inEditMode(),
			$content,
		);
	}
}