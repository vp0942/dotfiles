<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Module\Content\Domain\Event\ChangesDiscarded;
use Walnut\Module\Content\Domain\Event\ContentRemoved;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\UnpublishedContent;

final readonly class DiscardChanges {
	public function __invoke(
		ContentEntry $content
	): ChangesDiscarded|ContentRemoved {
		if ($content->pointFrameContent instanceof UnpublishedContent) {
			return new ContentRemoved($content);
		}
		return new ChangesDiscarded(
			$content->withDiscardedChanges(),
			$content,
		);
	}
}