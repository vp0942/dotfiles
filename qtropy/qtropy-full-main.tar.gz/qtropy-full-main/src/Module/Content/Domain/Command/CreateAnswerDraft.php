<?php

namespace Walnut\Module\Content\Domain\Command;

use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGenerator;
use Walnut\Module\Content\Domain\Event\AnswerDraftCreated;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentType;
use Walnut\Module\Content\Domain\Model\PointFrameContent;
use Walnut\Module\Content\Domain\Model\UnpublishedContent;
use Walnut\Module\Content\Domain\Rejection\IncompatibleState;
use Walnut\Module\Content\Domain\Service\AnswerUniquenessChecker;
use Walnut\Module\Content\Domain\Service\ContentKeyGenerator;
use Walnut\Module\Kernel\Time\SystemTime;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class CreateAnswerDraft {
	public function __construct(
		private SystemTime                  $systemTime,
		#[WriteModel(ContentEntry::class)]
		private WriteModelIdentityGenerator $identityGenerator,
		private ContentKeyGenerator         $contentKeyGenerator,
		private AnswerUniquenessChecker     $answerUniquenessChecker,
	) {}

	public function __invoke(
		Member $authorMember,
		ContentEntry $question,
		PointFrameContent $pointFrameContent,
	): AnswerDraftCreated|AnswerDraftAlreadyCreated {
		if ($question->contentType !== ContentType::question) {
			IncompatibleState::canOnlyAnswerToQuestions();
		}
		if ($aId = $this->answerUniquenessChecker->questionIsAnswered(
			$question->contentId,
			$authorMember->memberId
		)) {
			return new AnswerDraftAlreadyCreated(
				$authorMember->memberId,
				new ContentId(Uuid::fromString($aId))
			);
			//IncompatibleState::cannotAnswerTwice();
		}
		return new AnswerDraftCreated(
			ContentEntry::answer(
				$this->identityGenerator->generateIdentity(),
				$this->contentKeyGenerator->generateKey($question->contentKey . '-A-'),
				$authorMember->memberId,
				$this->systemTime->now(),
				$question->contentId,
				new UnpublishedContent($pointFrameContent, '')
			)
		);
	}
}