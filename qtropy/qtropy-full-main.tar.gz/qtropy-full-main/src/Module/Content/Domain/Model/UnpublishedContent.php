<?php

namespace Walnut\Module\Content\Domain\Model;

use Walnut\Module\Kernel\Time\DateAndTime;

final readonly class UnpublishedContent {
	public function __construct(
		public PointFrameContent $draftContent,
		public string $draftInfo,
	) {}

	public function withUpdatedContent(PointFrameContent $newContent, string $newInfo): self {
		return new self($newContent, $newInfo);
	}

	public function asPublished(DateAndTime $publishedOn): PublishedContent {
		return new PublishedContent($this->draftContent, $this->draftInfo, $publishedOn);
	}
}