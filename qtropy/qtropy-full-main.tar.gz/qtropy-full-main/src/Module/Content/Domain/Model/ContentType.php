<?php

namespace Walnut\Module\Content\Domain\Model;

enum ContentType: int {
	case question = 1;
	case answer = 2;
	case treatise = 3;
	case note = 4;
}