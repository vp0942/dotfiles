<?php

namespace Walnut\Module\Content\Domain\Model;

use Walnut\Lib\DataType\WrapperData;

#[WrapperData]
final readonly class ContentKey {
	public function __construct(
		public string $value
	) {}

	public function __toString(): string {
		return $this->value;
	}
}