<?php

namespace Walnut\Module\Content\Domain\Model;

use Walnut\Module\Kernel\Time\DateAndTime;

final readonly class ContentInEditMode {
	public function __construct(
		public PointFrameContent $content,
        public string            $info,
		public DateAndTime       $publishedOn,
		public PointFrameContent $draftContent,
		public string            $draftInfo,
	) {}

	public function withUpdatedContent(PointFrameContent $newContent, string $newInfo): self {
		return new self($this->content, $this->info, $this->publishedOn, $newContent, $newInfo);
	}

	public function asDiscarded(): PublishedContent {
		return new PublishedContent($this->content, $this->info, $this->publishedOn);
	}

	public function asPublished(DateAndTime $publishedOn): PublishedContent {
		return new PublishedContent($this->draftContent, $this->draftInfo, $publishedOn);
	}
}