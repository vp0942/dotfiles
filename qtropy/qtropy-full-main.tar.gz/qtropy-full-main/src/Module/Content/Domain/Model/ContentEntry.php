<?php

namespace Walnut\Module\Content\Domain\Model;

use Walnut\Module\Content\Domain\Rejection\IncompatibleState;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Util\Wither;

final readonly class ContentEntry {
	use Wither;
	public function __construct(
		public ContentId                                                  $contentId,
		public ContentKey                                                 $contentKey,
		public ContentType                                                $contentType,
		public MemberId                                                   $authorMemberId,
		public ContentId|null                                             $relatedContentId,
		public DateAndTime                                                $dateCreated,
		public ContentTitle|null                                          $title,
		public UnpublishedContent|PublishedContent|ContentInEditMode|null $pointFrameContent,
	) {}

	public static function note(
		ContentId $contentId,
		ContentKey $contentKey,
		MemberId $authorMemberId,
		DateAndTime $dateCreated,
		ContentTitle|null $title,
		UnpublishedContent|PublishedContent|ContentInEditMode $pointFrameContent,
	): self {
		return new self(
			$contentId, $contentKey, ContentType::note,
			$authorMemberId, null, $dateCreated,
			$title, $pointFrameContent
		);
	}

	public static function treatise(
		ContentId $contentId,
		ContentKey $contentKey,
		MemberId $authorMemberId,
		DateAndTime $dateCreated,
		ContentTitle|null $title,
		UnpublishedContent|PublishedContent|ContentInEditMode $pointFrameContent,
	): self {
		return new self(
			$contentId, $contentKey, ContentType::treatise,
			$authorMemberId, null, $dateCreated,
			$title, $pointFrameContent
		);
	}

	public static function question(
		ContentId $contentId,
		ContentKey $contentKey,
		MemberId $authorMemberId,
		DateAndTime $dateCreated,
		ContentTitle|null $title,
		UnpublishedContent|PublishedContent $pointFrameContent,
	): self {
		return new self(
			$contentId, $contentKey, ContentType::question,
			$authorMemberId, null, $dateCreated,
			$title, $pointFrameContent
		);
	}

	public static function answer(
		ContentId $contentId,
		ContentKey $contentKey,
		MemberId $authorMemberId,
		DateAndTime $dateCreated,
		ContentId $questionId,
		UnpublishedContent|PublishedContent|ContentInEditMode $pointFrameContent,
	): self {
		return new self(
			$contentId, $contentKey, ContentType::answer,
			$authorMemberId, $questionId, $dateCreated,
			null, $pointFrameContent
		);
	}

	/** @throws IncompatibleState */
	public function withNewTitle(ContentTitle $newTitle): self {
		return $this->title instanceof ContentTitle ?
			$this->with(title: $newTitle) :
			IncompatibleState::unableToSetTitle();
	}

	/** @throws IncompatibleState */
	public function withNewDraftContent(PointFrameContent $newContent, string $newInfo): self {
		return ($this->pointFrameContent instanceof UnpublishedContent) ||
			   ($this->pointFrameContent instanceof ContentInEditMode) ?
			$this->with(pointFrameContent: $this->pointFrameContent->withUpdatedContent($newContent, $newInfo)) :
			IncompatibleState::noDraftContentAvailable();
	}

	/** @throws IncompatibleState */
	public function inEditMode(): self {
		return $this->pointFrameContent instanceof PublishedContent ?
			$this->with(pointFrameContent: $this->pointFrameContent->inEditMode()) :
			IncompatibleState::cannotSwitchToEditMode();
	}

	/** @throws IncompatibleState */
	public function withDiscardedChanges(): self {
		return $this->pointFrameContent instanceof ContentInEditMode ?
			$this->with(pointFrameContent: $this->pointFrameContent->asDiscarded()) :
			IncompatibleState::contentIsNotInEditMode();
	}

	/** @throws IncompatibleState */
	public function withPublishedChanges(DateAndTime $publishOn): self {
		return ($this->pointFrameContent instanceof UnpublishedContent) ||
			   ($this->pointFrameContent instanceof ContentInEditMode) ?
			$this->with(pointFrameContent: $this->pointFrameContent->asPublished($publishOn)) :
			IncompatibleState::noDraftContentAvailable();
	}

}