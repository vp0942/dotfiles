<?php

namespace Walnut\Module\Content\Domain\Model;

use Walnut\Module\Kernel\Time\DateAndTime;

final readonly class PublishedContent {
	public function __construct(
		public PointFrameContent $content,
		public string            $info,
		public DateAndTime       $publishedOn,
	) {}

	public function inEditMode(): ContentInEditMode {
		return new ContentInEditMode(
			$this->content,
			$this->info,
			$this->publishedOn,
			$this->content,
            $this->info
		);
	}
}