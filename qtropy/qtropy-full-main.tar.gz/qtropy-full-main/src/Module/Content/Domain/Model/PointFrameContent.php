<?php

namespace Walnut\Module\Content\Domain\Model;

use Walnut\Lib\DataType\WrapperData;

#[WrapperData]
final readonly class PointFrameContent {
	public function __construct(
		public string $content
	) {}
}