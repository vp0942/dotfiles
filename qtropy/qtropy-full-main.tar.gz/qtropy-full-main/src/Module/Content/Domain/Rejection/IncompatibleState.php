<?php

namespace Walnut\Module\Content\Domain\Rejection;

use Walnut\Module\Kernel\Exception\ProcessException;

final class IncompatibleState extends ProcessException {

	private const cannotSwitchToEditMode = 'Cannot switch to edit mode';
	public static function cannotSwitchToEditMode(): never {
		throw new self(self::cannotSwitchToEditMode);
	}

	private const contentIsAlreadyInEditMode = 'Content is already in edit mode';
	public static function contentIsAlreadyInEditMode(): never {
		throw new self(self::contentIsAlreadyInEditMode);
	}

	private const contentIsNotInEditMode = 'Content is not in edit mode';
	public static function contentIsNotInEditMode(): never {
		throw new self(self::contentIsNotInEditMode);
	}

	private const noDraftContentAvailable = 'No draft content available';
	public static function noDraftContentAvailable(): never {
		throw new self(self::noDraftContentAvailable);
	}

	private const unableToSetTitle = 'Unable to set title';
	public static function unableToSetTitle(): never {
		throw new self(self::unableToSetTitle);
	}

	private const canOnlyAnswerToQuestions = 'Only questions can be answered';
	public static function canOnlyAnswerToQuestions(): never {
		throw new self(self::canOnlyAnswerToQuestions);
	}

	private const cannotAnswerTwice = 'Cannot answer to a question twice';
	public static function cannotAnswerTwice(): never {
		throw new self(self::cannotAnswerTwice);
	}
}