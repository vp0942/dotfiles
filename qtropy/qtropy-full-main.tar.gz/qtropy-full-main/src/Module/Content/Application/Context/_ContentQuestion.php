<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\ReturnValueBuilder;
use Walnut\Module\Content\Domain\Command\CreateAnswerDraft;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\PointFrameContent;
use Walnut\Module\Member\Domain\Model\Member;

#[DataContext(['member' => Member::class, 'content' => ContentEntry::class])]
interface _ContentQuestion {
	#[DomainCommand(CreateAnswerDraft::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('content'),
		new FunctionParameter('pointFrameContent'),
	)), ReturnValueBuilder(NewContentResult::class, new ParameterList(
		new ContextParameter('member')
	))]
	public function createAnswerDraft(
		PointFrameContent $pointFrameContent
	): _MemberContentEntry;
}