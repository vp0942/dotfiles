<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterBuilder;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\Reference;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\ReturnValueBuilder;
use Walnut\Module\Content\Domain\Command\CreateNoteDraft;
use Walnut\Module\Content\Domain\Command\CreateQuestionDraft;
use Walnut\Module\Content\Domain\Command\CreateTreatiseDraft;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentTitle;
use Walnut\Module\Content\Domain\Model\PointFrameContent;
use Walnut\Module\Member\Domain\Model\Member;

#[DataContext(Member::class)]
interface _MemberContent {
	#[DomainCommand(CreateNoteDraft::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('contentTitle'),
		new FunctionParameter('pointFrameContent'),
	)), ReturnValueBuilder(NewContentResult::class)]
	public function createNoteDraft(
		ContentTitle $contentTitle,
		PointFrameContent $pointFrameContent
	): _MemberContentEntry;

	#[DomainCommand(CreateTreatiseDraft::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('contentTitle'),
		new FunctionParameter('pointFrameContent'),
	)), ReturnValueBuilder(NewContentResult::class)]
	public function createTreatiseDraft(
		ContentTitle $contentTitle,
		PointFrameContent $pointFrameContent
	): _MemberContentEntry;

	#[DomainCommand(CreateQuestionDraft::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('contentTitle'),
		new FunctionParameter('pointFrameContent'),
	)), ReturnValueBuilder(NewContentResult::class)]
	public function createQuestionDraft(
		ContentTitle $contentTitle,
		PointFrameContent $pointFrameContent
	): _MemberContentEntry;

	#[Reference(_MemberContentEntry::class, new ParameterList(
		new ParameterBuilder(
			ContentById::class,
			new ParameterList(
				new FunctionParameter('contentId')
			)
		)
	))]
	public function entry(ContentId $contentId): _MemberContentEntry;

	#[Reference(_ContentQuestion::class, new ParameterList(
		new ContextParameter,
		new ParameterBuilder(
			ContentById::class,
			new ParameterList(
				new FunctionParameter('contentId')
			)
		)
	))]
	public function question(ContentId $contentId): _ContentQuestion;
}