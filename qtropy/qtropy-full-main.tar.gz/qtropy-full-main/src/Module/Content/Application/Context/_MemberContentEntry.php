<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\ReturnValueBuilder;
use Walnut\Module\Content\Domain\Command\DiscardChanges;
use Walnut\Module\Content\Domain\Command\PublishChanges;
use Walnut\Module\Content\Domain\Command\StartEdit;
use Walnut\Module\Content\Domain\Command\UpdateContent;
use Walnut\Module\Content\Domain\Command\UpdateTitle;
use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Command\RemoveContent;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Content\Domain\Model\ContentTitle;
use Walnut\Module\Content\Domain\Model\PointFrameContent;

#[DataContext(ContentEntry::class)]
interface _MemberContentEntry {
	#[DomainCommand(UpdateTitle::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('newTitle'),
	)), ReturnValueBuilder(UpdatedContentResult::class)]
	public function updateTitle(ContentTitle $newTitle): _MemberContentEntry;

	#[DomainCommand(StartEdit::class, new ParameterList(
		new ContextParameter,
	)), ReturnValueBuilder(UpdatedContentResult::class)]
	public function startEdit(): _MemberContentEntry;

	#[DomainCommand(UpdateContent::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('newContent'),
		new FunctionParameter('newInfo')
	)), ReturnValueBuilder(UpdatedContentResult::class)]
	public function updateContent(PointFrameContent $newContent, string $newInfo): _MemberContentEntry;

	#[DomainCommand(DiscardChanges::class, new ParameterList(
		new ContextParameter,
	))/*, ReturnValueBuilder(UpdatedContentResult::class)*/]
	public function discardChanges(): void;// _MemberContentEntry;

	#[DomainCommand(PublishChanges::class, new ParameterList(
		new ContextParameter,
	)), ReturnValueBuilder(UpdatedContentResult::class)]
	public function publish(): _MemberContentEntry;

	#[DataQuery(IdOfContent::class, new ParameterList(
		new ContextParameter,
	))]
	public function contentId(): ContentId;

	#[DataQuery(KeyOfContent::class, new ParameterList(
		new ContextParameter,
	))]
	public function contentKey(): ContentKey;

	#[DomainCommand(RemoveContent::class, new ParameterList(
		new ContextParameter,
	))]
	public function remove(): void;

}