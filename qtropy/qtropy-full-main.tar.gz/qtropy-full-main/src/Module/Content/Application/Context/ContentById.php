<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentKey;

interface ContentById {
	public function __invoke(ContentId|ContentKey $contentId): ContentEntry;
}