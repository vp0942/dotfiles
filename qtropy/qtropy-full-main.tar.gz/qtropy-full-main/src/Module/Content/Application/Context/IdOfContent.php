<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentEntry;

final readonly class IdOfContent {
	public function __invoke(ContentEntry $content): ContentId {
		return $content->contentId;
	}
}