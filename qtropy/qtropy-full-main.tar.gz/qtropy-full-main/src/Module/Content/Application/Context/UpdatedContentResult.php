<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Module\Content\Domain\Event\ChangesDiscarded;
use Walnut\Module\Content\Domain\Event\ChangesPublished;
use Walnut\Module\Content\Domain\Event\ContentUpdated;
use Walnut\Module\Content\Domain\Event\EditStarted;
use Walnut\Module\Content\Domain\Event\TitleUpdated;
use Walnut\Module\Member\Application\Context\_Members;

final readonly class UpdatedContentResult {
	public function __construct(
		private _Members $members
	) {}

	public function __invoke(TitleUpdated|ContentUpdated|EditStarted|ChangesDiscarded|ChangesPublished $event): _MemberContentEntry {
		return $this->members->member($event->content->authorMemberId)
			->content()->entry($event->content->contentId);
	}

}