<?php

namespace Walnut\Module\Content\Application\Context;

use InvalidArgumentException;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentKey;

final class UnknownContent extends InvalidArgumentException {
	private const unknownId = "Content with ID '%s' cannot be found";
	public static function withId(ContentId $contentId): never {
		throw new self(sprintf(self::unknownId, (string)$contentId));
	}

	private const unknownKey = "Content with key '%s' cannot be found";
	public static function withKey(ContentKey $contentKey): never {
		throw new self(sprintf(self::unknownKey, (string)$contentKey));
	}
}