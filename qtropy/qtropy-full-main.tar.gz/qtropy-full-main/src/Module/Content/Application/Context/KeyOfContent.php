<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Module\Content\Domain\Model\ContentEntry;
use Walnut\Module\Content\Domain\Model\ContentKey;

final readonly class KeyOfContent {
	public function __invoke(ContentEntry $content): ContentKey {
		return $content->contentKey;
	}
}