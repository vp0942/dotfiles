<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Module\Content\Application\Query\AnonymousAnswersQuery;
use Walnut\Module\Content\Application\Query\AnonymousContentSearchQuery;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Model\PointFrameData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Model\TreatiseData;
use Walnut\Module\Feed\Application\Query\PointFrame\ContentPointFrameQuery;

interface _Content {
	/** @return list<QuestionData|AnswerData|TreatiseData|NoteData> */
	#[DataQuery(AnonymousContentSearchQuery::class, new ParameterList(
		new FunctionParameter('searchText')
	))]
	public function search(string $searchText): array;

	#[DataQuery(ContentPointFrameQuery::class, new ParameterList(
		new FunctionParameter('contentKey')
	))]
	public function pointFrame(ContentKey $contentKey): PointFrameData|null;

	/** @return AnswerData[] */
	#[DataQuery(AnonymousAnswersQuery::class, new ParameterList(
		new FunctionParameter('contentKey')
	))]
	public function answersTo(ContentKey $contentKey): array;
}