<?php

namespace Walnut\Module\Content\Application\Context;

use Walnut\Module\Content\Domain\Command\AnswerDraftAlreadyCreated;
use Walnut\Module\Content\Domain\Event\AnswerDraftCreated;
use Walnut\Module\Content\Domain\Event\NoteDraftCreated;
use Walnut\Module\Content\Domain\Event\QuestionCreated;
use Walnut\Module\Content\Domain\Event\TreatiseDraftCreated;
use Walnut\Module\Member\Application\Context\_Members;

final readonly class NewContentResult {
	public function __construct(
		private _Members $members
	) {}

	public function __invoke(NoteDraftCreated|TreatiseDraftCreated|QuestionCreated|AnswerDraftCreated|AnswerDraftAlreadyCreated $event): _MemberContentEntry {
		$memberId = $event instanceof AnswerDraftAlreadyCreated ? $event->authorMemberId : $event->content->authorMemberId;
		$contentId = $event instanceof AnswerDraftAlreadyCreated ? $event->contentId : $event->content->contentId;
		return $this->members->member($memberId)
			->content()->entry($contentId);
	}

}