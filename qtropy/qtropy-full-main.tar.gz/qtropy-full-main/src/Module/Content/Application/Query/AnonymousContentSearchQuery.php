<?php

namespace Walnut\Module\Content\Application\Query;

use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Model\TreatiseData;
use Walnut\Module\Feed\Application\Query\Search\ContentSearch;
use Walnut\Module\Feed\Application\Query\Search\ContentSearchQuery;
use Walnut\Module\Member\Application\Context\AnonymousMember;

final readonly class AnonymousContentSearchQuery {
	public function __construct(
		private AnonymousMember $anonymousMember,
		private ContentSearchQuery $contentSearchQuery
	) {}

	/** @return list<QuestionData|AnswerData|TreatiseData|NoteData> */
	public function __invoke(string $searchText): array {
		return ($this->contentSearchQuery)(
			($this->anonymousMember)(),
			new ContentSearch(
				[],
				$searchText,
				null,
				null,
				null,
			)
		);
	}
}