<?php

namespace Walnut\Module\Content\Application\Query;

use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Query\Answers\AnswersQuery;
use Walnut\Module\Member\Application\Context\AnonymousMember;

final readonly class AnonymousAnswersQuery {
	public function __construct(
		private AnonymousMember $anonymousMember,
		private AnswersQuery $answersQuery
	) {}

	/** @return AnswerData[] */
	public function __invoke(
		ContentKey $contentKey
	): array {
		return ($this->answersQuery)(
			($this->anonymousMember)(),
			$contentKey
		);
	}
}