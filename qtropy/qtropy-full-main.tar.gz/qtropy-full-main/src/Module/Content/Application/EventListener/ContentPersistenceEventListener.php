<?php

namespace Walnut\Module\Content\Application\EventListener;

use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Content\Domain\Event\AnswerDraftCreated;
use Walnut\Module\Content\Domain\Event\ChangesDiscarded;
use Walnut\Module\Content\Domain\Event\ChangesPublished;
use Walnut\Module\Content\Domain\Event\ContentRemoved;
use Walnut\Module\Content\Domain\Event\ContentUpdated;
use Walnut\Module\Content\Domain\Event\EditStarted;
use Walnut\Module\Content\Domain\Event\NoteDraftCreated;
use Walnut\Module\Content\Domain\Event\QuestionCreated;
use Walnut\Module\Content\Domain\Event\TitleUpdated;
use Walnut\Module\Content\Domain\Event\TreatiseDraftCreated;
use Walnut\Module\Content\Domain\Model\ContentEntry;

#[AutoEventListener]
final readonly class ContentPersistenceEventListener {

	public function __construct(
		#[WriteModel(ContentEntry::class)]
		private WriteModelRepository $writeModelRepository
	) {}

	public function onContentCreatedOrUpdated(NoteDraftCreated|TreatiseDraftCreated|QuestionCreated|AnswerDraftCreated|ChangesDiscarded|ChangesPublished|TitleUpdated|ContentUpdated|EditStarted $event): void {
		$this->writeModelRepository->store($event->content);
	}

	public function onContentRemoved(ContentRemoved $event): void {
		$this->writeModelRepository->removeById($event->content->contentId);
	}

}