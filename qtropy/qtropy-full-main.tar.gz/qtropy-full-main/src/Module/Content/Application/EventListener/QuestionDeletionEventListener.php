<?php

namespace Walnut\Module\Content\Application\EventListener;

use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\EventBus\EventBus;
use Walnut\Lib\EventBus\EventListenerPriority;
use Walnut\Lib\EventBus\EventPriority;
use Walnut\Module\Content\Domain\Command\RemoveContent;
use Walnut\Module\Content\Domain\Event\ContentRemoved;
use Walnut\Module\Content\Domain\Model\ContentType;
use Walnut\Module\Content\Domain\Service\QuestionAnswerFinder;

#[AutoEventListener]
final readonly class QuestionDeletionEventListener {
	public function __construct(
		private QuestionAnswerFinder $questionAnswerFinder,
		private EventBus             $eventBus,
		private RemoveContent        $removeContent,
	) {}

	#[EventListenerPriority(EventPriority::high)]
	public function onContentRemoved(ContentRemoved $event): void {
		if ($event->content->contentType === ContentType::question) {
			foreach($this->questionAnswerFinder->allAnswersToQuestion($event->content->contentId) as $answer) {
				$this->eventBus->dispatchEvent(($this->removeContent)($answer));
			}
		}
	}

}