<?php

namespace Walnut\Module\Qtropy\Application\Model;

final readonly class ContactMessageData {
	public function __construct(
		public string $subject,
		public string $body,
	) {}
}