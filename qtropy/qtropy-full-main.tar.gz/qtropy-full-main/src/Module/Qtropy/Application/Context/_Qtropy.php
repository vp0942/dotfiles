<?php

namespace Walnut\Module\Qtropy\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\Reference;
use Walnut\Module\Content\Application\Context\_Content;
use Walnut\Module\Member\Application\Context\_Members;

interface _Qtropy {
	#[Reference(_Members::class)]
	public function members(): _Members;

	#[Reference(_Content::class)]
	public function content(): _Content;
}