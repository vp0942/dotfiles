<?php

namespace Walnut\Module\Qtropy\Application\Context;

use Walnut\App\Email\EmailAddress;
use Walnut\App\Email\EmailMessage;
use Walnut\App\Email\EmailSender;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Qtropy\Application\Model\ContactMessageData;

final readonly class ContactQtropy {
	public function __construct(
		private EmailSender $emailSender,
		private string      $contactEmailAddress,
		private string      $formattedSubject
	) {}

	public function __invoke(
		Member $member,
		ContactMessageData $messageData
	): void {
		$this->emailSender->send(
			new EmailAddress($this->contactEmailAddress),
			new EmailMessage(
				sprintf($this->formattedSubject,
					"$member->username ($member->emailAddress)",
					$messageData->subject),
				$messageData->body
			)
		);
	}
}