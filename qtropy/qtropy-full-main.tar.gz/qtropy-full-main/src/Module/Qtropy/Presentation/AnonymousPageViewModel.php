<?php

namespace Walnut\Module\Qtropy\Presentation;

use Walnut\Module\Kernel\Page\PageViewModel;

final class AnonymousPageViewModel implements PageViewModel {
	public function __construct(
		public string              $basePath,
		public string              $pageTitle,
		public string              $tokenName,
		public string              $loginUrl,
		public PageContent         $content,
		public string              $webComponents,
	) {}
}