<?php

namespace Walnut\Module\Qtropy\Presentation;

use Walnut\Module\Qtropy\Presentation\WebComponent\WebComponentGenerator;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Page\PageViewModelFactory;

final readonly class AnonymousPageViewModelFactory {
	public function __construct(
		private WebComponentGenerator $webComponentGenerator,
		private PageContentRenderer   $pageContentRenderer,
		private string                $basePath,
		private string                $loginUrl,
		private string                $tokenName,
	) {}

	public function page(
		string $pageTitle,
		object $content
	): PageViewModel {
		return new AnonymousPageViewModel(
			$this->basePath,
			$pageTitle,
			$this->tokenName,
			$this->loginUrl,
			$content instanceof PageContent ? $content :
				$this->pageContentRenderer->render($content),
			$this->webComponentGenerator->render()
		);
	}
}