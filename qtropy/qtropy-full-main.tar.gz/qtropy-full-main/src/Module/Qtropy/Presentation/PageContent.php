<?php

namespace Walnut\Module\Qtropy\Presentation;

final readonly class PageContent {

	public function __construct(
		public string  $mainContent,
		public ?string $inlineStyle = null,
		public ?string $inlineScript = null
	) {}

}
