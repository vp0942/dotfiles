<?php

namespace Walnut\Module\Qtropy\Presentation\WebComponent;

use Walnut\Module\Qtropy\Presentation\View\HtmlComponentsView;
use Walnut\Lib\HttpMapper\ViewRenderer;

final readonly class WebComponentGenerator {

	/** @param WebComponent[] $webComponents */
	public function __construct(
		private WebComponentRenderer $webComponentRenderer,
		private ViewRenderer         $viewRenderer,
		private array                $webComponents = [],
	) {}

	public function render(): string {
		return $this->viewRenderer->render(
			new HtmlComponentsView(
				array_map(
					fn(string $componentName): WebComponent =>
						$this->webComponentRenderer->render($componentName),
					$this->webComponents
				)
			)
		);
	}
}