<?php

namespace Walnut\Module\Qtropy\Presentation\WebComponent;

final readonly class WebComponent {

	public function __construct(
		public string  $componentName,
		public string  $mainContent,
		public ?string $inlineStyle = null,
		public ?string $inlineScript = null,
	) {}

}
