<?php

namespace Walnut\Module\Qtropy\Presentation\WebComponent;

use Walnut\Lib\TemplateRenderer\TemplateRenderer;

final readonly class WebComponentRenderer {

	public function __construct(
		private TemplateRenderer $templateRenderer,
	) {}

	private function safeRender(string $templateName, string $componentName): ?string {
		return $this->templateRenderer->canRenderTemplate($templateName) ?
			$this->templateRenderer->render($templateName, $componentName) : null;
	}

	public function render(string $componentName): WebComponent {
		$templateName = "component/$componentName";
		return new WebComponent(
			$componentName,
			$this->templateRenderer->render($templateName, $componentName),
			$this->safeRender($templateName . '-style', $componentName),
			$this->safeRender($templateName . '-script', $componentName),
		);
	}

}
