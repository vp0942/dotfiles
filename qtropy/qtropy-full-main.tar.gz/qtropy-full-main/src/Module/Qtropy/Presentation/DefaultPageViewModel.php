<?php

namespace Walnut\Module\Qtropy\Presentation;

use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Member\Application\Query\AccountSettings\AccountSettingsData;
use Walnut\Module\Qtropy\Presentation\Menu\Menu;

final readonly class DefaultPageViewModel implements PageViewModel {
	public function __construct(
		public string              $basePath,
		public string              $pageTitle,
		public string              $tokenName,
		public string              $loginUrl,
		public PageContent         $content,
		public Menu                $menu,
		public AccountSettingsData $member,
		public int                 $countNotifications,
		public string              $webComponents,
		public string              $contentClass,
	) {}
}