<?php

namespace Walnut\Module\Qtropy\Presentation\Menu;

final readonly class MenuItem {
	public function __construct(
		public string $itemId,
		public string $link,
		public string $title
	) {}
}