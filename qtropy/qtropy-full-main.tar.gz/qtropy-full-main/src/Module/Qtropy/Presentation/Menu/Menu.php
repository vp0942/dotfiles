<?php

namespace Walnut\Module\Qtropy\Presentation\Menu;

final readonly class Menu {
	/**
	 * @param MenuItem[] $items
	 * @param string $selectedItemId
	 */
	public function __construct(
		public array  $items,
		public string $selectedItemId
	) {}
}