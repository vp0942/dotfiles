<?php

namespace Walnut\Module\Qtropy\Presentation;

use Walnut\Module\Qtropy\Presentation\Menu\Menu;
use Walnut\Module\Qtropy\Presentation\WebComponent\WebComponentGenerator;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Page\PageViewModelFactory;
use Walnut\Module\Member\Application\Context\_Member;

final readonly class DefaultPageViewModelFactory implements PageViewModelFactory {
	public function __construct(
		private WebComponentGenerator $webComponentGenerator,
		private PageContentRenderer   $pageContentRenderer,
		private string                $basePath,
		private string                $loginUrl,
		private string                $tokenName,

		private _Member               $member,
		private array                 $menuItems,
	) {}

	public function page(
		string $pageTitle,
		object $content,
		string $selectedItemId
	): PageViewModel {
		return new DefaultPageViewModel(
			$this->basePath,
			$pageTitle,
			$this->tokenName,
			$this->loginUrl,
			$content instanceof PageContent ? $content :
				$this->pageContentRenderer->render($content),
			new Menu(
				$this->menuItems,
				$selectedItemId
			),
			$this->member->profile()->accountSettings(),
			$this->member->notifications()->count(),
			$this->webComponentGenerator->render(),
			$content::class
		);
	}
}