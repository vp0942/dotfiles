<?php

namespace Walnut\Module\Qtropy\Presentation\View\ContactUs;

final readonly class ContactUsView {
	public function __construct(
		public string $subject
	) {}
}