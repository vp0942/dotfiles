<?php

namespace Walnut\Module\Qtropy\Presentation\View;

use Walnut\Module\Qtropy\Presentation\WebComponent\WebComponent;

final readonly class HtmlComponentsView {
	/** @param WebComponent[] $webComponents */
	public function __construct(
		public array $webComponents
	) {}
}