<?php

namespace Walnut\Module\Qtropy\Presentation;

use Walnut\Lib\Http\Helper\ViewMapper;
use Walnut\Lib\TemplateRenderer\TemplateRenderer;

final readonly class PageContentRenderer {

	public function __construct(
		private TemplateRenderer $templateRenderer,
		private ViewMapper       $viewMapper,
	) {}

	private function safeRender(string $templateName, object $view): ?string {
		return $this->templateRenderer->canRenderTemplate($templateName) ?
			$this->templateRenderer->render($templateName, $view) : null;
	}

	public function render(object $view): PageContent {
		$templateName = $this->viewMapper->findTemplate($view::class);
		return new PageContent(
			$this->templateRenderer->render($templateName, $view),
			$this->safeRender($templateName . '-style', $view),
			$this->safeRender($templateName . '-script', $view),
		);
	}

}
