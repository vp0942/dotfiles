<?php

namespace Walnut\Module\Qtropy\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromAttribute;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Page\PageViewModelFactory;
use Walnut\Module\Qtropy\Presentation\View\ContactUs\ContactUsView;

final readonly class HttpPageContactUsController {

	public function __construct(
		private PageViewModelFactory $pageViewModelFactory,
	) {}

	#[HttpGet('/report-user/{username}'), ViewResponse]
	public function contactUsFormReport(
		#[FromAttribute('accountId')] string $accountId,
		#[FromRoute('username')] string $username
	): PageViewModel {
		$view = new ContactUsView($username !== '' ?
			"Report $username" : ''
		);
		return $this->pageViewModelFactory->page(
			'Contact Us',
			$view,
			'contact-us',
		);
	}

	#[HttpGet, ViewResponse]
	public function contactUsForm(
		#[FromAttribute('accountId')] string $accountId
	): PageViewModel {
		return $this->contactUsFormReport($accountId, '');
	}

}