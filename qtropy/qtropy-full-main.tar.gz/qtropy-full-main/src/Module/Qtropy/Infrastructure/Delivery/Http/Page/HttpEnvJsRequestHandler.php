<?php

namespace Walnut\Module\Qtropy\Infrastructure\Delivery\Http\Page;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Walnut\Lib\HttpMapper\ResponseBuilder;

final readonly class HttpEnvJsRequestHandler implements RequestHandlerInterface {
	public function __construct(
		private string          $apiEndpoint,
		private string          $webEndpoint,
		private ResponseBuilder $responseBuilder,
	) {}

	public function handle(ServerRequestInterface $request): ResponseInterface {
		return $this->responseBuilder
			->textResponse($this->getJsContent())
			->withHeader('Content-Type', 'application/javascript');
	}

	private function getJsContent(): string {
		return <<<JS
		export let apiEndpoint = '$this->apiEndpoint', webEndpoint = '$this->webEndpoint';
		JS;
	}
}