<?php

namespace Walnut\Module\Qtropy\Infrastructure\Delivery\Http\Api;

use Walnut\Lib\DataType\Exception\InvalidData;
use Walnut\Lib\HttpMapper\Attribute\ErrorHandler;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromJsonBody;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpPost;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\NoContentResponse;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\JsonResponseBody;
use Walnut\Lib\HttpMapper\InvalidJsonBody;
use Walnut\Module\Member\Application\Context\_Member;
use Walnut\Module\Qtropy\Application\Model\ContactMessageData;

final readonly class HttpApiContactController {
	public function __construct(
		private _Member $member
	) {}

	#[HttpPost, NoContentResponse]
	public function sendMessage(#[FromJsonBody] ContactMessageData $contactMessageData): void {
		$this->member->contactQtropy($contactMessageData);
	}

	#[ErrorHandler(InvalidJsonBody::class), JsonResponseBody(400)]
	public function invalidJsonBody(): array {
		return ['error' => 'Invalid input data'];
	}

	#[ErrorHandler(InvalidData::class), JsonResponseBody(400)]
	public function invalidValue(InvalidData $ex): array {
		return ['error' => $ex->getMessage()];
	}
}