<?php

namespace Walnut\Module\Qtropy\Infrastructure\Delivery\Http\Page;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Walnut\Lib\HttpMapper\ResponseBuilder;

final readonly class HttpRobotsTxtRequestHandler implements RequestHandlerInterface {
	public function __construct(
		private ResponseBuilder $responseBuilder,
	) {}

	public function handle(ServerRequestInterface $request): ResponseInterface {
		return $this->responseBuilder->textResponse("User-agent: *\r\nAllow: /");
	}
}