<?php

namespace Walnut\Module\Social\Presentation\View\Social;

use Walnut\Module\Member\Application\Model\MemberData;
use Walnut\Module\Social\Application\Query\Followers\FollowerData;

final readonly class SocialView {
	/**
	 * @param string $pageTitle
	 * @param SocialViewTab $tab
	 * @param MemberData[] $followed
	 * @param FollowerData[] $followers
	 */
	public function __construct(
		public string        $pageTitle,
		public SocialViewTab $tab,
		public array         $followed,
		public array         $followers,
	) {}
}