<?php

namespace Walnut\Module\Social\Presentation\View\Search;

use Walnut\Module\Social\Application\Query\Contact\MemberContact;

final readonly class SearchView {
	/** @param MemberContact[] $contacts */
	public function __construct(
		public array  $contacts,
	) {}
}