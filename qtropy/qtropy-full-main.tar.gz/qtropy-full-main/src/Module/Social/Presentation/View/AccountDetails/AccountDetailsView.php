<?php

namespace Walnut\Module\Social\Presentation\View\AccountDetails;

use Walnut\Module\Social\Application\Query\Profile\MemberProfileData;

final readonly class AccountDetailsView {
	public function __construct(
		public string            $pageTitle,
		public MemberProfileData $memberProfileData,
	) {}
}