<?php

namespace Walnut\Module\Social\Presentation\View\Search;

use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Application\Context\_MemberFeed;
use Walnut\Module\Feed\Application\Query\Search\ContentSearch;
use Walnut\Module\Social\Application\Context\_MemberSocial;

final readonly class SearchViewBuilder {

	public function __construct(
		private _MemberFeed $feed,
		private _MemberSocial $social
	) {}

	public function resultView(ContentSearch $contentSearch): SearchResultView {
		return new SearchResultView(
			$contentSearch,
			$this->feed->search($contentSearch)
		);
	}

	public function searchView(): SearchView {
		return new SearchView(
			$this->social->contacts(),
		);
	}

	public function byKeyResultView(ContentKey $contentKey): ByKeyResultView {
		return new ByKeyResultView(
			$contentKey,
			$this->feed->byKey($contentKey)
		);
	}

}