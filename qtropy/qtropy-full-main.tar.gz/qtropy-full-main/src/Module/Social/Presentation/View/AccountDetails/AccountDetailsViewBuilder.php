<?php

namespace Walnut\Module\Social\Presentation\View\AccountDetails;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Social\Application\Context\_MemberSocial;

final readonly class AccountDetailsViewBuilder {

	public function __construct(
		private string       $pageTitle,
		public _MemberSocial $memberSocial,
	) {}

	public function view(MemberId $memberId): AccountDetailsView {
		return new AccountDetailsView(
			$this->pageTitle,
			$this->memberSocial
				->withMember($memberId)->profile()
		);
	}
}