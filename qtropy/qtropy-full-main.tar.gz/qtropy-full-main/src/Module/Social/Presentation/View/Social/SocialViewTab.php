<?php

namespace Walnut\Module\Social\Presentation\View\Social;

enum SocialViewTab: string {
	case followers = 'followers';
	case following = 'following';
}