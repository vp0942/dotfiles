<?php

namespace Walnut\Module\Social\Presentation\View\Social;

use Walnut\Module\Social\Application\Context\_MemberSocial;

final readonly class SocialViewBuilder {
	public function __construct(
		private _MemberSocial $memberSocial,
		private string        $pageTitle
	) {}

	public function view(SocialViewTab $tab): SocialView {
		return new SocialView(
			$this->pageTitle,
			$tab,
			$this->memberSocial->followed(),
			$this->memberSocial->followers(),
		);
	}
}