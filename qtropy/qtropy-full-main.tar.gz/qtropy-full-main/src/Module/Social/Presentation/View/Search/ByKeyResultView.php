<?php

namespace Walnut\Module\Social\Presentation\View\Search;

use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Model\TreatiseData;

final readonly class ByKeyResultView {
	public function __construct(
		public ContentKey                                         $contentKey,
		public QuestionData|AnswerData|TreatiseData|NoteData|null $content
	) {}
}