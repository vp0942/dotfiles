<?php

namespace Walnut\Module\Social\Presentation\View\Search;

use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Model\TreatiseData;
use Walnut\Module\Feed\Application\Query\Search\ContentSearch;

final readonly class SearchResultView {

	/** @param list<QuestionData|AnswerData|TreatiseData|NoteData> $entries */
	public function __construct(
		public ContentSearch $contentSearch,
		public array         $entries
	) {}
}