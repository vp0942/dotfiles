<?php

namespace Walnut\Module\Social\Application\Query\Profile;

use Walnut\Module\Member\Application\Model\MemberData;
use Walnut\Module\Social\Application\Query\BlockStatus;
use Walnut\Module\Social\Application\Query\FollowStatus;

final readonly class MemberProfileData {
	public function __construct(
		public MemberData   $memberData,
		public FollowStatus $followerStatus,
		public FollowStatus $followedStatus,
		public BlockStatus  $blockStatus,
	) {}
}