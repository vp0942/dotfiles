<?php

namespace Walnut\Module\Social\Application\Query\Contact;

final readonly class MemberContact {
	public function __construct(
		public string $memberId,
		public string $username
	) {}
}