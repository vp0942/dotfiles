<?php

namespace Walnut\Module\Social\Application\Query\Contact;

use Walnut\Module\Member\Domain\Model\Member;

interface MemberContactsQuery {
	/** @return MemberContact[] */
	public function __invoke(Member $member): array;
}