<?php

namespace Walnut\Module\Social\Application\Query\Followed;

use Walnut\Module\Member\Application\Model\MemberData;
use Walnut\Module\Member\Domain\Model\Member;

interface FollowedQuery {
	/** @return MemberData[] */
	public function __invoke(Member $member): array;
}