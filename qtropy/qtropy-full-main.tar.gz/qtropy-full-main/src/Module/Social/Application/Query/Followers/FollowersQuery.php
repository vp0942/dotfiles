<?php

namespace Walnut\Module\Social\Application\Query\Followers;

use Walnut\Module\Member\Domain\Model\Member;

interface FollowersQuery {
	/** @return FollowerData[] */
	public function __invoke(Member $member): array;
}