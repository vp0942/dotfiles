<?php

namespace Walnut\Module\Social\Application\Query;

enum FollowStatus: int {
	case notFollowed = 0;
	case followed = 1;
	case pendingRequest = 2;
}
