<?php

namespace Walnut\Module\Social\Application\Query;

enum BlockStatus: int {
	case notBlocked = 0;
	case blocks = 1;
	case isBlocked = 2;
}
