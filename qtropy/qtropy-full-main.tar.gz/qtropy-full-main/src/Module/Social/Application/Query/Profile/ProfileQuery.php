<?php

namespace Walnut\Module\Social\Application\Query\Profile;

use Walnut\Module\Member\Domain\Model\Member;

interface ProfileQuery {
	public function __invoke(
		Member $member,
		Member $targetMember,
	): MemberProfileData;
}