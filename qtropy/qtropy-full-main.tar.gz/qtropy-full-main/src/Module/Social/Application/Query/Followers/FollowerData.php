<?php

namespace Walnut\Module\Social\Application\Query\Followers;

use Walnut\Module\Member\Application\Model\MemberData;
use Walnut\Module\Social\Application\Query\FollowStatus;

final readonly class FollowerData {
	public function __construct(
		public MemberData   $memberData,
		public FollowStatus $followerStatus
	) {}
}