<?php

namespace Walnut\Module\Social\Application\Context;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Model\SocialActivity;
use Walnut\Module\Social\Domain\Repository\SocialActivityRepository;

final readonly class SocialActivityById {
	public function __construct(
		private SocialActivityRepository $socialActivityRepository
	) {}

	public function __invoke(
		Member $member,
		MemberId $otherMemberId
	): SocialActivity {
		return $this->socialActivityRepository
			->betweenMembers(
				$member->memberId,
				$otherMemberId
			);
	}
}