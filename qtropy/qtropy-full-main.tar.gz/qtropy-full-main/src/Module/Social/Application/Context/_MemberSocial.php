<?php

namespace Walnut\Module\Social\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterBuilder;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\Reference;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Member\Application\Context\MemberById;
use Walnut\Module\Member\Application\Model\MemberData;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Application\Query\Contact\MemberContact;
use Walnut\Module\Social\Application\Query\Contact\MemberContactsQuery;
use Walnut\Module\Social\Application\Query\Followed\FollowedQuery;
use Walnut\Module\Social\Application\Query\Followers\FollowerData;
use Walnut\Module\Social\Application\Query\Followers\FollowersQuery;

#[DataContext(Member::class)]
interface _MemberSocial {
	#[Reference(_MemberSocialMember::class, new ParameterList(
		new ContextParameter,
		new ParameterBuilder(
			SocialActivityById::class,
			new ParameterList(
				new ContextParameter,
				new FunctionParameter('otherMemberId')
			)
		),
		new ParameterBuilder(
			MemberById::class,
			new ParameterList(
				new FunctionParameter('otherMemberId')
			)
		)
	))]
	public function withMember(MemberId $otherMemberId): _MemberSocialMember;

	/** @return MemberContact[] */
	#[DataQuery(MemberContactsQuery::class, new ParameterList(
		new ContextParameter
	))]
	public function contacts(): array;

	/** @return FollowerData[] */
	#[DataQuery(FollowersQuery::class, new ParameterList(
		new ContextParameter
	))]
	public function followers(): array;

	/** @return MemberData[] */
	#[DataQuery(FollowedQuery::class, new ParameterList(
		new ContextParameter
	))]
	public function followed(): array;
}