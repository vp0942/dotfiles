<?php

namespace Walnut\Module\Social\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Application\Query\Profile\MemberProfileData;
use Walnut\Module\Social\Application\Query\Profile\ProfileQuery;
use Walnut\Module\Social\Domain\Command\AcceptFollowRequest;
use Walnut\Module\Social\Domain\Command\BlockMember;
use Walnut\Module\Social\Domain\Command\CancelFollowRequest;
use Walnut\Module\Social\Domain\Command\RejectFollowRequest;
use Walnut\Module\Social\Domain\Command\SendFollowRequest;
use Walnut\Module\Social\Domain\Command\StopFollower;
use Walnut\Module\Social\Domain\Command\UnblockMember;
use Walnut\Module\Social\Domain\Command\UnfollowMember;
use Walnut\Module\Social\Domain\Model\SocialActivity;

#[DataContext([
	'member' => Member::class,
	'socialActivity' => SocialActivity::class,
	'otherMember' => Member::class
])]
interface _MemberSocialMember {
	#[DomainCommand(BlockMember::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('socialActivity'),
		new ContextParameter('otherMember'),
		new FunctionParameter('blockReason'),
	))]
	public function block(string $blockReason): void;

	#[DomainCommand(UnblockMember::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('socialActivity'),
		new ContextParameter('otherMember'),
	))]
	public function unblock(): void;

	#[DomainCommand(SendFollowRequest::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('socialActivity'),
		new ContextParameter('otherMember'),
	))]
	public function sendFollowRequest(): void;

	#[DomainCommand(CancelFollowRequest::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('socialActivity'),
		new ContextParameter('otherMember'),
	))]
	public function cancelFollowRequest(): void;

	#[DomainCommand(RejectFollowRequest::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('socialActivity'),
		new ContextParameter('otherMember'),
	))]
	public function rejectFollowRequest(): void;

	#[DomainCommand(AcceptFollowRequest::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('socialActivity'),
		new ContextParameter('otherMember'),
	))]
	public function acceptFollowRequest(): void;

	#[DomainCommand(StopFollower::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('socialActivity'),
		new ContextParameter('otherMember'),
	))]
	public function stopFollower(): void;

	#[DomainCommand(UnfollowMember::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('socialActivity'),
		new ContextParameter('otherMember'),
	))]
	public function unfollow(): void;

	#[DataQuery(ProfileQuery::class, new ParameterList(
		new ContextParameter('member'),
		new ContextParameter('otherMember'),
	))]
	public function profile(): MemberProfileData;
}