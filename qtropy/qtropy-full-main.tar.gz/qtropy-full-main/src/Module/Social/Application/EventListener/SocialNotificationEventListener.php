<?php

namespace Walnut\Module\Social\Application\EventListener;

use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\EventBus\EventBus;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Notification\Domain\Command\AddNotification;
use Walnut\Module\Notification\Domain\Model\Details\NotificationMemberData;
use Walnut\Module\Notification\Domain\Model\Details\ReceivedFollowRequest;
use Walnut\Module\Notification\Domain\Model\Details\SentFollowRequest;
use Walnut\Module\Notification\Domain\Model\Notification;
use Walnut\Module\Notification\Domain\Model\NotificationDetails;
use Walnut\Module\Notification\Domain\Model\NotificationId;
use Walnut\Module\Notification\Domain\Model\NotificationType;
use Walnut\Module\Notification\Domain\Repository\NotificationIdProvider;
use Walnut\Module\Social\Domain\Event\FollowRequestAccepted;
use Walnut\Module\Social\Domain\Event\FollowRequestCancelled;
use Walnut\Module\Social\Domain\Event\FollowRequestRejected;
use Walnut\Module\Social\Domain\Event\FollowRequestSent;

#[AutoEventListener]
final readonly class SocialNotificationEventListener {

	/** @param WriteModelRepository<Notification, NotificationId> $writeModelRepository */
	public function __construct(
		private EventBus               $eventBus,
		private AddNotification        $addNotification,
		#[WriteModel(Notification::class)]
		private WriteModelRepository   $writeModelRepository,
		private NotificationIdProvider $notificationIdProvider,
	) {}

	public function onFollowerRequestSent(FollowRequestSent $event): void {
		$message = "%s wants to become a follower";
		$this->eventBus->dispatchEvent(
			($this->addNotification)(
				$event->otherMember->memberId,
				sprintf($message, $event->member->username),
				new NotificationDetails(
					NotificationType::ReceivedFollowRequest,
					new ReceivedFollowRequest(
						new NotificationMemberData(
							$event->member->memberId,
							$event->member->username,
							$event->member->profileDetails->profilePicture,
						)
					),
				),
				$event->member->memberId->value
			)
		);
		$message = "You sent a follow request to %s";
		$this->eventBus->dispatchEvent(
			($this->addNotification)(
				$event->member->memberId,
				sprintf($message, $event->otherMember->username),
				new NotificationDetails(
					NotificationType::SentFollowRequest,
					new SentFollowRequest(
						new NotificationMemberData(
							$event->otherMember->memberId,
							$event->otherMember->username,
						)
					),
				),
				$event->otherMember->memberId->value
			)
		);
	}

	public function onFollowerRequestCancelled(FollowRequestCancelled $event): void {
		$notificationId = $this->notificationIdProvider->findFor(
			$event->activity->toMemberStatus->memberId,
			NotificationType::SentFollowRequest,
			$event->activity->toMemberStatus->otherMemberId->value
		);
		if ($notificationId) {
			$this->writeModelRepository->removeById($notificationId);
		}

		$notificationId = $this->notificationIdProvider->findFor(
			$event->activity->toMemberStatus->otherMemberId,
			NotificationType::ReceivedFollowRequest,
			$event->activity->toMemberStatus->memberId->value
		);
		if ($notificationId) {
			$this->writeModelRepository->removeById($notificationId);
		}
	}

	public function onFollowerRequestRejectedOrAccepted(FollowRequestRejected|FollowRequestAccepted $event): void {
		$notificationId = $this->notificationIdProvider->findFor(
			$event->activity->fromMemberStatus->otherMemberId,
			NotificationType::SentFollowRequest,
			$event->activity->fromMemberStatus->memberId->value
		);
		if ($notificationId) {
			$this->writeModelRepository->removeById($notificationId);
		}

		$notificationId = $this->notificationIdProvider->findFor(
			$event->activity->fromMemberStatus->memberId,
			NotificationType::ReceivedFollowRequest,
			$event->activity->fromMemberStatus->otherMemberId->value
		);
		if ($notificationId) {
			$this->writeModelRepository->removeById($notificationId);
		}
	}

}