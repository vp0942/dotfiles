<?php

namespace Walnut\Module\Social\Application\EventListener;

use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Social\Domain\Event\FollowerStopped;
use Walnut\Module\Social\Domain\Event\FollowRequestAccepted;
use Walnut\Module\Social\Domain\Event\FollowRequestCancelled;
use Walnut\Module\Social\Domain\Event\FollowRequestRejected;
use Walnut\Module\Social\Domain\Event\FollowRequestSent;
use Walnut\Module\Social\Domain\Event\MemberBlocked;
use Walnut\Module\Social\Domain\Event\MemberUnblocked;
use Walnut\Module\Social\Domain\Event\MemberUnfollowed;
use Walnut\Module\Social\Domain\Model\FromStatus\FromStatus;
use Walnut\Module\Social\Domain\Model\ToStatus\ToStatus;

#[AutoEventListener]
final readonly class SocialPersistenceEventListener {
	public function __construct(
		#[WriteModel(FromStatus::class)]
		private WriteModelRepository $fromStatusWriteModelRepository,
		#[WriteModel(ToStatus::class)]
		private WriteModelRepository $toStatusWriteModelRepository
	) {}

	public function toStatusChanged(MemberBlocked|MemberUnblocked|FollowRequestSent|FollowRequestCancelled|MemberUnfollowed $event): void {
		$this->toStatusWriteModelRepository->store($event->activity->toMemberStatus);
	}

	public function fromStatusChanged(FollowRequestRejected|FollowRequestAccepted|FollowerStopped $event): void {
		$this->fromStatusWriteModelRepository->store($event->activity->fromMemberStatus);
	}
}