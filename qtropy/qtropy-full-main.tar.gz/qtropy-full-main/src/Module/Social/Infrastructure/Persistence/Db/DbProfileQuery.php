<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Member\Application\Model\MemberData;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Application\Query\BlockStatus;
use Walnut\Module\Social\Application\Query\FollowStatus;
use Walnut\Module\Social\Application\Query\Profile\MemberProfileData;
use Walnut\Module\Social\Application\Query\Profile\ProfileQuery;

final readonly class DbProfileQuery implements ProfileQuery {
	public const query = <<<SQL
		SELECT 
		    BIN_TO_UUID(m.member_id) AS memberId, m.username, 
		    m.profile_picture as profilePicture,
		    m.profile_description as profileDescription,
			IF(q.target_followed_since IS NULL, IF(
			    q.follow_request_on IS NULL, 0, 2
			), 1) AS followerStatus,
			IF(a.target_followed_since IS NULL, IF(
			    a.follow_request_on IS NULL, 0, 2
			), 1) AS followedStatus,
		    IF(q.target_blocked_since IS NULL, IF(
		        a.target_blocked_since IS NULL, 0, 2
		    ), 1) AS blockStatus
		FROM members m
		JOIN members t ON m.member_id = :targetMemberId and t.member_id = :memberId
		LEFT JOIN member_social_activities a ON a.member_id = m.member_id AND a.target_member_id = t.member_id
		LEFT JOIN member_social_activities q ON q.target_member_id = m.member_id AND q.member_id = t.member_id
SQL;

	public function __construct(
		private readonly QueryExecutor $queryExecutor
	) {}

	public function __invoke(
		Member $member,
		Member $targetMember,
	): MemberProfileData {
		return $this->profileData(
			$this->queryExecutor->execute(self::query, [
				'memberId' => $member->memberId->value->binaryValue,
				'targetMemberId' => $targetMember->memberId->value->binaryValue,
			])->first()
		);
	}

	private function profileData(array $row): MemberProfileData {
		return new MemberProfileData(
			new MemberData(
				$row['memberId'],
				$row['username'],
				$row['profilePicture'],
				$row['profileDescription'],
			),
			FollowStatus::tryFrom($row['followerStatus']),
			FollowStatus::tryFrom($row['followedStatus']),
			BlockStatus::tryFrom($row['blockStatus']),
		);
	}

}