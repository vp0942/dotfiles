<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Member\Application\Model\MemberData;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Application\Query\Followers\FollowerData;
use Walnut\Module\Social\Application\Query\Followers\FollowersQuery;
use Walnut\Module\Social\Application\Query\FollowStatus;

final readonly class DbFollowersQuery implements FollowersQuery {
	public const query = <<<SQL
		SELECT BIN_TO_UUID(m.member_id) AS memberId, m.username, 
	       m.profile_picture as profilePicture,
	       m.profile_description as profileDescription,
			IF(q.target_followed_since IS NULL, IF(
			    q.follow_request_on IS NULL, 0, 2
			), 1) AS followerStatus
		FROM member_social_activities a
		JOIN members m ON a.member_id = m.member_id
		LEFT JOIN member_social_activities q
			ON q.member_id = a.target_member_id AND q.target_member_id = a.member_id
		WHERE a.target_member_id = :memberId
		AND a.target_followed_since IS NOT NULL
		ORDER BY a.target_followed_since DESC
SQL;

	public function __construct(
		private readonly QueryExecutor $queryExecutor
	) {}

	/** @return FollowerData[] */
	public function __invoke(Member $member): array {
		return array_map($this->followerData(...),
			$this->queryExecutor->execute(self::query, [
				'memberId' => $member->memberId->value->binaryValue
			])->all()
		);
	}

	private function followerData(array $row): FollowerData {
		return new FollowerData(
			new MemberData(
				$row['memberId'],
				$row['username'],
				$row['profilePicture'],
				$row['profileDescription'],
			),
			FollowStatus::tryFrom($row['followerStatus'])
		);
	}

}