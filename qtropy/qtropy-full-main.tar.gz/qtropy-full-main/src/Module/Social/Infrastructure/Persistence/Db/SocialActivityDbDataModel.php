<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\DbDataModel\Attribute\Fields;
use Walnut\Lib\DbDataModel\Attribute\KeyField;
use Walnut\Lib\DbDataModel\Attribute\ModelRoot;
use Walnut\Lib\DbDataModel\Attribute\Table;

#[ModelRoot('socialActivities')]
final readonly class SocialActivityDbDataModel {
	public function __construct(
		#[Table('member_social_activities'), KeyField('activity_id'), Fields(
			'member_id', 'target_member_id', 'target_blocked_since',
			'target_block_reason', 'follow_request_on', 'target_followed_since',
		)]
		public array $socialActivities,
	) {}
}