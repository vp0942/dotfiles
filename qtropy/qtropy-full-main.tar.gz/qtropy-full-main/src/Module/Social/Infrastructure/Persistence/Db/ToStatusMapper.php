<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\WriteModel\Mapper\EntityMapper;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Social\Domain\Model\ActivityId;
use Walnut\Module\Social\Domain\Model\ToStatus\Blocks;
use Walnut\Module\Social\Domain\Model\ToStatus\Follows;
use Walnut\Module\Social\Domain\Model\ToStatus\NoRelation;
use Walnut\Module\Social\Domain\Model\ToStatus\RequestsFollow;
use Walnut\Module\Social\Domain\Model\ToStatus\ToStatus;

/**
 * @implements EntityMapper<ToStatus, ActivityId, array, string>
 */
final readonly class ToStatusMapper implements EntityMapper {
	/**
	 * @param ToStatus $mapped
	 * @return array
	 */
	public function toSourceEntity(object|array $mapped): array {
		return [
			'activity_id' => $mapped->activityId->value->binaryValue,
			'member_id' => $mapped->memberId->value->binaryValue,
			'target_member_id' => $mapped->otherMemberId->value->binaryValue,
			'target_blocked_since' => match($mapped->status::class) {
				Blocks::class => $mapped->status->since->format('Y-m-d H:i:s'),
				default => null
			},
			'target_block_reason' => match($mapped->status::class) {
				Blocks::class => $mapped->status->reason,
				default => null
			},
			'follow_request_on' => match($mapped->status::class) {
				RequestsFollow::class => $mapped->status->requestedOn->format('Y-m-d H:i:s'),
				default => null
			},
			'target_followed_since' => match($mapped->status::class) {
				Follows::class => $mapped->status->since->format('Y-m-d H:i:s'),
				default => null
			},
		];
	}

	/**
	 * @param ActivityId $mapped
	 * @return string
	 */
	public function toSourceId(object|int|string $mapped): string {
		return $mapped->value->binaryValue;
	}

	/**
	 * @param array $source
	 * @return ToStatus
	 */
	public function fromSourceEntity(object|array $source): ToStatus {
		return new ToStatus(
			new ActivityId(Uuid::fromBinary((string)($source['activity_id'] ?? ''))),
			new MemberId(Uuid::fromBinary((string)($source['member_id'] ?? ''))),
			new MemberId(Uuid::fromBinary((string)($source['target_member_id'] ?? ''))),
			match(true) {
				($tfs = $source['target_followed_since'] ?? null) !== null => new Follows(new DateAndTime($tfs)),
				($fro = $source['follow_request_on'] ?? null) !== null => new RequestsFollow(new DateAndTime($fro)),
				($tbs = $source['target_blocked_since'] ?? null) !== null => new Blocks(
					new DateAndTime($tbs),
					$source['target_block_reason'] ?? ''
				),
				default => new NoRelation
			}
		);
	}

	/**
	 * @param string $source
	 * @return ActivityId
	 */
	public function fromSourceId(object|int|string $source): ActivityId {
		return new ActivityId(Uuid::fromBinary($source));
	}
}
