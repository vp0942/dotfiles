<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\WriteModel\Mapper\EntityMapper;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Social\Domain\Model\ActivityId;
use Walnut\Module\Social\Domain\Model\FromStatus\Blocked;
use Walnut\Module\Social\Domain\Model\FromStatus\Followed;
use Walnut\Module\Social\Domain\Model\FromStatus\FromStatus;
use Walnut\Module\Social\Domain\Model\FromStatus\NotRelated;
use Walnut\Module\Social\Domain\Model\FromStatus\RequestedFollow;

/**
 * @implements EntityMapper<FromStatus, ActivityId, array, string>
 */
final readonly class FromStatusMapper implements EntityMapper {
	/**
	 * @param FromStatus $mapped
	 * @return array
	 */
	public function toSourceEntity(object|array $mapped): array {
		return [
			'activity_id' => $mapped->activityId->value->binaryValue,
			'member_id' => $mapped->otherMemberId->value->binaryValue,
			'target_member_id' => $mapped->memberId->value->binaryValue,
			'target_blocked_since' => match($mapped->status::class) {
				Blocked::class => $mapped->status->since->format('Y-m-d H:i:s'),
				default => null
			},
			'target_block_reason' => match($mapped->status::class) {
				Blocked::class => $mapped->status->reason,
				default => null
			},
			'follow_request_on' => match($mapped->status::class) {
				RequestedFollow::class => $mapped->status->requestedOn->format('Y-m-d H:i:s'),
				default => null
			},
			'target_followed_since' => match($mapped->status::class) {
				Followed::class => $mapped->status->since->format('Y-m-d H:i:s'),
				default => null
			},
		];
	}

	/**
	 * @param ActivityId $mapped
	 * @return string
	 */
	public function toSourceId(object|int|string $mapped): string {
		return $mapped->value->binaryValue;
	}

	/**
	 * @param array $source
	 * @return FromStatus
	 */
	public function fromSourceEntity(object|array $source): FromStatus {
		return new FromStatus(
			new ActivityId(Uuid::fromBinary((string)($source['activity_id'] ?? ''))),
			new MemberId(Uuid::fromBinary((string)($source['target_member_id'] ?? ''))),
			new MemberId(Uuid::fromBinary((string)($source['member_id'] ?? ''))),
			match(true) {
				($tfs = $source['target_followed_since'] ?? null) !== null => new Followed(new DateAndTime($tfs)),
				($fro = $source['follow_request_on'] ?? null) !== null => new RequestedFollow(new DateAndTime($fro)),
				($tbs = $source['target_blocked_since'] ?? null) !== null => new Blocked(
					new DateAndTime($tbs),
					$source['target_block_reason'] ?? ''
				),
				default => new NotRelated
			}
		);
	}

	/**
	 * @param string $source
	 * @return ActivityId
	 */
	public function fromSourceId(object|int|string $source): ActivityId {
		return new ActivityId(Uuid::fromBinary($source));
	}
}
