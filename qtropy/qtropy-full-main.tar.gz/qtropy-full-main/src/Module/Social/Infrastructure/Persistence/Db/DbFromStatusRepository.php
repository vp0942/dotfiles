<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGenerator;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Social\Domain\Model\ActivityId;
use Walnut\Module\Social\Domain\Model\FromStatus\FromStatus;
use Walnut\Module\Social\Domain\Model\FromStatus\NotRelated;
use Walnut\Module\Social\Domain\Repository\FromStatusRepository;

final readonly class DbFromStatusRepository implements FromStatusRepository {
	private const query = "
		SELECT BIN_TO_UUID(activity_id) 
		FROM member_social_activities 
		WHERE member_id = UUID_TO_BIN(?) AND target_member_id = UUID_TO_BIN(?) 
	";

	public function __construct(
		private readonly QueryExecutor $queryExecutor,
		#[WriteModel(FromStatus::class)]
		private readonly WriteModelIdentityGenerator $identityGenerator,
		#[WriteModel(FromStatus::class)]
		private readonly WriteModelRepository $writeModelRepository,
	) {}

	public function betweenMembers(
		MemberId $memberId,
		MemberId $otherMemberId,
	): FromStatus {
		$fromActivityId = $this->queryExecutor->execute(self::query,
			[$otherMemberId, $memberId])->singleValue();
		return $fromActivityId ?
			$this->writeModelRepository->byId(
				new ActivityId(Uuid::fromString($fromActivityId))
			) : new FromStatus(
				$this->identityGenerator->generateIdentity(),
				$memberId,
				$otherMemberId,
				new NotRelated
			)
		;
	}
}
