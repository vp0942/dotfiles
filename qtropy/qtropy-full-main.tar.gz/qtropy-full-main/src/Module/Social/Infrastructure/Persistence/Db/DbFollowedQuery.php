<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Member\Application\Model\MemberData;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Application\Query\Followed\FollowedQuery;

final readonly class DbFollowedQuery implements FollowedQuery {
	public const query = <<<SQL
		SELECT BIN_TO_UUID(m.member_id) AS memberId, m.username, 
			m.profile_picture as profilePicture,
			m.profile_description as profileDescription
		FROM member_social_activities a
		JOIN members m ON a.target_member_id = m.member_id
		WHERE a.member_id = :memberId
		AND a.target_followed_since IS NOT NULL
		ORDER BY a.target_followed_since DESC
SQL;

	public function __construct(
		private readonly QueryExecutor $queryExecutor
	) {}

	/** @return MemberData[] */
	public function __invoke(Member $member): array {
		return array_map($this->memberData(...),
			$this->queryExecutor->execute(self::query, [
				'memberId' => $member->memberId->value->binaryValue
			])->all()
		);
	}

	private function memberData(array $row): MemberData {
		return new MemberData(... $row);
	}

}