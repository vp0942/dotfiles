<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGenerator;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Social\Domain\Model\ActivityId;
use Walnut\Module\Social\Domain\Model\ToStatus\NoRelation;
use Walnut\Module\Social\Domain\Model\ToStatus\ToStatus;
use Walnut\Module\Social\Domain\Repository\ToStatusRepository;

final readonly class DbToStatusRepository implements ToStatusRepository {
	private const query = "
		SELECT BIN_TO_UUID(activity_id) 
		FROM member_social_activities 
		WHERE member_id = UUID_TO_BIN(?) AND target_member_id = UUID_TO_BIN(?) 
	";

	public function __construct(
		private readonly QueryExecutor $queryExecutor,
		#[WriteModel(ToStatus::class)]
		private readonly WriteModelIdentityGenerator $identityGenerator,
		#[WriteModel(ToStatus::class)]
		private readonly WriteModelRepository $writeModelRepository,
	) {}

	public function betweenMembers(
		MemberId $memberId,
		MemberId $otherMemberId,
	): ToStatus {
		$toActivityId = $this->queryExecutor->execute(self::query,
			[$memberId, $otherMemberId])->singleValue();
		return $toActivityId ?
			$this->writeModelRepository->byId(
				new ActivityId(Uuid::fromString($toActivityId))
			) : new ToStatus(
				$this->identityGenerator->generateIdentity(),
				$memberId,
				$otherMemberId,
				new NoRelation
			)
		;
	}
}
