<?php

namespace Walnut\Module\Social\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Application\Query\Contact\MemberContact;
use Walnut\Module\Social\Application\Query\Contact\MemberContactsQuery;

final readonly class DbMemberContactsQuery implements MemberContactsQuery {
	public const query = <<<SQL
		SELECT DISTINCT memberId, username FROM (
		SELECT BIN_TO_UUID(m.member_id) AS memberId, m.username
		FROM member_social_activities a
		JOIN members m ON a.target_member_id = m.member_id
		WHERE a.member_id = :memberId
		AND a.target_followed_since IS NOT NULL
		UNION
		SELECT BIN_TO_UUID(m.member_id) AS memberId, m.username
		FROM member_social_activities a
		JOIN members m ON a.member_id = m.member_id
		WHERE a.target_member_id = :memberId
		AND a.target_followed_since IS NOT NULL
		) d ORDER BY username;
SQL;

	public function __construct(
		private readonly QueryExecutor $queryExecutor
	) {}

	/** @return MemberContact[] */
	public function __invoke(Member $member): array {
		return array_map($this->memberContact(...),
			$this->queryExecutor->execute(self::query, [
				'memberId' => $member->memberId->value->binaryValue
			])->all()
		);
	}

	private function memberContact(array $row): MemberContact {
		return new MemberContact(... $row);
	}

}