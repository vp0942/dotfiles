<?php

namespace Walnut\Module\Social\Infrastructure\Delivery\Http\Api\Request;

final readonly class MemberBlockRequest {
	public function __construct(
		public string $blockReason,
	) {}
}