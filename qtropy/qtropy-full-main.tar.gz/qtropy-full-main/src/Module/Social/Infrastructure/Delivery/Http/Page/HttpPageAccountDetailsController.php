<?php

namespace Walnut\Module\Social\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Page\PageViewModelFactory;
use Walnut\Module\Social\Presentation\View\AccountDetails\AccountDetailsView;
use Walnut\Module\Social\Presentation\View\AccountDetails\AccountDetailsViewBuilder;

final readonly class HttpPageAccountDetailsController {
	public function __construct(
		private PageViewModelFactory      $pageViewModelFactory,
		private AccountDetailsViewBuilder $accountDetailsViewBuilder,
	) {}

	#[HttpGet('/{memberId}/update'), ViewResponse]
	public function accountDetails(
		#[FromRoute('memberId')] MemberId $memberId
	): AccountDetailsView {
		return $this->accountDetailsViewBuilder->view($memberId);
	}

	#[HttpGet('/{memberId}'), ViewResponse]
	public function accountSettings(
		#[FromRoute('memberId')] MemberId $memberId
	): PageViewModel {
		$view = $this->accountDetailsViewBuilder->view($memberId);
		return $this->pageViewModelFactory->page(
			$view->pageTitle,
			$view,
			'account-details',
		);
	}
	
}