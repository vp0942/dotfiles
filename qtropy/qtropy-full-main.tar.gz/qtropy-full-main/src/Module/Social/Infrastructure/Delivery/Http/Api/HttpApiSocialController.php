<?php

namespace Walnut\Module\Social\Infrastructure\Delivery\Http\Api;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromFormParams;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpDelete;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpPost;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\NoContentResponse;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Social\Application\Context\_MemberSocial;
use Walnut\Module\Social\Application\Context\_MemberSocialMember;
use Walnut\Module\Social\Infrastructure\Delivery\Http\Api\Request\MemberBlockRequest;

final readonly class HttpApiSocialController {
	public function __construct(
		private _MemberSocial $memberSocial
	) {}

	private function getEntry(MemberId $memberId): _MemberSocialMember {
		return $this->memberSocial->withMember($memberId);
	}

	#[HttpPost('/followed/{followedId}/request'), NoContentResponse]
	public function memberFollowRequest(#[FromRoute] MemberId $followedId): void {
		$this->getEntry($followedId)->sendFollowRequest();
	}
	#[HttpDelete('/followed/{followedId}/request'), NoContentResponse]
	public function cancelMemberFollowRequest(#[FromRoute] MemberId $followedId): void {
		$this->getEntry($followedId)->cancelFollowRequest();
	}
	#[HttpDelete('/follower/{followerId}/request'), NoContentResponse]
	public function rejectMemberFollowRequest(#[FromRoute] MemberId $followerId): void {
		$this->getEntry($followerId)->rejectFollowRequest();
	}
	#[HttpDelete('/follower/{followerId}'), NoContentResponse]
	public function stopFollower(#[FromRoute] MemberId $followerId): void {
		$this->getEntry($followerId)->stopFollower();
	}
	#[HttpDelete('/followed/{followedId}'), NoContentResponse]
	public function memberUnfollow(#[FromRoute] MemberId $followedId): void {
		$this->getEntry($followedId)->unfollow();
	}
	#[HttpPost('/follower/{followerId}'), NoContentResponse]
	public function acceptMemberFollowRequest(#[FromRoute] MemberId $followerId): void {
		$this->getEntry($followerId)->acceptFollowRequest();
	}

	#[HttpPost('/block/{blockedId}'), NoContentResponse]
	public function memberBlock(
		#[FromRoute] MemberId $blockedId,
		#[FromFormParams] MemberBlockRequest $memberBlockRequest
	): void {
		$this->getEntry($blockedId)->block($memberBlockRequest->blockReason);
	}

	#[HttpDelete('/block/{blockedId}'), NoContentResponse]
	public function memberUnblock(#[FromRoute] MemberId $blockedId): void {
		$this->getEntry($blockedId)->unblock();
	}

}