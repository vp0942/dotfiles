<?php

namespace Walnut\Module\Social\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Page\PageViewModelFactory;
use Walnut\Module\Social\Presentation\View\Social\SocialView;
use Walnut\Module\Social\Presentation\View\Social\SocialViewBuilder;
use Walnut\Module\Social\Presentation\View\Social\SocialViewTab;

final readonly class HttpPageSocialController {
	public function __construct(
		private PageViewModelFactory $pageViewModelFactory,
		private SocialViewBuilder    $socialViewBuilder,
	) {}

	#[HttpGet('/{tab}/update'), ViewResponse]
	public function followFormUpdate(
		#[FromRoute] SocialViewTab $tab = SocialViewTab::followers
	): SocialView {
		return $this->socialViewBuilder->view($tab);
	}

	#[HttpGet('/{tab}'), ViewResponse]
	public function followForm(
		#[FromRoute] SocialViewTab $tab = SocialViewTab::followers
	): PageViewModel {
		$view = $this->socialViewBuilder->view($tab);
		return $this->pageViewModelFactory->page(
			$view->pageTitle,
			$view,
			'linked-users',
		);
	}

	#[HttpGet, ViewResponse]
	public function followFormDefault(): PageViewModel {
		return $this->followForm();
	}

}