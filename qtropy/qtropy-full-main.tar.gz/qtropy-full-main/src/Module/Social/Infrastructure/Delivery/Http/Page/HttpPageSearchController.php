<?php

namespace Walnut\Module\Social\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromQuery;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Application\Query\Search\ContentSearch;
use Walnut\Module\Feed\Application\Query\Search\ContentSearchType;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Page\PageViewModelFactory;
use Walnut\Module\Social\Presentation\View\Search\ByKeyResultView;
use Walnut\Module\Social\Presentation\View\Search\SearchResultView;
use Walnut\Module\Social\Presentation\View\Search\SearchViewBuilder;

final readonly class HttpPageSearchController {

	public function __construct(
		private SearchViewBuilder    $searchViewBuilder,
		private PageViewModelFactory $pageViewModelFactory,
	) {}

	#[HttpGet('/key/{contentKey}'), ViewResponse]
	public function findByKey(
		#[FromRoute] ContentKey $contentKey
	): ByKeyResultView {
		return $this->searchViewBuilder->byKeyResultView($contentKey);
	}

	/**
	 * @param string $searchIn
	 * @return ContentSearchType[]
	 */
	private static function searchTypes(string $searchIn): array {
		return ($searchIn === 'all' ? [] : array_filter(array_map(
			static fn(string $s): ?ContentSearchType => ContentSearchType::tryFrom($s),
			explode(',', $searchIn)
		))) ?: ContentSearchType::cases();
	}

	#[HttpGet('/content'), ViewResponse]
	public function searchContent(
		#[FromQuery] string $containsText,
		#[FromQuery] string $askedBy,
		#[FromQuery] string $answeredBy,
		#[FromQuery] string $sharedBy,
		#[FromQuery] string $searchIn = 'all',
	): SearchResultView {
		return $this->searchViewBuilder->resultView(
			new ContentSearch(
				self::searchTypes($searchIn),
				trim($containsText) ?: null,
				trim($askedBy) ?: null,
				trim($answeredBy) ?: null,
				trim($sharedBy) ?: null,
			),
		);
	}

	#[HttpGet, ViewResponse]
	public function searchForm(): PageViewModel {
		$view = $this->searchViewBuilder->searchView();
		return $this->pageViewModelFactory->page(
			'Search Form',
			$view,
			'search',
		);
	}

}