<?php

namespace Walnut\Module\Social\Domain\Model\FromStatus;

final readonly class NotRelated {

}