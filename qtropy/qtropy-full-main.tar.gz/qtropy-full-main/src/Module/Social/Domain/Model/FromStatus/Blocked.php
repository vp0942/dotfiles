<?php

namespace Walnut\Module\Social\Domain\Model\FromStatus;

use Walnut\Module\Kernel\Time\DateAndTime;

final readonly class Blocked {
	public function __construct(
		public DateAndTime $since,
		public string      $reason
	) {}
}