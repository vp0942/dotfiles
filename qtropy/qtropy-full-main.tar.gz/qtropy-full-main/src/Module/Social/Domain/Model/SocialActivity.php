<?php

namespace Walnut\Module\Social\Domain\Model;

use Walnut\Module\Kernel\Util\Wither;
use Walnut\Module\Social\Domain\Model\FromStatus\FromStatus;
use Walnut\Module\Social\Domain\Model\ToStatus\ToStatus;

final readonly class SocialActivity {
	use Wither;
	public function __construct(
		public ToStatus   $toMemberStatus,
		public FromStatus $fromMemberStatus,
	) {}

	public function withToStatus(ToStatus $toStatus): self {
		return $this->with(toMemberStatus: $toStatus);
	}

	public function withFromStatus(FromStatus $fromStatus): self {
		return $this->with(fromMemberStatus: $fromStatus);
	}
}