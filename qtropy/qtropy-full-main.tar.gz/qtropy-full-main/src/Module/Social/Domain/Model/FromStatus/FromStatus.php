<?php

namespace Walnut\Module\Social\Domain\Model\FromStatus;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Util\Wither;
use Walnut\Module\Social\Domain\Model\ActivityId;
use Walnut\Module\Social\Domain\Rejection\InvalidStatusChange;

final readonly class FromStatus {
	use Wither;

	public function __construct(
		public readonly ActivityId $activityId,
		public readonly MemberId $memberId,
		public readonly MemberId $otherMemberId,
		public readonly NotRelated|Blocked|RequestedFollow|Followed $status,
	) {}

	public function acceptFollowRequest(DateAndTime $onDate): self {
		return match($this->status::class) {
			RequestedFollow::class => $this->with(status: new Followed($onDate)),
			default => InvalidStatusChange::noFollowRequestToAccept()
		};
	}

	public function stopFollower(): self {
		return match($this->status::class) {
			Followed::class => $this->with(status: new NotRelated),
			default => InvalidStatusChange::cannotStopIfNotFollowed()
		};
	}

	public function rejectFollowRequest(): self {
		return match($this->status::class) {
			RequestedFollow::class => $this->with(status: new NotRelated()),
			default => InvalidStatusChange::noFollowRequestToReject()
		};
	}

}