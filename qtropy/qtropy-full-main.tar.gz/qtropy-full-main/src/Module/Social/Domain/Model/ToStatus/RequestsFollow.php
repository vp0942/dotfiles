<?php

namespace Walnut\Module\Social\Domain\Model\ToStatus;

use Walnut\Module\Kernel\Time\DateAndTime;

final readonly class RequestsFollow {
	public function __construct(
		public DateAndTime $requestedOn
	) {}
}