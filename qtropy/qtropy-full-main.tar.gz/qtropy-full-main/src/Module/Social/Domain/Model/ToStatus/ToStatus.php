<?php

namespace Walnut\Module\Social\Domain\Model\ToStatus;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Util\Wither;
use Walnut\Module\Social\Domain\Model\ActivityId;
use Walnut\Module\Social\Domain\Rejection\InvalidStatusChange;

final readonly class ToStatus {
	use Wither;

	public function __construct(
		public ActivityId                               $activityId,
		public MemberId                                 $memberId,
		public MemberId                                 $otherMemberId,
		public NoRelation|Blocks|RequestsFollow|Follows $status,
	) {}

	public function sendFollowRequest(DateAndTime $onDate): self {
		return match($this->status::class) {
			NoRelation::class => $this->with(status: new RequestsFollow($onDate)),
			default => InvalidStatusChange::noFollowRequestPossible()
		};
	}

	public function cancelFollowRequest(): self {
		return match($this->status::class) {
			RequestsFollow::class => $this->with(status: new NoRelation),
			default => InvalidStatusChange::noFollowRequestToCancel()
		};
	}

	public function unfollow(): self {
		return match($this->status::class) {
			Follows::class => $this->with(status: new NoRelation),
			default => InvalidStatusChange::cannotUnfollow()
		};
	}

	public function block(DateAndTime $onDate, string $blockReason): self {
		return match($this->status::class) {
			Blocks::class => InvalidStatusChange::noBlockPossible(),
			default => $this->with(status: new Blocks($onDate, $blockReason))
		};
	}

	public function unblock(): self {
		return match($this->status::class) {
			Blocks::class => $this->with(status: new NoRelation),
			default => InvalidStatusChange::cannotUnblock()
		};
	}

}