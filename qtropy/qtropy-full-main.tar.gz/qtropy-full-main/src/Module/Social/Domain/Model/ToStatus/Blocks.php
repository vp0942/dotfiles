<?php

namespace Walnut\Module\Social\Domain\Model\ToStatus;

use Walnut\Module\Kernel\Time\DateAndTime;

final readonly class Blocks {
	public function __construct(
		public DateAndTime $since,
		public string      $reason,
	) {}
}