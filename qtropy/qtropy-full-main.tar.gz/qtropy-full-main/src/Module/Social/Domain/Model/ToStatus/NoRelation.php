<?php

namespace Walnut\Module\Social\Domain\Model\ToStatus;

final readonly class NoRelation {

}