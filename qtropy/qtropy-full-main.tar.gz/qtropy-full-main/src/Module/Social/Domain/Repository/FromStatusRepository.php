<?php

namespace Walnut\Module\Social\Domain\Repository;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Social\Domain\Model\FromStatus\FromStatus;

interface FromStatusRepository {
	public function betweenMembers(
		MemberId $memberId,
		MemberId $otherMemberId,
	): FromStatus;
}