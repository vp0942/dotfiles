<?php

namespace Walnut\Module\Social\Domain\Repository;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class SocialActivityRepository {
	public function __construct(
		private FromStatusRepository $fromStatusRepository,
		private ToStatusRepository   $toStatusRepository,
	) {}

	public function betweenMembers(
		MemberId $memberId,
		MemberId $otherMemberId,
	): SocialActivity {
		return new SocialActivity(
			$this->toStatusRepository
				->betweenMembers($memberId, $otherMemberId),
			$this->fromStatusRepository
				->betweenMembers($memberId, $otherMemberId),
		);
	}
}