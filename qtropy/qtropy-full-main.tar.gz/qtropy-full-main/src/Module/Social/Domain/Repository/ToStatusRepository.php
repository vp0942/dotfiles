<?php

namespace Walnut\Module\Social\Domain\Repository;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Social\Domain\Model\ToStatus\ToStatus;

interface ToStatusRepository {
	public function betweenMembers(
		MemberId $memberId,
		MemberId $otherMemberId,
	): ToStatus;
}