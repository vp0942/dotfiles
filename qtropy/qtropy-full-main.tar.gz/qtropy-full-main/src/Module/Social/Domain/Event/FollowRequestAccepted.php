<?php

namespace Walnut\Module\Social\Domain\Event;

use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class FollowRequestAccepted {
	public function __construct(
		public SocialActivity $activity
	) {}
}