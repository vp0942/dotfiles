<?php

namespace Walnut\Module\Social\Domain\Event;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class FollowRequestSent {
	public function __construct(
		public SocialActivity $activity,
		public Member         $member,
		public Member         $otherMember,
	) {}
}