<?php

namespace Walnut\Module\Social\Domain\Rejection;

use Walnut\Module\Kernel\Exception\ProcessException;

final class InvalidStatusChange extends ProcessException {

	private const noFollowRequestToCancel = 'No follow request to cancel';
	public static function noFollowRequestToCancel(): never {
		throw new self(self::noFollowRequestToCancel);
	}

	private const cannotUnfollow = 'Cannot unfollow if not following';
	public static function cannotUnfollow(): never {
		throw new self(self::cannotUnfollow);
	}

	private const cannotUnblock = 'Cannot unblock if not blocked';
	public static function cannotUnblock(): never {
		throw new self(self::cannotUnblock);
	}

	private const noBlockPossible = 'Cannot block if already blocked';
	public static function noBlockPossible(): never {
		throw new self(self::noBlockPossible);
	}

	private const noFollowRequestToAccept = 'No follow request to accept';
	public static function noFollowRequestToAccept(): never {
		throw new self(self::noFollowRequestToAccept);
	}

	private const noFollowRequestToReject = 'No follow request to reject';
	public static function noFollowRequestToReject(): never {
		throw new self(self::noFollowRequestToReject);
	}

	private const cannotStopIfNotFollowed = 'Cannot stop follower if not followed';
	public static function cannotStopIfNotFollowed(): never {
		throw new self(self::cannotStopIfNotFollowed);
	}

	private const noFollowRequestPossible = 'Cannot send follow request';
	public static function noFollowRequestPossible(): never {
		throw new self(self::noFollowRequestPossible);
	}
}