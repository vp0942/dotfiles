<?php

namespace Walnut\Module\Social\Domain\Command;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Event\FollowerStopped;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class StopFollower {
	public function __invoke(
		Member $member,
		SocialActivity $socialActivity,
		Member $otherMember,
	): FollowerStopped {
		return new FollowerStopped(
			$socialActivity->withFromStatus(
				$socialActivity->fromMemberStatus
					->stopFollower()
			),
		);
	}
}