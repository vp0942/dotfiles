<?php

namespace Walnut\Module\Social\Domain\Command;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Event\FollowRequestCancelled;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class CancelFollowRequest {
	public function __invoke(
		Member $member,
		SocialActivity $socialActivity,
		Member $otherMember,
	): FollowRequestCancelled {
		return new FollowRequestCancelled(
			$socialActivity->withToStatus(
				$socialActivity->toMemberStatus
					->cancelFollowRequest()
			),
		);
	}
}