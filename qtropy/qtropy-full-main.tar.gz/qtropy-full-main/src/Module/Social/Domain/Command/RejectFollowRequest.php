<?php

namespace Walnut\Module\Social\Domain\Command;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Event\FollowRequestRejected;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class RejectFollowRequest {
	public function __invoke(
		Member $member,
		SocialActivity $socialActivity,
		Member $otherMember,
	): FollowRequestRejected {
		return new FollowRequestRejected(
			$socialActivity->withFromStatus(
				$socialActivity->fromMemberStatus
					->rejectFollowRequest()
			),
		);
	}
}