<?php

namespace Walnut\Module\Social\Domain\Command;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Event\MemberUnfollowed;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class UnfollowMember {
	public function __invoke(
		Member $member,
		SocialActivity $socialActivity,
		Member $otherMember,
	): MemberUnfollowed {
		return new MemberUnfollowed(
			$socialActivity->withToStatus(
				$socialActivity->toMemberStatus
					->unfollow()
			),
		);
	}
}