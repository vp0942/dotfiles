<?php

namespace Walnut\Module\Social\Domain\Command;

use Walnut\Module\Kernel\Time\SystemTime;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Event\FollowRequestSent;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class SendFollowRequest {
	public function __construct(
		private SystemTime $systemTime
	) {}

	public function __invoke(
		Member $member,
		SocialActivity $socialActivity,
		Member $otherMember,
	): FollowRequestSent {
		return new FollowRequestSent(
			$socialActivity->withToStatus(
				$socialActivity->toMemberStatus
					->sendFollowRequest($this->systemTime->now())
			),
			$member,
			$otherMember
		);
	}
}