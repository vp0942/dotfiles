<?php

namespace Walnut\Module\Social\Domain\Command;

use Walnut\Module\Kernel\Time\SystemTime;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Event\FollowRequestAccepted;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class AcceptFollowRequest {
	public function __construct(
		private SystemTime $systemTime
	) {}

	public function __invoke(
		Member $member,
		SocialActivity $socialActivity,
		Member $otherMember,
	): FollowRequestAccepted {
		return new FollowRequestAccepted(
			$socialActivity->withFromStatus(
				$socialActivity->fromMemberStatus
					->acceptFollowRequest(
						$this->systemTime->now()
					)
			),
		);
	}
}