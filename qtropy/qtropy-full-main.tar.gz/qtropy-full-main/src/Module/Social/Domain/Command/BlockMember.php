<?php

namespace Walnut\Module\Social\Domain\Command;

use Walnut\Module\Kernel\Time\SystemTime;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Event\MemberBlocked;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class BlockMember {
	public function __construct(
		private SystemTime $systemTime
	) {}

	public function __invoke(
		Member $member,
		SocialActivity $socialActivity,
		Member $otherMember,
		string $blockReason
	): MemberBlocked {
		return new MemberBlocked(
			$socialActivity->withToStatus(
				$socialActivity->toMemberStatus->block(
					$this->systemTime->now(),
					$blockReason,
				)
			),
		);
	}
}