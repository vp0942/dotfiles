<?php

namespace Walnut\Module\Social\Domain\Command;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Social\Domain\Event\MemberUnblocked;
use Walnut\Module\Social\Domain\Model\SocialActivity;

final readonly class UnblockMember {
	public function __invoke(
		Member $member,
		SocialActivity $socialActivity,
		Member $otherMember,
	): MemberUnblocked {
		return new MemberUnblocked(
			$socialActivity->withToStatus(
				$socialActivity->toMemberStatus->unblock()
			),
		);
	}
}