<?php

namespace Walnut\Module\Member\Infrastructure\Delivery\Http\Api;

use Walnut\Lib\DataType\Exception\InvalidData;
use Walnut\Lib\HttpMapper\Attribute\ErrorHandler;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromJsonBody;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpPatch;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\NoContentResponse;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\JsonResponseBody;
use Walnut\Module\Member\Application\Context\_Member;
use Walnut\Module\Member\Domain\Exception\InvalidNotificationType;
use Walnut\Module\Member\Domain\Model\ProfileDetails;

final readonly class HttpApiProfileController {

	public function __construct(
		private _Member $member,
	) {}

	#[HttpPatch, NoContentResponse]
	public function updateProfile(
		#[FromJsonBody] ProfileDetails $profileDetails
	): void {
		$this->member->profile()->withNewProfileDetails($profileDetails);
	}

	#[ErrorHandler(InvalidData::class), JsonResponseBody(400)]
	public function onInvalidData(InvalidData $ex): array {
		return [
			'error' => $ex->getMessage()
		];
	}

	#[ErrorHandler(InvalidNotificationType::class), JsonResponseBody(400)]
	public function onInvalidNotificationType(InvalidNotificationType $ex): array {
		return [
			'error' => $ex->getMessage()
		];
	}

}