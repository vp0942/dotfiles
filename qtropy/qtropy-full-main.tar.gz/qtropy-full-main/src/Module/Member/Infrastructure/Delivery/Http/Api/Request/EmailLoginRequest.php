<?php

namespace Walnut\Module\Member\Infrastructure\Delivery\Http\Api\Request;

use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Password;

final readonly class EmailLoginRequest {
	public function __construct(
		public EmailAddress $email,
		public Password $password,
	) {}
}