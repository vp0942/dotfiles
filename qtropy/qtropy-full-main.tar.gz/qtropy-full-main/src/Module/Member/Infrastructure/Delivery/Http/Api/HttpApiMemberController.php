<?php

namespace Walnut\Module\Member\Infrastructure\Delivery\Http\Api;

use Psr\Http\Message\ResponseInterface;
use Walnut\App\AccessTokenGenerator;
use Walnut\Lib\DataType\Exception\InvalidData;
use Walnut\Lib\HttpMapper\Attribute\ErrorHandler;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromFormParams;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpPost;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\JsonResponseBody;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\RedirectResponse;
use Walnut\Lib\HttpMapper\ResponseBuilder;
use Walnut\Module\Member\Application\Context\_Members;
use Walnut\Module\Member\Application\Context\UnknownMember;
use Walnut\Module\Member\Domain\Model\NotificationAlerts;
use Walnut\Module\Member\Domain\Model\PasswordChangeData;
use Walnut\Module\Member\Domain\Model\PasswordRecoveryData;
use Walnut\Module\Member\Domain\Model\ProfileDetails;
use Walnut\Module\Member\Domain\Rejection\CannotChangePassword;
use Walnut\Module\Member\Domain\Rejection\DuplicateEmail;
use Walnut\Module\Member\Domain\Rejection\DuplicateUsername;
use Walnut\Module\Member\Infrastructure\Delivery\Http\Api\Request\EmailLoginRequest;
use Walnut\Module\Member\Infrastructure\Delivery\Http\Api\Request\LoginRequest;
use Walnut\Module\Member\Infrastructure\Delivery\Http\Api\Request\RegisterRequest;

final readonly class HttpApiMemberController {

	public function __construct(
		private AccessTokenGenerator $accessTokenGenerator,
		private _Members             $members,
		private ResponseBuilder      $responseBuilder,
		private string               $cookieName
	) {}

	#[HttpPost('/logout')]
	public function logout(
	): ResponseInterface {
		return $this->responseBuilder->emptyResponse(204)
			->withAddedHeader(
				'Set-Cookie',
				"$this->cookieName=; Path=/; SameSite=Strict"
			);
	}

	#[HttpPost('/register'), RedirectResponse]
	public function register(
		#[FromFormParams] RegisterRequest $registerData
	): string {
		$memberId = $this->members->register(
			$registerData->email,
			$registerData->username,
			$registerData->password,
			new ProfileDetails(
				$registerData->profilePicture,
				$registerData->profileDescription,
				NotificationAlerts::fromBitmask(0),
				$registerData->theme
			),
			false
		);
		return $memberId->memberId()->value->stringValue;
	}

	#[HttpPost('/password-change'), JsonResponseBody(204)]
	public function passwordChange(
		#[FromFormParams] PasswordChangeData $passwordChangeData
	): void {
		$this->members
			->memberByEmail($passwordChangeData->email)
			->profile()->withNewPassword(
				$passwordChangeData->newPassword,
				$passwordChangeData->passwordRecoveryToken,
			);
	}

	#[HttpPost('/password-recovery'), JsonResponseBody(204)]
	public function passwordRecovery(
		#[FromFormParams] PasswordRecoveryData $passwordRecoveryData
	): void {
		$this->members
			->memberByEmail($passwordRecoveryData->email)
			->profile()->passwordRecoveryRequest();
	}

	#[HttpPost('/login/with-email')]
	public function loginWithEmail(
		#[FromFormParams] EmailLoginRequest $loginData
	): ResponseInterface {
		$member = $this->members->memberByEmail($loginData->email);
		$isAuthorized = $member->profile()->isAuthorizedWithPassword($loginData->password);
		if ($isAuthorized) {
			$token = $this->accessTokenGenerator->generateToken($member->memberId());

			return $this->responseBuilder->jsonResponse($token)
				->withAddedHeader(
					'Set-Cookie',
					"$this->cookieName=$token; Path=/; SameSite=Strict"
				);
		}
		return $this->responseBuilder->jsonResponse(['error' => 'Login failed'], 403);
	}

	#[HttpPost('/login')]
	public function login(
		#[FromFormParams] LoginRequest $loginData
	): ResponseInterface {
		$member = $this->members->memberByUsername($loginData->username);
		$isAuthorized = $member->profile()->isAuthorizedWithPassword($loginData->password);
		if ($isAuthorized) {
			$token = $this->accessTokenGenerator->generateToken($member->memberId());

			return $this->responseBuilder->jsonResponse($token)
				->withAddedHeader(
					'Set-Cookie',
					"$this->cookieName=$token; Path=/; SameSite=Strict"
				);
		}
		return $this->responseBuilder->jsonResponse(['error' => 'Login failed'], 403);
	}


	#[ErrorHandler(InvalidData::class), JsonResponseBody(400)]
	public function onInvalidData(InvalidData $error): array {
		return [
			'error' => "Invalid username or password."// . $error->getMessage()
		];
	}

	#[ErrorHandler(CannotChangePassword::class), JsonResponseBody(403)]
	public function onCannotChangePassword(CannotChangePassword $error): array {
		return [
			'error' => "Cannot change the password: " . $error->getMessage()
		];
	}

	#[ErrorHandler(UnknownMember::class), JsonResponseBody(403)]
	public function onUnknownMember(UnknownMember $member): array {
		return [
			'error' => "Invalid username or password"
		];
	}

	#[ErrorHandler(DuplicateUsername::class), JsonResponseBody(403)]
	public function onDuplicateUsername(DuplicateUsername $error): array {
		return [
			'error' => "This username is already in use"
		];
	}

	#[ErrorHandler(DuplicateEmail::class), JsonResponseBody(403)]
	public function onDuplicateEmail(DuplicateEmail $error): array {
		return [
			'error' => "This email is already in use"
		];
	}

}