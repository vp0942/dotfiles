<?php

namespace Walnut\Module\Member\Infrastructure\Delivery\Http\Api\Request;

use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Model\Username;

final readonly class RegisterRequest {
	public function __construct(
		public EmailAddress $email,
		public Username $username,
		public Password $password,
		public string $profilePicture,
		public string $profileDescription,
		public string $theme,
	) {}
}