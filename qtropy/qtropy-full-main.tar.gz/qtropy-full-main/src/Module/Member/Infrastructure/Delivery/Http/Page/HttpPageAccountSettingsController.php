<?php

namespace Walnut\Module\Member\Infrastructure\Delivery\Http\Page;

use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Page\PageViewModelFactory;
use Walnut\Module\Member\Presentation\AccountSettings\AccountSettingsViewBuilder;

final readonly class HttpPageAccountSettingsController {

	public function __construct(
		private AccountSettingsViewBuilder $accountSettingsViewBuilder,
		private PageViewModelFactory       $pageViewModelFactory,
	) {}

	#[HttpGet, ViewResponse]
	public function accountSettings(): PageViewModel {
		$view = $this->accountSettingsViewBuilder->view();
		return $this->pageViewModelFactory->page(
			$view->pageTitle,
			$view,
			'account-settings',
		);
	}

}