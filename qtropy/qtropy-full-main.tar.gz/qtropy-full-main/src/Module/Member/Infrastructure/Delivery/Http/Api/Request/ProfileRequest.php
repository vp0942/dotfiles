<?php

namespace Walnut\Module\Member\Infrastructure\Delivery\Http\Api\Request;

final readonly class ProfileRequest {

}