<?php

namespace Walnut\Module\Member\Infrastructure\Delivery\Http\Api\Request;

use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Model\Username;

final readonly class LoginRequest {
	public function __construct(
		public Username $username,
		public Password $password,
	) {}
}