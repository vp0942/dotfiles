<?php

namespace Walnut\Module\Member\Infrastructure\Delivery\Http\Page;

use Psr\Http\Message\ServerRequestInterface;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromQuery;
use Walnut\Lib\HttpMapper\Attribute\RequestMapper\FromRoute;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\DefaultRouteMatch;
use Walnut\Lib\HttpMapper\Attribute\RequestMatch\HttpGet;
use Walnut\Lib\HttpMapper\Attribute\ResponseMapper\ViewResponse;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Page\PageViewModel;
use Walnut\Module\Kernel\Uuid\InvalidUuid;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Member\Application\Context\_Members;
use Walnut\Module\Member\Application\Context\UnknownMember;
use Walnut\Module\Member\Domain\Rejection\CannotConfirmRegistration;
use Walnut\Module\Member\Presentation\LoginPage\LoginPageViewBuilder;
use Walnut\Module\Member\Presentation\PasswordRecoveryPage\PasswordRecoveryPageViewBuilder;
use Walnut\Module\Member\Presentation\RegisterPage\RegisterPageViewBuilder;
use Walnut\Module\Qtropy\Presentation\AnonymousPageViewModelFactory;

final readonly class HttpPageMemberController {
	public function __construct(
		private RegisterPageViewBuilder $registerPageViewBuilder,
		private PasswordRecoveryPageViewBuilder $passwordRecoveryPageViewBuilder,
		private LoginPageViewBuilder $loginPageViewBuilder,
		private AnonymousPageViewModelFactory $anonymousPageViewModelFactory,
		private _Members $members,
	) {}

	#[HttpGet('/register/{token}'), ViewResponse]
	public function registerConfirmation(
		#[FromRoute] string $token,
		#[FromQuery] string|null $email
	): PageViewModel {
		$success = false;
		try {
			$this->members->member(
				new MemberId(Uuid::fromString($token))
			)->profile()->confirmRegistration();
			$success = true;
		} catch (InvalidUuid | UnknownMember | CannotConfirmRegistration) {}

		return $this->anonymousPageViewModelFactory->page(
			'Register Confirmation',
			$this->registerPageViewBuilder->confirmationView($email, $success)
		);
	}

	#[HttpGet('/register'), ViewResponse]
	public function register(
		ServerRequestInterface $request,
		#[FromQuery] string|null $email
	): PageViewModel {
		return $this->anonymousPageViewModelFactory->page(
			'Register',
			$this->registerPageViewBuilder->view($email, $request->getRequestTarget())
		);
	}

	#[HttpGet('/password-recovery/{token}'), ViewResponse]
	public function passwordChange(
		#[FromRoute] $token,
		#[FromQuery] string|null $email
	): PageViewModel {
		return $this->anonymousPageViewModelFactory->page(
			'Password Change',
			$this->passwordRecoveryPageViewBuilder->passwordChangePageView($token, $email)
		);
	}

	#[HttpGet('/password-recovery'), ViewResponse]
	public function passwordRecovery(
		ServerRequestInterface $request,
		#[FromQuery] string|null $email
	): PageViewModel {
		return $this->anonymousPageViewModelFactory->page(
			'Password Recovery',
			$this->passwordRecoveryPageViewBuilder->passwordRecoveryPageView($email)
		);
	}

	#[DefaultRouteMatch, ViewResponse]
	public function login(
		ServerRequestInterface $request,
		#[FromQuery] string|null $username
	): PageViewModel {
		return $this->anonymousPageViewModelFactory->page(
			'Login',
			$this->loginPageViewBuilder->view($username, '/'),
		);
	}
}