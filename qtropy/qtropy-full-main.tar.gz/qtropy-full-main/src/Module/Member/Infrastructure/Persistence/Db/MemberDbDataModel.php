<?php

namespace Walnut\Module\Member\Infrastructure\Persistence\Db;

use Walnut\Lib\DbDataModel\Attribute\Fields;
use Walnut\Lib\DbDataModel\Attribute\KeyField;
use Walnut\Lib\DbDataModel\Attribute\ModelRoot;
use Walnut\Lib\DbDataModel\Attribute\Table;

#[ModelRoot('members')]
final readonly class MemberDbDataModel {
	public function __construct(
		#[Table('members'), KeyField('member_id'), Fields(
			'email_address', 'username', 'profile_picture',
			'profile_description', 'notification_alerts', 'profile_theme',
			'password_hash',
		)]
		public array $members,
	) {}
}