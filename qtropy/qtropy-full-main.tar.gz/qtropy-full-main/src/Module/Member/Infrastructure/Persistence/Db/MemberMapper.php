<?php

namespace Walnut\Module\Member\Infrastructure\Persistence\Db;

use Walnut\Lib\DataType\Exception\InvalidValue;
use Walnut\Lib\WriteModel\Mapper\EntityMapper;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\NotificationAlerts;
use Walnut\Module\Member\Domain\Model\PasswordHash;
use Walnut\Module\Member\Domain\Model\ProfileDetails;
use Walnut\Module\Member\Domain\Model\Username;

/**
 * @implements EntityMapper<Member, MemberId, array, string>
 */
final readonly class MemberMapper implements EntityMapper {
	/**
	 * @param Member $mapped
	 * @return array
	 */
	public function toSourceEntity(object|array $mapped): array {
		return [
			'member_id' => $mapped->memberId->value->binaryValue,
			'email_address' => $mapped->emailAddress->value,
			'username' => $mapped->username->value,
			'profile_picture' => $mapped->profileDetails->profilePicture,
			'profile_description' => $mapped->profileDetails->profileDescription,
			'notification_alerts' => $mapped->profileDetails->notificationAlerts->bitmaskValue(),
			'profile_theme' => $mapped->profileDetails->theme,
			'password_hash' => $mapped->passwordHash->value,
		];
	}

	/**
	 * @param MemberId $mapped
	 * @return string
	 */
	public function toSourceId(object|int|string $mapped): string {
		return $mapped->value->binaryValue;
	}

	/**
	 * @param array $source
	 * @throws InvalidValue
	 * @return Member
	 */
	public function fromSourceEntity(object|array $source): Member {
		return new Member(
			new MemberId(Uuid::fromBinary((string)($source['member_id'] ?? ''))),
			new EmailAddress((string)($source['email_address'] ?? '')),
			new Username((string)($source['username'] ?? '')),
			new PasswordHash((string)($source['password_hash'] ?? '')),
			new ProfileDetails(
				(string)($source['profile_picture'] ?? ''),
				(string)($source['profile_description'] ?? ''),
				NotificationAlerts::fromBitmask((int)($source['notification_alerts'] ?? 0)),
				(string)($source['profile_theme'] ?? ''),
			)
		);
	}

	/**
	 * @param string $source
	 * @return MemberId
	 */
	public function fromSourceId(object|int|string $source): MemberId {
		return new MemberId(Uuid::fromBinary($source));
	}
}
