<?php

namespace Walnut\Module\Member\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Member\Application\Context\MemberByEmail;
use Walnut\Module\Member\Application\Context\MemberById;
use Walnut\Module\Member\Application\Context\UnknownMember;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class DbMemberByEmail implements MemberByEmail {

	public function __construct(
		private QueryExecutor $queryExecutor,
		private MemberById    $memberById
	) {}

	public function __invoke(EmailAddress $emailAddress): Member {
		$memberId = $this->queryExecutor->execute("SELECT member_id FROM members WHERE email_address = ?", [
			$emailAddress->value
		])->singleValue();
		return $memberId ? ($this->memberById)(
			new MemberId(Uuid::fromBinary($memberId))
		) : UnknownMember::withEmail($emailAddress);
	}
}