<?php

namespace Walnut\Module\Member\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Member\Application\Context\MemberById;
use Walnut\Module\Member\Application\Context\MemberByUsername;
use Walnut\Module\Member\Application\Context\UnknownMember;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\Username;

final readonly class DbMemberByUsername implements MemberByUsername {

	public function __construct(
		private QueryExecutor $queryExecutor,
		private MemberById    $memberById
	) {}

	public function __invoke(Username $username): Member {
		$memberId = $this->queryExecutor->execute("SELECT member_id FROM members WHERE username = ?", [
			$username->value
		])->singleValue();
		return $memberId ? ($this->memberById)(
			new MemberId(Uuid::fromBinary($memberId))
		) : UnknownMember::withUsername($username);
	}
}