<?php

namespace Walnut\Module\Member\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Username;
use Walnut\Module\Member\Domain\Service\EmailChecker;
use Walnut\Module\Member\Domain\Service\UsernameChecker;

final readonly class DbUniquenessChecker implements UsernameChecker, EmailChecker {

	public function __construct(
		private QueryExecutor $queryExecutor
	) {}

	public function emailIsFree(EmailAddress $emailAddress): bool {
		return !$this->queryExecutor->execute(
			"SELECT member_id FROM members WHERE email_address = ?", [
				$emailAddress->value
			]
		)->singleValue();
	}

	public function usernameIsFree(Username $username): bool {
		return !$this->queryExecutor->execute(
			"SELECT member_id FROM members WHERE username = ?", [
				$username->value
			]
		)->singleValue();
	}
}