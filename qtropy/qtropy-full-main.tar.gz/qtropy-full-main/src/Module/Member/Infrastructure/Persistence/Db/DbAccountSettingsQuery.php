<?php

namespace Walnut\Module\Member\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Member\Application\Query\AccountSettings\AccountSettingsData;
use Walnut\Module\Member\Application\Query\AccountSettings\AccountSettingsQuery;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\NotificationAlerts;

final readonly class DbAccountSettingsQuery implements AccountSettingsQuery {
	private const query = <<<SQL
		SELECT 
		    BIN_TO_UUID(m.member_id) AS memberId,
		    m.username,
		    m.email_address AS emailAddress,
		    COALESCE(m.profile_description, '') AS profileDescription,
		    COALESCE(m.profile_picture, '') AS profilePicture,
		    COALESCE(m.profile_theme, '') AS theme,
		    m.notification_alerts AS notificationAlerts
		FROM members m
		WHERE m.member_id = :memberId
SQL;

	public function __construct(
		private readonly QueryExecutor $queryExecutor
	) {}

	public function __invoke(Member $member): AccountSettingsData {
		return $this->accountSettingsData(
			$this->queryExecutor->execute(self::query, [
				'memberId' => $member->memberId->value->binaryValue
			])->first()
		);
	}

	private function accountSettingsData(array $row): AccountSettingsData {
		$row['notificationAlerts'] = NotificationAlerts::fromBitmask($row['notificationAlerts']);
		return new AccountSettingsData(... $row);
	}
}