<?php

namespace Walnut\Module\Member\Infrastructure;

use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Model\PasswordHash;
use Walnut\Module\Member\Domain\Service\PasswordChecker;
use Walnut\Module\Member\Domain\Service\PasswordHasher;

final readonly class PhpPasswordHandler implements PasswordChecker, PasswordHasher {

	public function checkPassword(Password $password, PasswordHash $hash): bool {
		return password_verify($password->value, $hash->value);
	}

	public function hashPassword(Password $password): PasswordHash {
		return new PasswordHash(
			password_hash($password->value, PASSWORD_BCRYPT)
		);
	}
}