<?php

namespace Walnut\Module\Member\Infrastructure;

final readonly class Service {

}