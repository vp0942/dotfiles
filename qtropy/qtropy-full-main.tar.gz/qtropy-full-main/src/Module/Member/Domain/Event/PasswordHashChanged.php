<?php

namespace Walnut\Module\Member\Domain\Event;

use Walnut\Module\Member\Domain\Model\Member;

final readonly class PasswordHashChanged {
	public function __construct(
		public Member $member,
		public Member $previousState,
	) {}
}