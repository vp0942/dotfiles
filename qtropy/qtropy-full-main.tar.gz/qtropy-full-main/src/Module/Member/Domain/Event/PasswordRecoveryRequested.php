<?php

namespace Walnut\Module\Member\Domain\Event;

use Walnut\Module\Member\Domain\Model\Member;

final readonly class PasswordRecoveryRequested {
	private function __construct(
		public Member $member,
		public string $token,
	) {}

	public static function for(Member $account, string $token): self {
		return new self($account, $token);
	}
}