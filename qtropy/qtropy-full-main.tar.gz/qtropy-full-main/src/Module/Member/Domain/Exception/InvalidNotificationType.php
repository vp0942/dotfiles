<?php

namespace Walnut\Module\Member\Domain\Exception;

use Walnut\Module\Kernel\Exception\ProcessException;

final class InvalidNotificationType extends ProcessException {
	public function __construct(
		public readonly string $alertType
	) {
		parent::__construct(sprintf("Invalid notification alert type: %s", $alertType));
	}
}
