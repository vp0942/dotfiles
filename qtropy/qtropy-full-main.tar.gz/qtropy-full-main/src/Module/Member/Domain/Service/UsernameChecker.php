<?php

namespace Walnut\Module\Member\Domain\Service;

use Walnut\Module\Member\Domain\Model\Username;

interface UsernameChecker {
	public function usernameIsFree(Username $username): bool;
}