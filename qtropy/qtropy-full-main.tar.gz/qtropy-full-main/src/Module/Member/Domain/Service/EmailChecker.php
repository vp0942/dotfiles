<?php

namespace Walnut\Module\Member\Domain\Service;

use Walnut\Module\Member\Domain\Model\EmailAddress;

interface EmailChecker {
	public function emailIsFree(EmailAddress $emailAddress): bool;
}