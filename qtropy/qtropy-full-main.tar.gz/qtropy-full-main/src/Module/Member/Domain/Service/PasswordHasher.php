<?php

namespace Walnut\Module\Member\Domain\Service;

use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Model\PasswordHash;

interface PasswordHasher {
	public function hashPassword(Password $password): PasswordHash;
}