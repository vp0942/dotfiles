<?php

namespace Walnut\Module\Member\Domain\Rejection;

use LogicException;
use Walnut\Module\Member\Domain\Model\Username;

final class DuplicateUsername extends LogicException {
	private const errorMessage = "Duplicate username %s";
	public static function for(Username $username): never {
		throw new self(sprintf(self::errorMessage, $username));
	}
}