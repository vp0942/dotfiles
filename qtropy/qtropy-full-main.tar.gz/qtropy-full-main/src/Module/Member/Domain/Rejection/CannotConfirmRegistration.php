<?php

namespace Walnut\Module\Member\Domain\Rejection;

use LogicException;
use Walnut\Module\Member\Domain\Model\EmailAddress;

final class CannotConfirmRegistration extends LogicException {
	private const errorMessage = "Cannot confirm registration for user with email %s";
	public static function for(EmailAddress $emailAddress): never {
		throw new self(sprintf(self::errorMessage, $emailAddress));
	}
}