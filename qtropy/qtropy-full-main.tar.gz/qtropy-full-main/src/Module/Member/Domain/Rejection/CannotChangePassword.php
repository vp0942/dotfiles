<?php

namespace Walnut\Module\Member\Domain\Rejection;

use LogicException;
use Walnut\Module\Member\Domain\Model\EmailAddress;

final class CannotChangePassword extends LogicException {
	private const errorMessage = "Cannot change password for user with email %s";
	public static function for(EmailAddress $emailAddress): never {
		throw new self(sprintf(self::errorMessage, $emailAddress));
	}
}