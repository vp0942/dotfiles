<?php

namespace Walnut\Module\Member\Domain\Model;

use Attribute;
use Walnut\Lib\DataType\DirectValue;
use Walnut\Lib\DataType\Exception\InvalidValueType;

#[Attribute]
final readonly class NotificationAlertsData implements DirectValue {
	public function importValue(float|object|int|bool|array|string|null $value): NotificationAlerts {
		if (!is_array($value)) {
			throw new InvalidValueType('array', gettype($value));
		}
		return NotificationAlerts::fromStringArray(...$value);
	}
}