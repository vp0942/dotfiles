<?php

namespace Walnut\Module\Member\Domain\Model;

use Walnut\Lib\DataType\StringData;

final readonly class PasswordChangeData {
	public function __construct(
		public string       $passwordRecoveryToken,
		public EmailAddress $email,
		public Password       $newPassword,
	) {}
}
