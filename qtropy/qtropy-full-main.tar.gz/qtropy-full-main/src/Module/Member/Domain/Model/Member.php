<?php

namespace Walnut\Module\Member\Domain\Model;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Util\Wither;

final readonly class Member {
	use Wither;
	public function __construct(
		public MemberId       $memberId,
		public EmailAddress   $emailAddress,
		public Username       $username,
		public PasswordHash   $passwordHash,
		public ProfileDetails $profileDetails,
	) {}

	public function withNewUsername(Username $newUsername): self {
		return $this->with(username: $newUsername);
	}

	public function withNewEmailAddress(EmailAddress $newEmailAddress): self {
		return $this->with(emailAddress: $newEmailAddress);
	}

	public function withNewPasswordHash(PasswordHash $newPasswordHash): self {
		return $this->with(passwordHash: $newPasswordHash);
	}

	public function withNewProfileDetails(ProfileDetails $newProfileDetails): self {
		return $this->with(profileDetails: $newProfileDetails);
	}
}