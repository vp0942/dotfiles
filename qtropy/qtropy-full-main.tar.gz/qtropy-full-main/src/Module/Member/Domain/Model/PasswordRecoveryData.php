<?php

namespace Walnut\Module\Member\Domain\Model;

final readonly class PasswordRecoveryData {
	public function __construct(
		public EmailAddress $email,
	) {}
}
