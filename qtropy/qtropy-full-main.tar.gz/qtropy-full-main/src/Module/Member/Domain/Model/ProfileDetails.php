<?php

namespace Walnut\Module\Member\Domain\Model;

final readonly class ProfileDetails {
	public function __construct(
		public string             $profilePicture,
		public string             $profileDescription,
		public NotificationAlerts $notificationAlerts,
		public string             $theme,
	) {}
}