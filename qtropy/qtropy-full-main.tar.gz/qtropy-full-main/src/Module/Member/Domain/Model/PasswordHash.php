<?php

namespace Walnut\Module\Member\Domain\Model;

use Walnut\Lib\DataType\Exception\InvalidValue;
use Walnut\Lib\DataType\StringData;
use Walnut\Lib\DataType\WrapperData;

#[WrapperData]
final readonly class PasswordHash {
	public string $value;
	/** @throws InvalidValue */
	public function __construct(string $value) {
		$this->value = (new StringData(minLength: 5, maxLength: 127))
			->importValue($value);
	}
}