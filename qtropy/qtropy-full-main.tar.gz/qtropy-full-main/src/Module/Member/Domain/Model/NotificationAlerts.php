<?php

namespace Walnut\Module\Member\Domain\Model;

use Walnut\Module\Member\Domain\Exception\InvalidNotificationType;
use Walnut\Module\Notification\Domain\Model\NotificationTypeGroup;

#[NotificationAlertsData]
final readonly class NotificationAlerts {
	/**
	 * @var NotificationTypeGroup[] $values
	 */
	public array $values;
	public function __construct(
		NotificationTypeGroup ... $values
	) {
		$this->values = $values;
	}

	public function has(NotificationTypeGroup $notificationType): bool {
		return in_array($notificationType, $this->values, true);
	}

	public static function fromBitmask(int $bitmask): self {
		$result = [];
		foreach(NotificationTypeGroup::cases() as $case) {
			if ($case->value & $bitmask) {
				$result[] = $case;
			}
		}
		return new self(...$result);
	}

	public function bitmaskValue(): int {
		return array_sum(array_map(static fn(
			NotificationTypeGroup $notificationType
		): int => $notificationType->value, $this->values));
	}

	private static function lookup(): array {
		static $lookup = null;
		if ($lookup === null) {
			$lookup = [];
			foreach(NotificationTypeGroup::cases() as $case) {
				$lookup[$case->name] = $case;
			}
		}
		return $lookup;
	}

	/**
	 * @param string ...$values
	 * @return self
	 */
	public static function fromStringArray(string ...$values): self {
		$lookup = self::lookup();
		return new self(...array_map(static fn(string $value): NotificationTypeGroup =>
			$lookup[$value] ?? throw new InvalidNotificationType($value),
			//@TODO - better exception
			$values));
	}
}