<?php

namespace Walnut\Module\Member\Domain\Model;

use Walnut\Lib\DataType\Exception\InvalidValue;
use Walnut\Lib\DataType\StringData;
use Walnut\Lib\DataType\WrapperData;

#[WrapperData]
final readonly class EmailAddress {
	public string $value;

	/** @throws InvalidValue */
	public function __construct(string $value) {
		$this->value = (new StringData(minLength: 1, maxLength: 127, format: 'email'))
			->importValue($value);
	}

	public function __toString(): string {
		return $this->value;
	}
}