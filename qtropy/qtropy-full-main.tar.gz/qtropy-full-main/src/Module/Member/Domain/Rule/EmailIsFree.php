<?php

namespace Walnut\Module\Member\Domain\Rule;

use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Rejection\DuplicateEmail;
use Walnut\Module\Member\Domain\Service\EmailChecker;

final readonly class EmailIsFree {
	public function __construct(
		private EmailChecker $emailChecker
	) {}

	public function __invoke(EmailAddress $emailAddress): void {
		$this->emailChecker->emailIsFree($emailAddress) ||
			DuplicateEmail::for($emailAddress);
	}
}