<?php

namespace Walnut\Module\Member\Domain\Rule;

use Walnut\Module\Member\Domain\Model\Username;
use Walnut\Module\Member\Domain\Rejection\DuplicateUsername;
use Walnut\Module\Member\Domain\Service\UsernameChecker;

final readonly class UsernameIsFree {
	public function __construct(
		private UsernameChecker $usernameChecker
	) {}

	public function __invoke(Username $username): void {
		$this->usernameChecker->usernameIsFree($username) ||
			DuplicateUsername::for($username);
	}
}