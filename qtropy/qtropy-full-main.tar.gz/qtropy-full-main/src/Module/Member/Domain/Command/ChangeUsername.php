<?php

namespace Walnut\Module\Member\Domain\Command;

use Walnut\Module\Member\Domain\Event\UsernameChanged;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\Username;
use Walnut\Module\Member\Domain\Rule\UsernameIsFree;

final readonly class ChangeUsername {
	public function __construct(
		private UsernameIsFree $usernameIsFree
	) {}

	public function __invoke(
		Member $member,
		Username $username
	): UsernameChanged {
		($this->usernameIsFree)($username);
		return new UsernameChanged(
			$member->withNewUsername($username),
			$member
		);
	}
}