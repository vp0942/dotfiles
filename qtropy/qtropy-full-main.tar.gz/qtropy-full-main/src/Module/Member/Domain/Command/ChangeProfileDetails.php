<?php

namespace Walnut\Module\Member\Domain\Command;

use Walnut\Module\Member\Domain\Event\ProfileDetailsChanged;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\ProfileDetails;

final readonly class ChangeProfileDetails {
	public function __invoke(
		Member $member,
		ProfileDetails $profileDetails
	): ProfileDetailsChanged {
		return new ProfileDetailsChanged(
			$member->withNewProfileDetails($profileDetails),
			$member
		);
	}
}