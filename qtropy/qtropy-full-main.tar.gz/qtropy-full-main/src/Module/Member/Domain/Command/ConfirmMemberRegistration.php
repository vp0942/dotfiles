<?php

namespace Walnut\Module\Member\Domain\Command;

use Walnut\Module\Member\Domain\Event\MemberRegistrationConfirmed;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\PasswordHash;
use Walnut\Module\Member\Domain\Rejection\CannotConfirmRegistration;

final class ConfirmMemberRegistration {
	public function __invoke(
		Member $member
	): MemberRegistrationConfirmed {
		$oldHash = $member->passwordHash->value;
		$newHash = str_replace($member->memberId, '', $member->passwordHash->value);
		if ($newHash === $oldHash) {
			CannotConfirmRegistration::for($member->emailAddress);
		}
		return new MemberRegistrationConfirmed(
			$member->withNewPasswordHash(
				new PasswordHash($newHash)
			)
		);
	}

}