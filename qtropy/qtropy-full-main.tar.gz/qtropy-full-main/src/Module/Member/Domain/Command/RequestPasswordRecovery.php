<?php

namespace Walnut\Module\Member\Domain\Command;

use Walnut\Module\Member\Domain\Event\PasswordRecoveryRequested;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Service\PasswordHasher;

final readonly class RequestPasswordRecovery {
	public function __construct(
		private PasswordHasher $passwordHasher
	) {}

	public function __invoke(Member $member): PasswordRecoveryRequested {
		$token = $this->passwordHasher->hashPassword(new Password($member->passwordHash->value));
		return PasswordRecoveryRequested::for($member, $token->value);
	}
}