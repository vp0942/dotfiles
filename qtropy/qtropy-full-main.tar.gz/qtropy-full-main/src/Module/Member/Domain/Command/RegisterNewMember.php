<?php

namespace Walnut\Module\Member\Domain\Command;

use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGenerator;
use Walnut\Module\Member\Domain\Event\MemberRegistered;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\PasswordHash;
use Walnut\Module\Member\Domain\Model\ProfileDetails;
use Walnut\Module\Member\Domain\Model\Username;
use Walnut\Module\Member\Domain\Rule\EmailIsFree;
use Walnut\Module\Member\Domain\Rule\UsernameIsFree;

final readonly class RegisterNewMember {
	public function __construct(
		#[WriteModel(Member::class)]
		private WriteModelIdentityGenerator $memberIdGenerator,
		private EmailIsFree                 $emailIsFree,
		private UsernameIsFree              $usernameIsFree
	) {}

	public function __invoke(
		EmailAddress $emailAddress,
		Username $username,
		PasswordHash $passwordHash,
		ProfileDetails $profileDetails,
		bool $activateUser
	): MemberRegistered {
		($this->usernameIsFree)($username);
		($this->emailIsFree)($emailAddress);
		return new MemberRegistered(
			new Member(
				$memberId = $this->memberIdGenerator->generateIdentity(),
				$emailAddress,
				$username,
				$activateUser ? $passwordHash : new PasswordHash(
					$memberId->value->stringValue . $passwordHash->value
				),
				$profileDetails
			)
		);
	}
}