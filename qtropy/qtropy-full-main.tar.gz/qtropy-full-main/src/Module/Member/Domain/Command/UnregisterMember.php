<?php

namespace Walnut\Module\Member\Domain\Command;

use Walnut\Module\Member\Domain\Event\MemberUnregistered;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class UnregisterMember {
	public function __invoke(
		Member $member
	): MemberUnregistered {
		return new MemberUnregistered($member);
	}
}