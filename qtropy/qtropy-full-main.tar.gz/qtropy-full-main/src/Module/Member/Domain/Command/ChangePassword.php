<?php

namespace Walnut\Module\Account\Domain\Command\Login;

use Walnut\Module\Account\Domain\Event\PasswordChanged;
use Walnut\Module\Account\Domain\Model\Account;
use Walnut\Module\Account\Domain\Model\AccountCredentials;
use Walnut\Module\Account\Domain\Model\AccountPasswordHash;
use Walnut\Module\Account\Domain\Rejection\CannotChangePassword;
use Walnut\Module\Account\Domain\Service\PasswordChecker;
use Walnut\Module\Account\Domain\Service\PasswordHasher;

final class ChangePassword {
	public function __construct(
		private readonly PasswordChecker $passwordChecker,
		private readonly PasswordHasher $passwordHasher
	) {}

	public function __invoke(Account $account, string $newPassword, string $passwordRecoveryToken): PasswordChanged {
		if (!$this->passwordChecker->checkPassword(
			$account->credentials->passwordHash,
			$passwordRecoveryToken
		)) {
			CannotChangePassword::becauseTheTokenIsNotValid();
		}
		return new PasswordChanged(
			$account->withNewCredentials(
				new AccountCredentials(
					$account->credentials->email,
					new AccountPasswordHash(
						$this->passwordHasher->hashPassword($newPassword)
					)
				)
			)
		);
	}
}