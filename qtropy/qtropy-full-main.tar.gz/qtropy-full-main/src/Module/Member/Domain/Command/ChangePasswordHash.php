<?php

namespace Walnut\Module\Member\Domain\Command;

use Walnut\Module\Member\Domain\Event\PasswordHashChanged;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\PasswordHash;
use Walnut\Module\Member\Domain\Rejection\CannotChangePassword;

final readonly class ChangePasswordHash {
	public function __invoke(
		Member $member,
		PasswordHash $passwordHash,
	): PasswordHashChanged {
		return new PasswordHashChanged(
			$member->withNewPasswordHash($passwordHash),
			$member
		);
	}
}