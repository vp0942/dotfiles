<?php

namespace Walnut\Module\Member\Domain\Command;

use Walnut\Module\Member\Domain\Event\EmailChanged;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Rule\EmailIsFree;

final readonly class ChangeEmail {
	public function __construct(
		private EmailIsFree $emailIsFree
	) {}

	public function __invoke(
		Member $member,
		EmailAddress $emailAddress
	): EmailChanged {
		($this->emailIsFree)($emailAddress);
		return new EmailChanged(
			$member->withNewEmailAddress($emailAddress),
			$member
		);
	}
}