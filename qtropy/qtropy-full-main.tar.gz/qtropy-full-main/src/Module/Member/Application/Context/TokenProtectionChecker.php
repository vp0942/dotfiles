<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Model\PasswordHash;
use Walnut\Module\Member\Domain\Rejection\CannotChangePassword;
use Walnut\Module\Member\Domain\Service\PasswordChecker;

final readonly class TokenProtectionChecker {
	public function __construct(
		private PasswordChecker $passwordChecker
	) {}

	public function __invoke(
		Member $member,
		string|null $tokenProtection
	): void {
		if ($tokenProtection !== null && !$this->passwordChecker->checkPassword(
			new Password($member->passwordHash->value),
			new PasswordHash(base64_decode($tokenProtection))
		)) {
			CannotChangePassword::for($member->emailAddress);
		}
	}
}