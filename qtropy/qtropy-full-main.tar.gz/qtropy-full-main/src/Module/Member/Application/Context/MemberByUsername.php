<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\Username;

interface MemberByUsername {
	public function __invoke(Username $username): Member;
}