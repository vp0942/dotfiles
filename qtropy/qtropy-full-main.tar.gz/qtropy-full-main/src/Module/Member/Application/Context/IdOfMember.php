<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class IdOfMember {
	public function __invoke(Member $member): MemberId {
		return $member->memberId;
	}
}