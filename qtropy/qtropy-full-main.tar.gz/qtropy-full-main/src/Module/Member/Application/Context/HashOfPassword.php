<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Model\PasswordHash;
use Walnut\Module\Member\Domain\Service\PasswordHasher;

final readonly class HashOfPassword {
	public function __construct(
		private PasswordHasher $passwordHasher,
	) {}

	public function __invoke(Password $password): PasswordHash {
		return $this->passwordHasher->hashPassword($password);
	}
}