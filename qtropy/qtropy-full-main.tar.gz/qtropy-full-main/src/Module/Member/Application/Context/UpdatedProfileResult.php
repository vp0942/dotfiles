<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Member\Domain\Event\EmailChanged;
use Walnut\Module\Member\Domain\Event\PasswordHashChanged;
use Walnut\Module\Member\Domain\Event\ProfileDetailsChanged;
use Walnut\Module\Member\Domain\Event\UsernameChanged;

final readonly class UpdatedProfileResult {
	public function __construct(
		private _Members $members
	) {}

	public function __invoke(UsernameChanged|EmailChanged|PasswordHashChanged|ProfileDetailsChanged $event): _MemberProfile {
		return $this->members->member($event->member->memberId)->profile();
	}
}