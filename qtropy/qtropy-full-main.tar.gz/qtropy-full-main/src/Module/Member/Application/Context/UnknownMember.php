<?php

namespace Walnut\Module\Member\Application\Context;

use InvalidArgumentException;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Username;

final class UnknownMember extends InvalidArgumentException {
	private const unknownId = "Member with ID '%s' cannot be found";
	public static function withId(MemberId $memberId): never {
		throw new self(sprintf(self::unknownId, (string)$memberId));
	}

	private const unknownUsername = "Member with Username '%s' cannot be found";
	public static function withUsername(Username $username): never {
		throw new self(sprintf(self::unknownUsername, (string)$username));
	}

	private const unknownEmail = "Member with Email '%s' cannot be found";
	public static function withEmail(EmailAddress $emailAddress): never {
		throw new self(sprintf(self::unknownEmail, (string)$emailAddress));
	}
}