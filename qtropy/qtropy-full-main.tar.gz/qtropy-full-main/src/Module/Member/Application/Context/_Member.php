<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\Reference;
use Walnut\Module\Content\Application\Context\_MemberContent;
use Walnut\Module\Feed\Application\Context\_MemberFeed;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Member\Domain\Command\UnregisterMember;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Messaging\Application\Context\_MemberMessaging;
use Walnut\Module\Notification\Application\Context\_MemberNotifications;
use Walnut\Module\Qtropy\Application\Context\ContactQtropy;
use Walnut\Module\Qtropy\Application\Model\ContactMessageData;
use Walnut\Module\Social\Application\Context\_MemberSocial;

#[DataContext(Member::class)]
interface _Member {
	#[Reference(_MemberContent::class, new ParameterList(
		new ContextParameter
	))]
	public function content(): _MemberContent;

	#[Reference(_MemberProfile::class, new ParameterList(
		new ContextParameter
	))]
	public function profile(): _MemberProfile;

	#[Reference(_MemberFeed::class, new ParameterList(
		new ContextParameter
	))]
	public function feed(): _MemberFeed;

	#[Reference(_MemberSocial::class, new ParameterList(
		new ContextParameter
	))]
	public function social(): _MemberSocial;

	#[Reference(_MemberMessaging::class, new ParameterList(
		new ContextParameter
	))]
	public function messaging(): _MemberMessaging;

	#[Reference(_MemberNotifications::class, new ParameterList(
		new ContextParameter
	))]
	public function notifications(): _MemberNotifications;

	#[DomainCommand(UnregisterMember::class, new ParameterList(
		new ContextParameter,
	))]
	public function unregister(): void;

	#[DomainCommand(ContactQtropy::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('messageData')
	))]
	public function contactQtropy(ContactMessageData $messageData): void;

	#[DataQuery(IdOfMember::class, new ParameterList(
		new ContextParameter
	))]
	public function memberId(): MemberId;

}