<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Member\Domain\Event\MemberRegistered;

final readonly class NewMemberResult {
	public function __construct(
		private _Members $members
	) {}

	public function __invoke(MemberRegistered $event): _Member {
		return $this->members->member($event->member->memberId);
	}

}