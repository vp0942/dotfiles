<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class MemberById {
	public function __construct(
		#[WriteModel(Member::class)]
		private WriteModelRepository $repository
	) {}

	public function __invoke(MemberId $memberId): Member {
		return $this->repository->byId($memberId) ??
			UnknownMember::withId($memberId);
	}
}