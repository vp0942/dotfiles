<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Member;

interface MemberByEmail {
	public function __invoke(EmailAddress $emailAddress): Member;
}