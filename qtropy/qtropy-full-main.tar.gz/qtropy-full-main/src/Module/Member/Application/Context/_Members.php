<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterBuilder;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\Reference;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\ReturnValueBuilder;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Member\Domain\Command\RegisterNewMember;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Model\ProfileDetails;
use Walnut\Module\Member\Domain\Model\Username;

interface _Members {
	#[Reference(_Member::class, new ParameterList(
		new ParameterBuilder(
			MemberById::class,
			new ParameterList(
				new FunctionParameter('memberId')
			)
		)
	))]
	public function member(MemberId $memberId): _Member;

	#[Reference(_Member::class, new ParameterList(
		new ParameterBuilder(
			MemberByUsername::class,
			new ParameterList(
				new FunctionParameter('username')
			)
		)
	))]
	public function memberByUsername(Username $username): _Member;

	#[Reference(_Member::class, new ParameterList(
		new ParameterBuilder(
			MemberByEmail::class,
			new ParameterList(
				new FunctionParameter('emailAddress')
			)
		)
	))]
	public function memberByEmail(EmailAddress $emailAddress): _Member;

	#[DomainCommand(RegisterNewMember::class, new ParameterList(
		new FunctionParameter('emailAddress'),
		new FunctionParameter('username'),
		new ParameterBuilder(
			HashOfPassword::class, new ParameterList(
				new FunctionParameter('password'),
			)
		),
		new FunctionParameter('profileDetails'),
		new FunctionParameter('activateUser'),
	)), ReturnValueBuilder(NewMemberResult::class, new ParameterList)]
	public function register(
		EmailAddress $emailAddress,
		Username $username,
		Password $password,
		ProfileDetails $profileDetails,
		bool $activateUser
	): _Member;

}