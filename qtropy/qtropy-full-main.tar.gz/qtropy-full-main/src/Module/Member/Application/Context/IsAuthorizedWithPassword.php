<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Service\PasswordChecker;

final readonly class IsAuthorizedWithPassword {
	public function __construct(
		private PasswordChecker $passwordChecker
	) {}

	public function __invoke(Member $member, Password $password): bool {
		return $this->passwordChecker->checkPassword($password, $member->passwordHash);
	}
}