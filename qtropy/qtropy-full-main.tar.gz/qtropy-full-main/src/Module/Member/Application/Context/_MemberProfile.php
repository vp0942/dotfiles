<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Lib\FluentDomain\Attribute\DataContext;
use Walnut\Lib\FluentDomain\Attribute\DataQuery;
use Walnut\Lib\FluentDomain\Attribute\DomainCommand;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ContextParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\FunctionParameter;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterBuilder;
use Walnut\Lib\FluentDomain\Attribute\Parameter\ParameterList;
use Walnut\Lib\FluentDomain\Attribute\ReturnValue\ReturnValueBuilder;
use Walnut\Module\Member\Application\Query\AccountSettings\AccountSettingsData;
use Walnut\Module\Member\Application\Query\AccountSettings\AccountSettingsQuery;
use Walnut\Module\Member\Domain\Command\ChangeEmail;
use Walnut\Module\Member\Domain\Command\ChangePasswordHash;
use Walnut\Module\Member\Domain\Command\ChangeProfileDetails;
use Walnut\Module\Member\Domain\Command\ChangeUsername;
use Walnut\Module\Member\Domain\Command\ConfirmMemberRegistration;
use Walnut\Module\Member\Domain\Command\RequestPasswordRecovery;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\Password;
use Walnut\Module\Member\Domain\Model\ProfileDetails;
use Walnut\Module\Member\Domain\Model\Username;

#[DataContext(Member::class)]
interface _MemberProfile {
	#[DomainCommand(ChangeUsername::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('newUsername')
	)), ReturnValueBuilder(UpdatedProfileResult::class)]
	public function withNewUsername(Username $newUsername): _MemberProfile;

	#[DomainCommand(ChangeEmail::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('newEmailAddress')
	)), ReturnValueBuilder(UpdatedProfileResult::class)]
	public function withNewEmailAddress(EmailAddress $newEmailAddress): _MemberProfile;

	#[DomainCommand(ChangePasswordHash::class, new ParameterList(
		new ContextParameter,
		new ParameterBuilder(
			HashOfPassword::class,
			new ParameterList(
				new FunctionParameter('newPassword'),
			)
		),
		new ParameterBuilder(
			TokenProtectionChecker::class,
			new ParameterList(
				new ContextParameter,
				new FunctionParameter('tokenProtection'),
			)
		),
	)), ReturnValueBuilder(UpdatedProfileResult::class)]
	public function withNewPassword(Password $newPassword, string|null $tokenProtection): _MemberProfile;

	#[DomainCommand(ConfirmMemberRegistration::class, new ParameterList(
		new ContextParameter,
	))]
	public function confirmRegistration(): void;

	#[DomainCommand(RequestPasswordRecovery::class)]
	public function passwordRecoveryRequest(): void;

	#[DomainCommand(ChangeProfileDetails::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('newProfileDetails')
	)), ReturnValueBuilder(UpdatedProfileResult::class)]
	public function withNewProfileDetails(ProfileDetails $newProfileDetails): _MemberProfile;


	#[DataQuery(AccountSettingsQuery::class, new ParameterList(
		new ContextParameter,
	))]
	public function accountSettings(): AccountSettingsData;

	#[DataQuery(IsAuthorizedWithPassword::class, new ParameterList(
		new ContextParameter,
		new FunctionParameter('password'),
	))]
	public function isAuthorizedWithPassword(Password $password): bool;
}