<?php

namespace Walnut\Module\Member\Application\Context;

use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Member\Domain\Model\EmailAddress;
use Walnut\Module\Member\Domain\Model\Member;
use Walnut\Module\Member\Domain\Model\NotificationAlerts;
use Walnut\Module\Member\Domain\Model\PasswordHash;
use Walnut\Module\Member\Domain\Model\ProfileDetails;
use Walnut\Module\Member\Domain\Model\Username;

final readonly class AnonymousMember {
	public function __invoke(): Member {
		return new Member(
			new MemberId(Uuid::zeroUuid()),
			new EmailAddress('contact@qtropy.com'),
			new Username("qtropy"),
			new PasswordHash("password"),
			new ProfileDetails(
				'',
				'',
				NotificationAlerts::fromBitmask(0),
				''
			),
		);
	}
}