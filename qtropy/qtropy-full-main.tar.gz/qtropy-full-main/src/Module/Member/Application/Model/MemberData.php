<?php

namespace Walnut\Module\Member\Application\Model;

final readonly class MemberData {
	public function __construct(
		public string      $memberId,
		public string      $username,
		public string|null $profilePicture,
		public string|null $profileDescription,
	) {}
}