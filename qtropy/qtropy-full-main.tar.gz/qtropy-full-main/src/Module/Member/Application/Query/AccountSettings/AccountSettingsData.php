<?php

namespace Walnut\Module\Member\Application\Query\AccountSettings;

use Walnut\Module\Member\Domain\Model\NotificationAlerts;

final readonly class AccountSettingsData {
	public function __construct(
		public string             $memberId,
		public string             $username,
		public string             $emailAddress,
		public string             $profileDescription,
		public string             $profilePicture,
		public string             $theme,
		public NotificationAlerts $notificationAlerts,
	) {}
}