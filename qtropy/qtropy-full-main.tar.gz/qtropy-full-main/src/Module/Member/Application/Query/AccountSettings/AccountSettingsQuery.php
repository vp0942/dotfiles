<?php

namespace Walnut\Module\Member\Application\Query\AccountSettings;

use Walnut\Module\Member\Domain\Model\Member;

interface AccountSettingsQuery {
	public function __invoke(Member $member): AccountSettingsData;
}