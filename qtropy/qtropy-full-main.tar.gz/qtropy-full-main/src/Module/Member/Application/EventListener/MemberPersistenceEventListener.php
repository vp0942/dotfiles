<?php

namespace Walnut\Module\Member\Application\EventListener;

use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Member\Domain\Event\EmailChanged;
use Walnut\Module\Member\Domain\Event\MemberRegistered;
use Walnut\Module\Member\Domain\Event\MemberRegistrationConfirmed;
use Walnut\Module\Member\Domain\Event\MemberUnregistered;
use Walnut\Module\Member\Domain\Event\PasswordHashChanged;
use Walnut\Module\Member\Domain\Event\ProfileDetailsChanged;
use Walnut\Module\Member\Domain\Event\UsernameChanged;
use Walnut\Module\Member\Domain\Model\Member;

#[AutoEventListener]
final readonly class MemberPersistenceEventListener {

	public function __construct(
		#[WriteModel(Member::class)]
		private WriteModelRepository $writeModelRepository
	) {}

	public function onMemberRegisteredOrUpdated(MemberRegistered|MemberRegistrationConfirmed|UsernameChanged|EmailChanged|PasswordHashChanged|ProfileDetailsChanged $event): void {
		$this->writeModelRepository->store($event->member);
	}

	public function onMemberUnregistered(MemberUnregistered $event): void {
		$this->writeModelRepository->removeById($event->member->memberId);
	}

}