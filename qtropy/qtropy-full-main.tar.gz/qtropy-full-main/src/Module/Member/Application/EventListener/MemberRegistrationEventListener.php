<?php
/** @noinspection PhpUnused */

namespace Walnut\Module\Member\Application\EventListener;

use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\Mailbox\Mailbox;
use Walnut\Lib\Mailbox\Message;
use Walnut\Lib\Mailbox\Recipient;
use Walnut\Module\Member\Domain\Event\MemberRegistered;
use Walnut\Module\Member\Domain\Event\PasswordRecoveryRequested;

#[AutoEventListener]
final readonly class MemberRegistrationEventListener {

	public function __construct(
		private string  $webRoot,
		private string  $registrationConfirmationUrl,
		private Mailbox $mailbox
	) {}

	public function onMemberRegistered(MemberRegistered $event): void {
		$base = $this->webRoot;
		$link = sprintf("%s%s/%s",
			$base,
			$this->registrationConfirmationUrl,
			$event->member->memberId->value->stringValue
		);
		$this->mailbox->send(
			Message::create(
				"Member Registration Confirmation (Qtropy)",
				nl2br(<<<MAIL
				Please click on this link to confirm your Qtropy registration: <a href="$link">$link</a>
				MAIL),
				[],
				new Recipient('noreply@qtropy.com', 'Qtropy'),
				new Recipient('noreply@qtropy.com', 'Qtropy')
			)->toRecipient(new Recipient(
				$event->member->emailAddress->value,
				$event->member->username->value
			))
		);
	}

}