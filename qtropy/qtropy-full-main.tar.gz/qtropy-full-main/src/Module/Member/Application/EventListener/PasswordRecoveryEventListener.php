<?php
/** @noinspection PhpUnused */

namespace Walnut\Module\Member\Application\EventListener;

use Walnut\Lib\EventBus\AutoEventListener;
use Walnut\Lib\Mailbox\Mailbox;
use Walnut\Lib\Mailbox\Message;
use Walnut\Lib\Mailbox\Recipient;
use Walnut\Module\Member\Domain\Event\PasswordRecoveryRequested;

#[AutoEventListener]
final readonly class PasswordRecoveryEventListener {

	public function __construct(
		private string  $webRoot,
		private string  $passwordRecoveryUrl,
		private Mailbox $mailbox
	) {}

	public function onPasswordRecoveryRequested(PasswordRecoveryRequested $event): void {
		$base = $this->webRoot;
		$link = sprintf("%s%s/%s?email=%s",
			$base,
			$this->passwordRecoveryUrl,
			base64_encode($event->token),
			$event->member->emailAddress->value
		);
		$this->mailbox->send(
			Message::create(
				"Password Reset Link (Qtropy)",
				nl2br(<<<MAIL
				A password reset was requested. If you did not make this request then simply disregard this email.
				
				You can follow this link to change your password: <a href="$link">$link</a>
				MAIL),
				[],
				new Recipient('noreply@qtropy.com', 'Qtropy'),
				new Recipient('noreply@qtropy.com', 'Qtropy')
			)->toRecipient(new Recipient(
				$event->member->emailAddress->value,
				$event->member->username->value
			))
		);
	}

}