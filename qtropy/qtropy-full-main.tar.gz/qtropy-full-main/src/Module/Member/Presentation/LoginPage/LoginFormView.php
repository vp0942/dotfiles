<?php

namespace Walnut\Module\Member\Presentation\LoginPage;

final readonly class LoginFormView {
	public function __construct(
		public string|null $username,
		public string      $basePath,
		public string      $redirectUrl,
		public string      $registerUrl,
		public string      $forgotPasswordUrl,
		public string      $serviceUrl,
		public string      $tokenName,
	) {}
}