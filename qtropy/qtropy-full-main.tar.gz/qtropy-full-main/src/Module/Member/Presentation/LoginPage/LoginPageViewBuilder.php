<?php

namespace Walnut\Module\Member\Presentation\LoginPage;

final readonly class LoginPageViewBuilder {
	public function __construct(
		private string $basePath,
		private string $registerUrl,
		private string $forgotPasswordUrl,
		private string $serviceUrl,
		private string $tokenName,
	) {}

	public function view(string|null $username, string|null $redirectUrl): LoginFormView {
		return new LoginFormView(
			$username,
			$this->basePath,
			$redirectUrl ?? '/',
			$this->registerUrl,
			$this->forgotPasswordUrl,
			$this->serviceUrl,
			$this->tokenName,
		);
	}
}