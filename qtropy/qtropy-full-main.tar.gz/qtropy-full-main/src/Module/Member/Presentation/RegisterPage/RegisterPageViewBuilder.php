<?php

namespace Walnut\Module\Member\Presentation\RegisterPage;

final readonly class RegisterPageViewBuilder {
	public function __construct(
		private string $basePath,
		private string $loginUrl,
		private string $registerUrl,
		private string $forgotPasswordUrl,
		private string $serviceUrl,
		private string $serviceTokenUrl,
		private string $tokenName,
	) {}

	public function view(string|null $email, string|null $redirectUrl): RegisterFormView {
		return new RegisterFormView(
			$email,
			$this->basePath,
			$redirectUrl ?? '/',
			$this->loginUrl,
			$this->registerUrl,
			$this->forgotPasswordUrl,
			$this->serviceUrl,
			$this->serviceTokenUrl,
			$this->tokenName,
		);
	}

	public function confirmationView(string $email, bool $isSuccessful): RegisterConfirmationView {
		return new RegisterConfirmationView(
			$email,
			$isSuccessful,
			$this->basePath,
			'/',
			$this->loginUrl,
			$this->registerUrl,
			$this->forgotPasswordUrl,
			$this->serviceUrl,
			$this->serviceTokenUrl,
			$this->tokenName,
		);
	}
}