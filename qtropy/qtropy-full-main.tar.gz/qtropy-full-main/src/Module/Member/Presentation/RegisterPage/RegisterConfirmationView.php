<?php

namespace Walnut\Module\Member\Presentation\RegisterPage;

final readonly class RegisterConfirmationView {
	public function __construct(
		public string $email,
		public bool $isSuccessful,
		public string      $basePath,
		public string      $redirectUrl,
		public string      $loginUrl,
		public string      $registerUrl,
		public string      $forgotPasswordUrl,
		public string      $serviceUrl,
		public string      $serviceTokenUrl,
		public string      $tokenName,
	) {}
}