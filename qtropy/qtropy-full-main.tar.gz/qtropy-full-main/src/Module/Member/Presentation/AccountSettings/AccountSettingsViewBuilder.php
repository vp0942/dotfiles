<?php

namespace Walnut\Module\Member\Presentation\AccountSettings;

use Walnut\Module\Member\Application\Context\_MemberProfile;

final readonly class AccountSettingsViewBuilder {

	/** @param array<string, string> $labels */
	public function __construct(
		private _MemberProfile $memberProfile,
		private string         $pageTitle,
		private array          $labels,
	) {}

	public function view(): AccountSettingsView {
		return new AccountSettingsView(
			$this->pageTitle,
			$this->labels,
			$this->memberProfile->accountSettings()
		);
	}
}