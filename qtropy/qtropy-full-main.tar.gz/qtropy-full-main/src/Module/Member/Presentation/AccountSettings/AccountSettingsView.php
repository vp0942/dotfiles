<?php

namespace Walnut\Module\Member\Presentation\AccountSettings;

use Walnut\Module\Member\Application\Query\AccountSettings\AccountSettingsData;

final readonly class AccountSettingsView {

	/** @param array<string, string> $labels */
	public function __construct(
		public string              $pageTitle,
		public array               $labels,
		public AccountSettingsData $accountSettingsData
	) {}
}