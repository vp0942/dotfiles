<?php

namespace Walnut\Module\Member\Presentation\PasswordRecoveryPage;

final readonly class PasswordRecoveryFormView {
	public function __construct(
		public string|null $email,
		public string      $basePath,
		public string      $redirectUrl,
		public string      $loginUrl,
		public string      $registerUrl,
		public string      $forgotPasswordUrl,
		public string      $serviceUrl,
		public string      $tokenName,
	) {}
}