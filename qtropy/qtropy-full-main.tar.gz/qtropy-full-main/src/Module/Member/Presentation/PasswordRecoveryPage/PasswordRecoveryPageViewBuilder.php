<?php

namespace Walnut\Module\Member\Presentation\PasswordRecoveryPage;

final readonly class PasswordRecoveryPageViewBuilder {
	public function __construct(
		private string $basePath,
		private string $loginUrl,
		private string $registerUrl,
		private string $forgotPasswordUrl,
		private string $recoveryServiceUrl,
		private string $changeServiceUrl,
		private string $tokenName,
	) {}

	public function passwordRecoveryPageView(string|null $email): PasswordRecoveryFormView {
		return new PasswordRecoveryFormView(
			$email,
			$this->basePath,
			$redirectUrl ?? '/',
			$this->loginUrl,
			$this->registerUrl,
			$this->forgotPasswordUrl,
			$this->recoveryServiceUrl,
			$this->tokenName,
		);
	}

	public function passwordChangePageView(string $token, string|null $email): PasswordChangeFormView {
		return new PasswordChangeFormView(
			$token,
			$email,
			$this->basePath,
			$redirectUrl ?? '/',
			$this->loginUrl,
			$this->registerUrl,
			$this->forgotPasswordUrl,
			$this->changeServiceUrl,
			$this->tokenName,
		);
	}
}