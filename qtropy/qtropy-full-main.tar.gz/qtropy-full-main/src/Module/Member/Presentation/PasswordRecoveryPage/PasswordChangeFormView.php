<?php

namespace Walnut\Module\Member\Presentation\PasswordRecoveryPage;

final readonly class PasswordChangeFormView {
	public function __construct(
		public string $token,
		public string $email,
		public string      $basePath,
		public string      $redirectUrl,
		public string      $loginUrl,
		public string      $registerUrl,
		public string      $forgotPasswordUrl,
		public string      $serviceUrl,
		public string      $tokenName,
	) {}
}