<?php

namespace Walnut\Module\Kernel\Time;

interface SystemTime {
	public function now(): DateAndTime;
}