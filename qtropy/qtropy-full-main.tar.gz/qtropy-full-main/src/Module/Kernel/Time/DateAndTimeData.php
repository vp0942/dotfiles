<?php

namespace Walnut\Module\Kernel\Time;

use Attribute;
use Walnut\Lib\DataType\DirectValue;
use Walnut\Lib\DataType\Exception\InvalidValueType;

#[Attribute]
final readonly class DateAndTimeData implements DirectValue {
	public function __construct(
		public bool $nullable = false,
	) {}

	public function importValue(float|object|int|bool|array|string|null $value): DateAndTime {
		if (!is_string($value) && !($value === null && $this->nullable)) {
			throw new InvalidValueType('string', gettype($value));
		}
		return new DateAndTime((string)$value);
	}
}