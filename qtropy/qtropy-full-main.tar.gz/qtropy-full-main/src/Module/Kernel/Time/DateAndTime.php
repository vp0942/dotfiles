<?php

namespace Walnut\Module\Kernel\Time;

use DateTimeImmutable;
use JsonSerializable;

/**
 * @psalm-immutable
 */
#[DateAndTimeData]
final class DateAndTime extends DateTimeImmutable implements JsonSerializable {

	public function jsonSerialize(): string {
		return $this->format('Y-m-d H:i:s');
	}
	
}