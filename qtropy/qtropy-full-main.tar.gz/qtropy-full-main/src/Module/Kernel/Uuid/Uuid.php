<?php

namespace Walnut\Module\Kernel\Uuid;

use JsonSerializable;

#[UuidData]
final readonly class Uuid implements JsonSerializable {
	public const UUID_PATTERN = '/^[\da-f]{8}-[\da-f]{4}-4[\da-f]{3}-[89ab][\da-f]{3}-[\da-f]{12}$/iD';
	public const ZERO_UUID = '00000000-0000-4000-8000-000000000000';

	private function __construct(
		public readonly string $stringValue,
		public readonly string $binaryValue
	) {}

	public static function zeroUuid(): self {
		return self::fromString(self::ZERO_UUID);
	}

	/**
	 * @throws InvalidUuid
	 */
	public static function fromString(string $stringValue): self {
		if (!preg_match(self::UUID_PATTERN, $stringValue)) {
			throw new InvalidUuid($stringValue);
		}
		return new Uuid(
			$stringValue,
			self::stringToBinary($stringValue)
		);
	}

	/**
	 * @throws InvalidUuid
	 */
	public static function fromBinary(string $binaryValue): self {
		$stringValue = self::binaryToString($binaryValue);
		if (!preg_match(self::UUID_PATTERN, $stringValue)) {
			throw new InvalidUuid($stringValue);
		}
		return new Uuid(
			$stringValue,
			$binaryValue
		);
	}

	public static function stringToBinary(string $stringValue): string {
		return (string)hex2bin(str_replace('-', '', $stringValue));
	}

	public static function binaryToString(string $binaryValue): string {
		$hexValue = bin2hex($binaryValue);
		return
			substr($hexValue, 0, 8) . '-' .
			substr($hexValue, 8, 4) . '-' .
			substr($hexValue, 12, 4) . '-' .
			substr($hexValue, 16, 4) . '-' .
			substr($hexValue, 20)
		;
	}

	public function jsonSerialize(): string {
		return $this->stringValue;
	}
}