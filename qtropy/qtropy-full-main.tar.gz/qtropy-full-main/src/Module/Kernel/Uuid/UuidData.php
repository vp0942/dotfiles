<?php

namespace Walnut\Module\Kernel\Uuid;

use Attribute;
use Walnut\Lib\DataType\DirectValue;
use Walnut\Lib\DataType\Exception\InvalidValueType;
use Walnut\Lib\DataType\Exception\StringType\StringIncorrectlyFormatted;

#[Attribute]
final readonly class UuidData implements DirectValue {
	public function __construct(
		public bool $nullable = false,
	) {}

	public function importValue(float|object|int|bool|array|string|null $value): Uuid {
		if (!is_string($value) && !($value === null && $this->nullable)) {
			throw new InvalidValueType('string', gettype($value));
		}
		$value = (string)$value;
		$fromBinaryValue = Uuid::binaryToString($value);
		if (preg_match(Uuid::UUID_PATTERN, $value)) {
			return Uuid::fromString($value);
		}
		if (preg_match(Uuid::UUID_PATTERN, $fromBinaryValue)) {
			return Uuid::fromBinary($value);
		}
		throw new StringIncorrectlyFormatted(Uuid::UUID_PATTERN, $value);
	}
}