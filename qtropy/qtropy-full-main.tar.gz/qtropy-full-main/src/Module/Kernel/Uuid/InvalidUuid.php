<?php

namespace Walnut\Module\Kernel\Uuid;

use Walnut\Module\Kernel\Exception\ProcessException;

final class InvalidUuid extends ProcessException {
	public const ERROR_MESSAGE = "Invalid UUID: %s";

	public function __construct(
		public readonly string $value
	) {
		parent::__construct(
			sprintf(self::ERROR_MESSAGE, $value)
		);
	}

}