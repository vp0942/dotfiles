<?php

namespace Walnut\Module\Kernel\Exception;

use RuntimeException;
use JsonSerializable;

class ProcessException extends RuntimeException implements JsonSerializable {

	public function jsonSerialize(): string {
		return $this->getMessage();
	}
	
}