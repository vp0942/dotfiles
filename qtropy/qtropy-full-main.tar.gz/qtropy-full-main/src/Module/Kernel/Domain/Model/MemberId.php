<?php

namespace Walnut\Module\Kernel\Domain\Model;

use JsonSerializable;
use Walnut\Lib\DataType\WrapperData;
use Walnut\Module\Kernel\Uuid\Uuid;

#[WrapperData]
final readonly class MemberId implements JsonSerializable {
	public function __construct(
		public Uuid $value
	) {}

	public function __toString(): string {
		return $this->value->stringValue;
	}

	public function jsonSerialize(): string {
		return $this->value->stringValue;
	}
}
