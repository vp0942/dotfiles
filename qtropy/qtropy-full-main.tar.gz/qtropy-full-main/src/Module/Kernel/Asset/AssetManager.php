<?php

namespace Walnut\Module\Kernel\Asset;

interface AssetManager {
	public function storeAsset(string $key, string $content): void;
	public function removeAsset(string $key): void;
	public function retrieveAsset(string $key): string;

	public function moveAssetGroup(string $sourceGroupKey, string $targetGroupKey): void;
}