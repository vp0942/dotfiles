<?php

namespace Walnut\Module\Kernel\Util;

trait Wither {
	private function with(mixed ... $newValues): self {
		return new self(...$newValues + (array)$this);
	}
}