<?php

namespace Walnut\Module\Kernel\Page;

interface PageViewModel {}