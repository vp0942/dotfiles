<?php

namespace Walnut\Module\Kernel\Page;

interface PageViewModelFactory {

	public function page(
		string $pageTitle,
		object $content,
		string $selectedItemId
	): PageViewModel;

}