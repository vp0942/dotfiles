<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Model\TreatiseData;
use Walnut\Module\Feed\Application\Query\ByKey\ContentByKeyQuery;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class DbContentByKeyQuery implements ContentByKeyQuery {
	public function __construct(
		private QueryExecutor      $queryExecutor,
		private ContentDataMapper  $contentDataMapper,
		private DbFeedQueryBuilder $queryBuilder
	) {}

	public function __invoke(
		Member $member,
		ContentKey $contentKey
	): QuestionData|AnswerData|TreatiseData|NoteData|null {
		$row = $this->queryExecutor->execute(
			$this->queryBuilder->build(filter: $this->getSql()), [
				'memberId' => $member->memberId->value->binaryValue,
				'contentKey' => $contentKey->value
			]
		)->first();

		return $row ? $this->contentDataMapper->contentData($row) : null;
	}

	private function getSql(): string {
		return <<<SQL
			c.content_key = :contentKey AND c.content IS NOT NULL AND (
			    c.content_type <= 4 OR 
		        (
		            c.author_member_id = :memberId OR
		            (NOT ISNULL(mca.recommended_by_member_id) AND ISNULL(mca.recommendation_removed_on))
		        )
			)
		SQL;
	}
}