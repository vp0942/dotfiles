<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Feed\Domain\Repository\SavedContentRepository;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class DbSavedContentRepository implements SavedContentRepository {
	private const query = "
		SELECT member_id as memberId
		FROM member_content_activities 
		WHERE content_id = ? AND saved_since IS NOT NULL
	";

	public function __construct(
		private readonly QueryExecutor $queryExecutor,
		#[WriteModel(Member::class)]
		private readonly WriteModelRepository $writeModelRepository,
	) {}

	/** @return Member[] */
	public function allMembersForSavedContent(ContentId $contentId): array {
		$memberIds = array_map(static fn(array $row): MemberId =>
			new MemberId(Uuid::fromBinary($row['memberId'])),
			$this->queryExecutor->execute(self::query, [$contentId->value->binaryValue])->all()
		);
		return $memberIds ? [...$this->writeModelRepository->allById($memberIds)] : [];
	}
}