<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Module\Content\Domain\Model\ContentType;
use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\InfoData;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Model\ContentRelationship;
use Walnut\Module\Feed\Application\Model\PointFrameData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Model\TreatiseData;
use Walnut\Module\Member\Application\Model\MemberData;

final readonly class ContentDataMapper {

	public function pointFrameData(array $row): PointFrameData {
		return new PointFrameData(
			$row['content'] ?? null,
			$row['contentDraft'] ?? null,
			$row['annotations'] ?? null,
			$row['explanationRequests'] ?? null,
			$this->contentData($row)
		);
	}

	public function contentData(array $row): NoteData|TreatiseData|QuestionData|AnswerData {
		return match(ContentType::tryFrom($row['contentType'])) {
			ContentType::question => $this->questionData($row),
			ContentType::answer => $this->answerData($row),
			ContentType::treatise => $this->treatiseData($row),
			ContentType::note => $this->noteData($row),
		};
	}

	public function noteData(array $row): NoteData {
		return new NoteData(
			$row['contentId'],
			$row['contentKey'],
			$row['title'],
			ContentRelationship::tryFrom($row['contentRelationship']),
			(bool)$row['isSaved'],
			(int)$row['recommendedToOthers'],
			new MemberData(
				$row['postedByMemberId'],
				$row['postedByUsername'],
				$row['postedByProfilePicture'],
				$row['postedByProfileDescription'],
			),
			$row['recommendedByMemberId'] ?
				new MemberData(
					$row['recommendedByMemberId'],
					$row['recommendedByUsername'],
					$row['recommendedByProfilePicture'],
					$row['recommendedByProfileDescription'],
				) : null,
            InfoData::fromJson((string)$row['info']),
            InfoData::fromJson((string)$row['infoRevision']),
		);
	}

	public function treatiseData(array $row): TreatiseData {
		return new TreatiseData(
			$row['contentId'],
			$row['contentKey'],
			$row['title'],
			ContentRelationship::tryFrom($row['contentRelationship']),
			(bool)$row['isSaved'],
			new MemberData(
				$row['postedByMemberId'],
				$row['postedByUsername'],
				$row['postedByProfilePicture'],
				$row['postedByProfileDescription'],
			),
            InfoData::fromJson((string)$row['info']),
            InfoData::fromJson((string)$row['infoRevision']),
		);
	}

	public function answerData(array $row): AnswerData {
		$q = [];
		foreach($row as $k => $v) {
			if (str_starts_with($k, 'p_')) {
				$q[substr($k, 2)] = $v;
			}
		}
		return new AnswerData(
			$row['contentId'],
			$row['contentKey'],
			ContentRelationship::tryFrom($row['contentRelationship']),
			(bool)$row['isSaved'],
			new MemberData(
				$row['postedByMemberId'],
				$row['postedByUsername'],
				$row['postedByProfilePicture'],
				$row['postedByProfileDescription']
			),
			$this->questionData($q),
            InfoData::fromJson((string)$row['info']),
            InfoData::fromJson((string)$row['infoRevision']),
		);
	}

	public function questionData(array $row): QuestionData {
		return new QuestionData(
			$row['contentId'],
			$row['contentKey'],
			$row['title'],
			ContentRelationship::tryFrom($row['contentRelationship']),
			(bool)$row['isSaved'],
			new MemberData(
				$row['postedByMemberId'],
				$row['postedByUsername'],
				$row['postedByProfilePicture'],
				$row['postedByProfileDescription']
			),
			(int)$row['answersCount'],
			$row['ownAnswerId'],
			$row['ownAnswerKey'],
			json_decode($row['image'] ?? '') ?: null,
			json_decode($row['audio'] ?? '') ?: null,
		);
	}
}
