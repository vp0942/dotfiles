<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Query\Note\NoteFeedQuery;
use Walnut\Module\Feed\Application\Query\Note\NoteFeedType;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class DbNoteFeedQuery implements NoteFeedQuery {
	public function __construct(
		private QueryExecutor      $queryExecutor,
		private ContentDataMapper  $contentDataMapper,
		private DbFeedQueryBuilder $feedQueryBuilder,
	) {}

	/**
	 * @param NoteFeedType[] $feedTypes
	 * @return NoteData[]
	 */
	public function __invoke(Member $member, array $feedTypes): array {
		$filterSql = $this->getFilterSql($feedTypes);
		return array_map($this->contentDataMapper->noteData(...), $this->queryExecutor->execute(
			$this->feedQueryBuilder->build(
				filter: $filterSql,
				orderBy: $this->getOrderBySql($feedTypes),
			), [
				'memberId' => $member->memberId->value->binaryValue
			]
		)->all());
	}

	/** @param NoteFeedType[] $feedTypes */
	private function getOrderBySql(array $feedTypes): string {
		$defaultOrderBy = "COALESCE(c.last_revision_date, c.date_created) DESC";
		$orderBySql = [
			NoteFeedType::draft->name => $defaultOrderBy,
			NoteFeedType::own->name => $defaultOrderBy,
			NoteFeedType::saved->name => 'mca.saved_since DESC',
			NoteFeedType::recommended->name => 'mca.recommended_on DESC',
			NoteFeedType::recommendedToOthers->name => $defaultOrderBy,
		];
		$seq = [
			NoteFeedType::draft->name => 3,
			NoteFeedType::own->name => 3,
			NoteFeedType::saved->name => 1,
			NoteFeedType::recommended->name => 2,
			NoteFeedType::recommendedToOthers->name => 3,
		];
		$filters = $feedTypes ?: NoteFeedType::cases();
		$result = [];
		foreach($filters as $filter) {
			$result[$seq[$filter->name]] = $orderBySql[$filter->name];
		}
		ksort($result);
		$result = array_unique($result);
		return "ORDER BY " . implode(', ', $result);
	}

	/** @param NoteFeedType[] $feedTypes */
	private function getFilterSql(array $feedTypes): string {
		$filterSql = [
			NoteFeedType::draft->name => '(c.author_member_id = :memberId AND c.content_revision IS NOT NULL)',
			NoteFeedType::own->name => '(c.author_member_id = :memberId AND c.content IS NOT NULL)',
			NoteFeedType::saved->name => '(c.author_member_id <> :memberId AND NOT ISNULL(mca.saved_since))',
			NoteFeedType::recommended->name => '(c.author_member_id <> :memberId AND NOT ISNULL(mca.recommended_by_member_id) AND ISNULL(mca.recommendation_removed_on))',
			NoteFeedType::recommendedToOthers->name => 'COALESCE(rc.recommendedToOthers, 0) > 0',
		];
		$filters = $feedTypes ?: NoteFeedType::cases();
		$result = [];
		foreach($filters as $filter) {
			$result[] = $filterSql[$filter->name];
		}
		return "c.content_type = 4 AND (" . implode(' OR ', $result) . ")";
	}
}