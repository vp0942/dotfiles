<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Query\Question\QuestionFeedQuery;
use Walnut\Module\Feed\Application\Query\Question\QuestionFeedType;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class DbQuestionFeedQuery implements QuestionFeedQuery {
	public function __construct(
		private QueryExecutor      $queryExecutor,
		private ContentDataMapper  $contentDataMapper,
		private DbFeedQueryBuilder $queryBuilder
	) {}

	/**
	 * @param QuestionFeedType[] $feedTypes
	 * @return list<AnswerData|QuestionData>
	 */
	public function __invoke(Member $member, array $feedTypes): array {
		$filterSql = $this->getFilterSql($feedTypes);
		return array_map($this->data(...), $this->queryExecutor->execute(
			$this->queryBuilder->build(
				filter: $filterSql,
				orderBy: $this->getOrderBySql($feedTypes),
			), [
				'memberId' => $member->memberId->value->binaryValue
			]
		)->all());
	}


	/** @param QuestionFeedType[] $feedTypes */
	private function getOrderBySql(array $feedTypes): string {
		$defaultSort = 'COALESCE(c.last_revision_date, c.date_created) DESC';
		$orderBySql = [
			QuestionFeedType::draft->name       => $defaultSort,
			QuestionFeedType::ownQuestion->name => $defaultSort,
			QuestionFeedType::ownAnswer->name   => $defaultSort,
			QuestionFeedType::saved->name       => 'mca.saved_since DESC',
			QuestionFeedType::tracked->name     => 'mca.saved_since DESC',
			QuestionFeedType::recommended->name => $defaultSort,
		];
		$seq = [
			QuestionFeedType::draft->name => 2,
			QuestionFeedType::ownAnswer->name => 2,
			QuestionFeedType::ownQuestion->name => 2,
			QuestionFeedType::tracked->name => 1,
			QuestionFeedType::saved->name => 1,
			QuestionFeedType::recommended->name => 2,
		];
		$filters = $feedTypes ?: QuestionFeedType::cases();
		$result = [];
		foreach($filters as $filter) {
			$result[$seq[$filter->name]] = $orderBySql[$filter->name];
		}
		ksort($result);
		$result = array_unique($result);
		return "ORDER BY " . implode(', ', $result);
	}

	/** @param QuestionFeedType[] $feedTypes */
	private function getFilterSql(array $feedTypes): string {
		$filterSql = [
			QuestionFeedType::draft->name => '(c.content_type IN (1, 2) AND c.author_member_id = :memberId AND c.content_revision IS NOT NULL)',
			QuestionFeedType::ownQuestion->name => '(c.content_type = 1 AND c.author_member_id = :memberId)',
			QuestionFeedType::ownAnswer->name => '(
				(c.content_type = 1 AND oa.ownAnswerId IS NOT NULL AND oa.ownAnswerId != \'\') OR
				(c.content_type = 2 AND c.author_member_id = :memberId AND c.content IS NOT NULL)
			)',
			QuestionFeedType::saved->name => '(c.content_type = 2 AND c.author_member_id <> :memberId AND NOT ISNULL(mca.saved_since))',
			QuestionFeedType::tracked->name => '(c.content_type = 1 AND c.author_member_id <> :memberId AND NOT ISNULL(mca.saved_since))',
			QuestionFeedType::recommended->name => '(
				(c.content_type = 1 AND c.author_member_id <> :memberId AND (
					msa1.target_followed_since IS NOT NULL OR msa2.target_followed_since IS NOT NULL  
				) AND ISNULL(mca.recommendation_removed_on)) OR
				(c.content_type = 2 AND c.author_member_id <> :memberId AND msa1.target_followed_since IS NOT NULL AND ISNULL(mca.recommendation_removed_on))
			)',
		];
		$filters = $feedTypes ?: QuestionFeedType::cases();
		$result = [];
		foreach($filters as $filter) {
			$result[] = $filterSql[$filter->name];
		}
		return implode(' OR ', $result);
	}

	private function data(array $row): QuestionData|AnswerData {
		return $row['p_title'] !== null ?
			$this->contentDataMapper->answerData($row) :
			$this->contentDataMapper->questionData($row);
	}
}