<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

final readonly class DbFeedQueryBuilder {
	private const query = <<<SQL
		SELECT
		    BIN_TO_UUID(c.content_id) AS contentId,
		    c.content_key AS contentKey,
		    c.title,
		    c.content_type AS contentType,
		    c.info,
		    c.info_revision AS infoRevision,
			c.content->"$.pointFrames.P1.content.image" AS image,
			c.content->"$.pointFrames.P1.content.audio" AS audio,
		
		    IF(
		        c.author_member_id = :memberId,
		        IF(c.content IS NULL, 1, IF(c.content_revision IS NULL, 2, 3)),
		        IF(ISNULL(mca.recommendation_removed_on) AND
					(
					    (c.content_type = 1 AND (
					        msa1.target_followed_since IS NOT NULL OR 
					        msa2.target_followed_since IS NOT NULL
					    )) OR 
					    (c.content_type = 2 AND msa1.target_followed_since IS NOT NULL) OR 
					    (c.content_type = 3 AND msa1.target_followed_since IS NOT NULL) OR
                        (c.content_type = 4 AND mca.recommended_by_member_id IS NOT NULL) 		            	
		        	), 4, 5
	            )
		    ) AS contentRelationship,
		    IF(ISNULL(mca.saved_since), 0, 1) AS isSaved,
		    
		    BIN_TO_UUID(m.member_id) AS postedByMemberId,
		    m.username AS postedByUsername,
		    m.profile_picture AS postedByProfilePicture,
            m.profile_description AS postedByProfileDescription,
		    
		    BIN_TO_UUID(mr.member_id) AS recommendedByMemberId,
		    mr.username AS recommendedByUsername,
		    mr.profile_picture AS recommendedByProfilePicture,
            mr.profile_description AS recommendedByProfileDescription,
                        
            COALESCE(rc.recommendedToOthers, 0) AS recommendedToOthers,
            oa.ownAnswerId,
            oa.ownAnswerKey,
            oa.answersCount,

		    BIN_TO_UUID(cp.content_id) AS p_contentId,
		    cp.content_key AS p_contentKey,
		    cp.title AS p_title,
		    cp.content_type AS p_contentType,
			cp.content->"$.pointFrames.P1.content.image" AS p_image,
			cp.content->"$.pointFrames.P1.content.audio" AS p_audio,

		    IF(
		        cp.author_member_id = :memberId,
		        IF(cp.content IS NULL, 1, IF(cp.content_revision IS NULL, 2, 3)),
		        IF(ISNULL(mcap.recommendation_removed_on) AND 
		           (
						msap1.target_followed_since IS NOT NULL OR 
						msap2.target_followed_since IS NOT NULL
					), 4, 5
	            )
		    ) AS p_contentRelationship,
		    IF(ISNULL(mcap.saved_since), 0, 1) AS p_isSaved,
		    
		    BIN_TO_UUID(mp.member_id) AS p_postedByMemberId,
		    mp.username AS p_postedByUsername,
		    mp.profile_picture AS p_postedByProfilePicture,
            mp.profile_description AS p_postedByProfileDescription,

            c.content_id AS p_ownAnswerId,
            c.content_key AS p_ownAnswerKey,
            oap.answersCount AS p_answersCount
			
			%s
	    FROM content_entries c
	    JOIN members m ON c.author_member_id = m.member_id
		LEFT JOIN member_content_activities mca on c.content_id = mca.content_id AND mca.member_id = :memberId
		LEFT JOIN member_social_activities msa1 on c.author_member_id = msa1.target_member_id AND msa1.member_id = :memberId
		LEFT JOIN member_social_activities msa2 on c.author_member_id = msa2.member_id AND msa2.target_member_id = :memberId    

	    LEFT JOIN members mr ON mca.recommended_by_member_id = mr.member_id
	        
	    LEFT JOIN (
	    	SELECT content_id, COUNT(activity_id) AS recommendedToOthers 
	    	FROM member_content_activities 
	    	WHERE recommended_by_member_id = :memberId
	    	GROUP BY content_id
        ) rc ON c.content_id = rc.content_id

	    LEFT JOIN (
	    	SELECT 
	    	    related_entry_id, 
	    	    MAX(IF(author_member_id = :memberId AND content IS NOT NULL, BIN_TO_UUID(content_id), '')) AS ownAnswerId, 
	    	    MAX(IF(author_member_id = :memberId AND content IS NOT NULL, content_key, '')) AS ownAnswerKey, 
	    	    SUM(IF(content IS NOT NULL, 1, 0)) AS answersCount 
	    	FROM content_entries GROUP BY related_entry_id
        ) oa ON c.content_id = oa.related_entry_id
	        
	    LEFT JOIN content_entries cp ON c.related_entry_id = cp.content_id
	    LEFT JOIN members mp ON cp.author_member_id = mp.member_id
		LEFT JOIN member_content_activities mcap on cp.content_id = mcap.content_id AND mcap.member_id = :memberId
		LEFT JOIN member_social_activities msap1 on cp.author_member_id = msap1.target_member_id AND msap1.member_id = :memberId
		LEFT JOIN member_social_activities msap2 on cp.author_member_id = msap1.member_id AND msap2.target_member_id = :memberId    

	    LEFT JOIN (
	    	SELECT 
	    	    related_entry_id, 
	    	    SUM(IF(content IS NOT NULL, 1, 0)) AS answersCount 
	    	FROM content_entries WHERE content IS NOT NULL GROUP BY related_entry_id
        ) oap ON cp.content_id = oap.related_entry_id

		WHERE (c.author_member_id = :memberId OR c.content_type <> 4 OR (mca.recommended_by_member_id IS NOT NULL AND mca.recommendation_removed_on IS NULL)) 
		  AND (c.author_member_id = :memberId OR c.content IS NOT NULL)
		  AND (%s)
		%s		
SQL;

	public function build(
		string $filter = '1',
		string $extraFields = '',
		string $orderBy = '',
	): string {
		return sprintf(self::query, $extraFields, $filter, $orderBy);
	}
}
