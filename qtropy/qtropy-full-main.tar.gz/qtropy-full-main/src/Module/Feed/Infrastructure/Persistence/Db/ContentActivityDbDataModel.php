<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Lib\DbDataModel\Attribute\Fields;
use Walnut\Lib\DbDataModel\Attribute\KeyField;
use Walnut\Lib\DbDataModel\Attribute\ModelRoot;
use Walnut\Lib\DbDataModel\Attribute\Table;

#[ModelRoot('contentActivities')]
final readonly class ContentActivityDbDataModel {
	public function __construct(
		#[Table('member_content_activities'), KeyField('activity_id'), Fields(
			'member_id', 'content_id', 'annotations',
			'recommended_on', 'recommended_by_member_id',
			'recommended_message', 'recommendation_removed_on',
			'explanation_requested_on',
			'explanation_request_message',
			'saved_since'
		)]
		public array $contentActivities,
	) {}
}