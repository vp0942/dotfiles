<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Lib\WriteModel\Mapper\EntityMapper;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Feed\Domain\Model\ActivityId;
use Walnut\Module\Feed\Domain\Model\Annotations;
use Walnut\Module\Feed\Domain\Model\ContentActivity;
use Walnut\Module\Feed\Domain\Model\ExplanationRequestStatus\ExplanationRequested;
use Walnut\Module\Feed\Domain\Model\ExplanationRequestStatus\ExplanationRequestStatus;
use Walnut\Module\Feed\Domain\Model\ExplanationRequestStatus\NoExplanationRequested;
use Walnut\Module\Feed\Domain\Model\RecommendationStatus\NotRecommended;
use Walnut\Module\Feed\Domain\Model\RecommendationStatus\RecommendationStatus;
use Walnut\Module\Feed\Domain\Model\RecommendationStatus\Recommended;
use Walnut\Module\Feed\Domain\Model\RecommendationStatus\RecommendedByMember;
use Walnut\Module\Feed\Domain\Model\SaveStatus\NotSaved;
use Walnut\Module\Feed\Domain\Model\SaveStatus\Saved;
use Walnut\Module\Feed\Domain\Model\SaveStatus\SaveStatus;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Time\DateAndTime;
use Walnut\Module\Kernel\Uuid\Uuid;

/**
 * @implements EntityMapper<ContentActivity, ActivityId, array, string>
 */
final readonly class ContentActivityMapper implements EntityMapper {
	/**
	 * @param ContentActivity $mapped
	 * @return array
	 */
	public function toSourceEntity(object|array $mapped): array {
		return [
			'activity_id' => $mapped->activityId->value->binaryValue,
			'member_id' => $mapped->memberId->value->binaryValue,
			'content_id' => $mapped->contentId->value->binaryValue,
			'annotations' => $mapped->annotations->content,
			'recommended_on' => ($mapped?->recommendationStatus->status?->recommendedOn ?? null)?->format('Y-m-d H:i:s'),
			'recommended_by_member_id' => ($mapped?->recommendationStatus->status?->byMemberId ?? null)?->value->binaryValue,
			'recommended_message' => $mapped?->recommendationStatus->status?->message ?? null,
			'recommendation_removed_on' => ($mapped?->recommendationStatus->status?->removedOn ?? null)?->format('Y-m-d H:i:s'),
			'explanation_requested_on' => ($mapped?->explanationRequestStatus->status?->requestedOn ?? null)?->format('Y-m-d H:i:s'),
			'explanation_request_message' => $mapped?->explanationRequestStatus->status?->message ?? null,
			'saved_since' => ($mapped->saveStatus->status?->savedSince ?? null)?->format('Y-m-d H:i:s'),
		];
	}

	/**
	 * @param ActivityId $mapped
	 * @return string
	 */
	public function toSourceId(object|int|string $mapped): string {
		return $mapped->value->binaryValue;
	}

	private function getRecommendationStatus(array $source): Recommended|RecommendedByMember|NotRecommended {
		if (($rro = $source['recommendation_removed_on'] ?? null) !== null) {
			return new NotRecommended(new DateAndTime($rro));
		}
		return (($ro = $source['recommended_on'] ?? null) !== null) &&
			($mid = $source['recommended_by_member_id'] ?? null) ?
			new RecommendedByMember(
				new DateAndTime($ro),
				new MemberId(Uuid::fromBinary($mid)),
				(string)($source['recommended_message'] ?? '')
			) : new Recommended;
	}

	/**
	 * @param array $source
	 * @return ContentActivity
	 */
	public function fromSourceEntity(object|array $source): ContentActivity {
		return new ContentActivity(
			new ActivityId(Uuid::fromBinary((string)($source['activity_id'] ?? ''))),
			new MemberId(Uuid::fromBinary((string)($source['member_id'] ?? ''))),
			new ContentId(Uuid::fromBinary((string)($source['content_id'] ?? ''))),
			new Annotations((string)($source['annotations'] ?? '')),
			new RecommendationStatus($this->getRecommendationStatus($source)),
			new ExplanationRequestStatus(
				($ero = $source['explanation_requested_on'] ?? null) !== null ?
					new ExplanationRequested(
						new DateAndTime($ero),
						(string)($source['explanation_request_message'] ?? null)
					) : new NoExplanationRequested
			),
			new SaveStatus(($svs = $source['saved_since'] ?? null) !== null ?
				new Saved(new DateAndTime($svs)) : new NotSaved),
		);
	}

	/**
	 * @param string $source
	 * @return ActivityId
	 */
	public function fromSourceId(object|int|string $source): ActivityId {
		return new ActivityId(Uuid::fromBinary($source));
	}
}
