<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Lib\WriteModel\Configuration\WriteModel;
use Walnut\Lib\WriteModel\IdentityGenerator\WriteModelIdentityGenerator;
use Walnut\Lib\WriteModel\Repository\WriteModelRepository;
use Walnut\Module\Content\Domain\Model\ContentId;
use Walnut\Module\Content\Domain\Model\ContentKey;
use Walnut\Module\Feed\Domain\Model\Annotations;
use Walnut\Module\Feed\Domain\Model\ContentActivity;
use Walnut\Module\Feed\Domain\Model\ExplanationRequestStatus\ExplanationRequestStatus;
use Walnut\Module\Feed\Domain\Model\ExplanationRequestStatus\NoExplanationRequested;
use Walnut\Module\Feed\Domain\Model\RecommendationStatus\RecommendationStatus;
use Walnut\Module\Feed\Domain\Model\RecommendationStatus\Recommended;
use Walnut\Module\Feed\Domain\Model\SaveStatus\NotSaved;
use Walnut\Module\Feed\Domain\Model\SaveStatus\SaveStatus;
use Walnut\Module\Feed\Domain\Repository\ContentActivityRepository;
use Walnut\Module\Feed\Domain\Repository\InvalidContentActivity;
use Walnut\Module\Kernel\Domain\Model\MemberId;
use Walnut\Module\Kernel\Uuid\Uuid;
use Walnut\Module\Social\Domain\Model\ActivityId;

final readonly class DbContentActivityRepository implements ContentActivityRepository {
	private const query = "
		SELECT BIN_TO_UUID(activity_id) AS activityId, c.content_id AS contentId 
		FROM content_entries c
		JOIN members m ON m.member_id = ? AND c.content_id = ? 
		LEFT JOIN member_content_activities a 
		    ON c.content_id = a.content_id
		    AND m.member_id = a.member_id
	";

	private const keyQuery = "
		SELECT BIN_TO_UUID(activity_id) AS activityId, c.content_id AS contentId
		FROM content_entries c
		JOIN members m ON m.member_id = ? AND c.content_key = ? 
		LEFT JOIN member_content_activities a 
		    ON c.content_id = a.content_id
		    AND m.member_id = a.member_id
	";

	public function __construct(
		private readonly QueryExecutor $queryExecutor,
		#[WriteModel(ContentActivity::class)]
		private readonly WriteModelIdentityGenerator $identityGenerator,
		#[WriteModel(ContentActivity::class)]
		private readonly WriteModelRepository $writeModelRepository,
	) {}

	/** @throws InvalidContentActivity */
	public function forMemberAndContent(
		MemberId $memberId,
		ContentId|ContentKey $contentId,
	): ContentActivity {
		$activity = $contentId instanceof ContentId ?
			$this->queryExecutor->execute(self::query,
				[$memberId->value->binaryValue, $contentId->value->binaryValue])->first() :
			$this->queryExecutor->execute(self::keyQuery,
				[$memberId->value->binaryValue, $contentId->value])->first();
		if (!$activity) {
			throw new InvalidContentActivity;
		}
		$activityId = $activity['activityId'] ?? null;
		$contentIdX = $activity['contentId'] ?? null;
		return $activityId ?
			$this->writeModelRepository->byId(
				new ActivityId(Uuid::fromString($activityId))
			) : new ContentActivity(
				$this->identityGenerator->generateIdentity(),
				$memberId,
				new ContentId(Uuid::fromBinary($contentIdX)),
				new Annotations(''),
				new RecommendationStatus(new Recommended),
				new ExplanationRequestStatus(new NoExplanationRequested),
				new SaveStatus(new NotSaved),
			)
		;
	}
}
