<?php

namespace Walnut\Module\Feed\Infrastructure\Persistence\Db;

use Walnut\Lib\DbQuery\QueryExecutor;
use Walnut\Module\Feed\Application\Model\AnswerData;
use Walnut\Module\Feed\Application\Model\NoteData;
use Walnut\Module\Feed\Application\Model\QuestionData;
use Walnut\Module\Feed\Application\Model\TreatiseData;
use Walnut\Module\Feed\Application\Query\Search\ContentSearch;
use Walnut\Module\Feed\Application\Query\Search\ContentSearchQuery;
use Walnut\Module\Feed\Application\Query\Search\ContentSearchType;
use Walnut\Module\Member\Domain\Model\Member;

final readonly class DbContentSearchQuery implements ContentSearchQuery {
	public function __construct(
		private QueryExecutor      $queryExecutor,
		private ContentDataMapper  $contentDataMapper,
		private DbFeedQueryBuilder $queryBuilder
	) {}

	/** @return list<QuestionData|AnswerData|TreatiseData|NoteData> */
	public function __invoke(Member $member, ContentSearch $contentSearch): array {
		$params = ['memberId' => $member->memberId->value->binaryValue];
		$txt = $contentSearch->searchText ?: '';
		if ($txt !== '') {
			$params['searchText'] = "%" . $txt . "%";
		}
		$share = $contentSearch->sharedBy ?: '';
		if ($share !== '') {
			$params['sharedBy'] = "%" . $share . "%";
		}
		$by = $contentSearch->postedBy ?: '';
		if ($by !== '') {
			$params['postedBy'] = "%" . $by . "%";
		}
		$answer = $contentSearch->answeredBy ?: '';
		if ($answer !== '') {
			$params['answeredBy'] = "%" . $answer . "%";
		}

		return array_map($this->contentDataMapper->contentData(...),
			$this->queryExecutor->execute(
				$this->queryBuilder->build(filter: $this->getSql($contentSearch))
					//. " ORDER BY c.visits_counter DESC", $params
					. " ORDER BY c.last_revision_date DESC, c.date_created DESC", $params
			)->all()
		);
	}

	private function getSql(ContentSearch $contentSearch): string {
		$searches = [];
		$contentSearchTypes = $contentSearch->contentSearchTypes ?: ContentSearchType::cases();
		if (count($contentSearchTypes) !== count(ContentSearchType::cases())) {
			$t = [];
			if (in_array(ContentSearchType::questionsAndAnswers, $contentSearchTypes)) {
				$t[] = 1;
				$t[] = 2;
			}
			if (in_array(ContentSearchType::treatises, $contentSearchTypes)) {
				$t[] = 3;
			}
			if (in_array(ContentSearchType::notes, $contentSearchTypes)) {
				$t[] = 4;
			}
			$searches[] = "c.content_type IN (" . implode(', ', $t) . ")";
		}
		$txt = $contentSearch->searchText ?: '';
		if ($txt !== '') {
			$searches[] = "(c.title LIKE :searchText OR c.content_key LIKE :searchText OR c.content LIKE :searchText OR (c.content_revision LIKE :searchText AND c.author_member_id = :memberId))";
		}
		$share = $contentSearch->sharedBy ?: '';
		if ($share !== '') {
			$searches[] = "mr.username LIKE :sharedBy";
		}
		$by = $contentSearch->postedBy ?: '';
		if ($by !== '') {
			$searches[] = "(
				(c.content_type <> 2 AND m.username LIKE :postedBy) OR
				(c.content_type = 2 AND mp.username LIKE :postedBy)
			)";
		}
		$answer = $contentSearch->answeredBy ?: '';
		if ($answer !== '') {
			//(c.content_type = 1 AND m.username LIKE :answeredBy) OR
			$searches[] = "(
				(c.content_type = 2 AND m.username LIKE :answeredBy)
			)";
		}
		//var_dump($searches);

		return '(' . (implode(' AND ', $searches) ?: '1') . ')';
	}
}